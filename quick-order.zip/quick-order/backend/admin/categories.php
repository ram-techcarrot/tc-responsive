<?php
require_once '../auth/check_auth.php';
require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'add_category') {
        $name = trim($_POST['name']);
        $icon = trim($_POST['icon']);
        $sort_order = intval($_POST['sort_order']);
        $is_active = isset($_POST['is_active']) ? 1 : 0;
        
        $query = "INSERT INTO categories (name, icon, sort_order, is_active) 
                  VALUES (:name, :icon, :sort_order, :is_active)";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':icon', $icon);
        $stmt->bindParam(':sort_order', $sort_order);
        $stmt->bindParam(':is_active', $is_active);
        
        if ($stmt->execute()) {
            $success = 'Category added successfully!';
        } else {
            $error = 'Failed to add category.';
        }
    } elseif ($action === 'edit_category') {
        $id = $_POST['id'];
        $name = trim($_POST['name']);
        $icon = trim($_POST['icon']);
        $sort_order = intval($_POST['sort_order']);
        $is_active = isset($_POST['is_active']) ? 1 : 0;
        
        $query = "UPDATE categories SET name = :name, icon = :icon, 
                  sort_order = :sort_order, is_active = :is_active WHERE id = :id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':icon', $icon);
        $stmt->bindParam(':sort_order', $sort_order);
        $stmt->bindParam(':is_active', $is_active);
        
        if ($stmt->execute()) {
            $success = 'Category updated successfully!';
        } else {
            $error = 'Failed to update category.';
        }
    } elseif ($action === 'delete_category') {
        $id = $_POST['id'];
        
        // Check if category has menu items
        $query = "SELECT COUNT(*) as count FROM menu_items WHERE category_id = :id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        $item_count = $stmt->fetch()['count'];
        
        if ($item_count > 0) {
            $error = 'Cannot delete category. It has ' . $item_count . ' menu items. Please move or delete the items first.';
        } else {
            $query = "DELETE FROM categories WHERE id = :id";
            $stmt = $db->prepare($query);
            $stmt->bindParam(':id', $id);
            
            if ($stmt->execute()) {
                $success = 'Category deleted successfully!';
            } else {
                $error = 'Failed to delete category.';
            }
        }
    }
}

// Get all categories
$query = "SELECT c.*, COUNT(mi.id) as item_count FROM categories c 
          LEFT JOIN menu_items mi ON c.id = mi.category_id 
          GROUP BY c.id 
          ORDER BY c.sort_order, c.name";
$stmt = $db->prepare($query);
$stmt->execute();
$categories = $stmt->fetchAll();

// Get category for editing
$edit_category = null;
if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $query = "SELECT * FROM categories WHERE id = :id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    $edit_category = $stmt->fetch();
}
?>

<?php include 'includes/header.php'; ?>
    <style>
        .category-card {
            background: white;
            border-radius: 10px;
            padding: 1.5rem;
            margin-bottom: 1rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            border-left: 4px solid #007bff;
        }
        .category-card.inactive {
            border-left-color: #dc3545;
            opacity: 0.7;
        }
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.3);
        }
        .form-control:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
        }
        .status-badge {
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
            text-transform: uppercase;
        }
        .status-active { background: #d4edda; color: #155724; }
        .status-inactive { background: #f8d7da; color: #721c24; }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <?php include 'includes/sidebar.php'; ?>
            
            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2><i class="fas fa-tags"></i> Category Management</h2>
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addCategoryModal">
                        <i class="fas fa-plus"></i> Add Category
                    </button>
                </div>
                
                <?php if (isset($success)): ?>
                    <div class="alert alert-success alert-dismissible fade show">
                        <i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <?php if (isset($error)): ?>
                    <div class="alert alert-danger alert-dismissible fade show">
                        <i class="fas fa-exclamation-triangle"></i> <?php echo htmlspecialchars($error); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <!-- Categories List -->
                <div class="row">
                    <?php foreach ($categories as $category): ?>
                        <div class="col-md-6 col-lg-4 mb-3">
                            <div class="category-card <?php echo $category['is_active'] ? '' : 'inactive'; ?>">
                                <div class="d-flex justify-content-between align-items-start mb-2">
                                    <h5 class="mb-0"><?php echo htmlspecialchars($category['name']); ?></h5>
                                    <span class="status-badge status-<?php echo $category['is_active'] ? 'active' : 'inactive'; ?>">
                                        <?php echo $category['is_active'] ? 'Active' : 'Inactive'; ?>
                                    </span>
                                </div>
                                
                                <?php if ($category['icon']): ?>
                                    <div class="mb-2">
                                        <img src="../../image/<?php echo htmlspecialchars($category['icon']); ?>" 
                                             alt="<?php echo htmlspecialchars($category['name']); ?>" 
                                             style="width: 24px; height: 24px;">
                                        <small class="text-muted ms-2"><?php echo htmlspecialchars($category['icon']); ?></small>
                                    </div>
                                <?php endif; ?>
                                
                                <p class="mb-2 text-muted">
                                    <i class="fas fa-sort"></i> Sort Order: <?php echo $category['sort_order']; ?>
                                </p>
                                <p class="mb-2 text-muted">
                                    <i class="fas fa-book"></i> Menu Items: <?php echo $category['item_count']; ?>
                                </p>
                                
                                <div class="btn-group btn-group-sm">
                                    <button class="btn btn-outline-primary" 
                                            onclick="editCategory(<?php echo htmlspecialchars(json_encode($category)); ?>)">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="btn btn-outline-danger" 
                                            onclick="deleteCategory(<?php echo $category['id']; ?>, '<?php echo htmlspecialchars($category['name']); ?>', <?php echo $category['item_count']; ?>)">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                
                <?php if (empty($categories)): ?>
                    <div class="text-center py-5">
                        <i class="fas fa-tags fa-3x text-muted mb-3"></i>
                        <h5 class="text-muted">No categories found</h5>
                        <p class="text-muted">Add your first category to get started.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Add/Edit Category Modal -->
    <div class="modal fade" id="addCategoryModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-plus"></i> Add Category
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" id="categoryForm">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="add_category" id="formAction">
                        <input type="hidden" name="id" id="categoryId">
                        
                        <div class="mb-3">
                            <label for="name" class="form-label">Category Name *</label>
                            <input type="text" class="form-control" name="name" id="name" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="icon" class="form-label">Icon File</label>
                            <select class="form-select" name="icon" id="icon">
                                <option value="">Select an icon (optional)</option>
                                <option value="Tea.svg">Tea.svg</option>
                                <option value="Coffee.svg">Coffee.svg</option>
                                <option value="Juice.svg">Juice.svg</option>
                                <option value="Water.svg">Water.svg</option>
                                <option value="Snacks.svg">Snacks.svg</option>
                                <option value="Soft Drink.svg">Soft Drink.svg</option>
                                <option value="Home.svg">Home.svg</option>
                                <option value="Cart.svg">Cart.svg</option>
                                <option value="Plus.svg">Plus.svg</option>
                                <option value="Success.svg">Success.svg</option>
                            </select>
                            <small class="text-muted">Available SVG icons from the image/ directory</small>
                        </div>
                        
                        <div class="mb-3">
                            <label for="sort_order" class="form-label">Sort Order</label>
                            <input type="number" class="form-control" name="sort_order" id="sort_order" 
                                   value="0" min="0">
                        </div>
                        
                        <div class="mb-3">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="is_active" 
                                       id="is_active" checked>
                                <label class="form-check-label" for="is_active">
                                    Active (visible in frontend)
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Save Category
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Delete Confirmation Modal -->
    <div class="modal fade" id="deleteModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-exclamation-triangle text-warning"></i> Confirm Delete
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p id="deleteMessage"></p>
                    <p class="text-danger">This action cannot be undone.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <form method="POST" style="display: inline;">
                        <input type="hidden" name="action" value="delete_category">
                        <input type="hidden" name="id" id="deleteCategoryId">
                        <button type="submit" class="btn btn-danger">
                            <i class="fas fa-trash"></i> Delete
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function editCategory(category) {
            document.getElementById('formAction').value = 'edit_category';
            document.getElementById('categoryId').value = category.id;
            document.getElementById('name').value = category.name;
            document.getElementById('icon').value = category.icon || '';
            document.getElementById('sort_order').value = category.sort_order;
            document.getElementById('is_active').checked = category.is_active == 1;
            
            document.querySelector('.modal-title').innerHTML = '<i class="fas fa-edit"></i> Edit Category';
            document.querySelector('.modal-footer button[type="submit"]').innerHTML = '<i class="fas fa-save"></i> Update Category';
            
            new bootstrap.Modal(document.getElementById('addCategoryModal')).show();
        }
        
        function deleteCategory(id, name, itemCount) {
            document.getElementById('deleteCategoryId').value = id;
            
            if (itemCount > 0) {
                document.getElementById('deleteMessage').innerHTML = 
                    `Cannot delete category "${name}". It has ${itemCount} menu items. Please move or delete the items first.`;
                document.querySelector('#deleteModal .btn-danger').style.display = 'none';
            } else {
                document.getElementById('deleteMessage').innerHTML = 
                    `Are you sure you want to delete the category "${name}"?`;
                document.querySelector('#deleteModal .btn-danger').style.display = 'inline-block';
            }
            
            new bootstrap.Modal(document.getElementById('deleteModal')).show();
        }
        
        // Reset form when modal is hidden
        document.getElementById('addCategoryModal').addEventListener('hidden.bs.modal', function() {
            document.getElementById('categoryForm').reset();
            document.getElementById('formAction').value = 'add_category';
            document.getElementById('categoryId').value = '';
            document.querySelector('.modal-title').innerHTML = '<i class="fas fa-plus"></i> Add Category';
            document.querySelector('.modal-footer button[type="submit"]').innerHTML = '<i class="fas fa-save"></i> Save Category';
        });
    </script>
    <?php include 'includes/footer.php'; ?>
