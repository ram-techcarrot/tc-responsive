<?php
require_once 'backend/config/database.php';

$database = new Database();
$db = $database->getConnection();

// Get open orders (placed, pending, cooking)
$open_orders = [];
try {
    $query = "SELECT o.*, t.table_number,
                     GROUP_CONCAT(CONCAT(oi.item_name, ' (', oi.quantity, ')') SEPARATOR ', ') as items_summary,
                     COUNT(oi.id) as item_count
              FROM orders o 
              LEFT JOIN tables t ON o.table_id = t.id
              LEFT JOIN order_items oi ON o.id = oi.order_id 
              WHERE o.status IN ('placed', 'pending', 'cooking')
              GROUP BY o.id 
              ORDER BY o.created_at ASC";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $open_orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    error_log("Error fetching open orders: " . $e->getMessage());
}

// Get detailed order items for each order
$order_items = [];
if (!empty($open_orders)) {
    $order_ids = array_column($open_orders, 'id');
    $placeholders = str_repeat('?,', count($order_ids) - 1) . '?';
    
    $query = "SELECT oi.*, t.table_number, o.customer_name, o.created_at 
              FROM order_items oi 
              JOIN orders o ON oi.order_id = o.id 
              LEFT JOIN tables t ON o.table_id = t.id
              WHERE oi.order_id IN ($placeholders) 
              ORDER BY o.created_at ASC, oi.order_id ASC";
    $stmt = $db->prepare($query);
    $stmt->execute($order_ids);
    $order_items = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Group items by order
$grouped_items = [];
foreach ($order_items as $item) {
    $grouped_items[$item['order_id']][] = $item;
}

// Function to get status-specific colors with high contrast
function getStatusColor($status) {
    switch ($status) {
        case 'placed':
            return [
                'bg' => '#FF0000',      // Bright Red
                'border' => '#CC0000',  // Dark Red
                'text' => '#FFFFFF',    // White text
                'badge' => '#990000'    // Dark Red badge
            ];
        case 'pending':
            return [
                'bg' => '#FFFF00',      // Bright Yellow
                'border' => '#FFD700',  // Gold
                'text' => '#000000',    // Black text
                'badge' => '#FF8C00'    // Orange badge
            ];
        case 'cooking':
            return [
                'bg' => '#00FF00',      // Bright Green
                'border' => '#00CC00',  // Dark Green
                'text' => '#000000',    // Black text
                'badge' => '#006600'    // Dark Green badge
            ];
        default:
            return [
                'bg' => '#FF00FF',      // Bright Magenta
                'border' => '#CC00CC',  // Dark Magenta
                'text' => '#FFFFFF',    // White text
                'badge' => '#990099'    // Dark Magenta badge
            ];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kitchen Orders - Sobha</title>
    
    <!-- Bootstrap 5 CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root {
            --kitchen-primary: #1a1a1a;
            --kitchen-secondary: #2d2d2d;
            --kitchen-accent: #D4AF37;
            --kitchen-light: #f8f9fa;
            --kitchen-dark: #1a1a1a;
        }

        body {
            background: linear-gradient(135deg, #000000 0%, #1a1a1a 50%, #000000 100%);
            font-family: 'Arial', sans-serif;
            min-height: 100vh;
            color: #fff;
        }

        .kitchen-header {
            background: linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 50%, #1a1a1a 100%);
            padding: 1rem 0;
            border-bottom: 3px solid var(--kitchen-accent);
            box-shadow: 
                0 4px 15px rgba(0,0,0,0.3),
                inset 0 1px 0 rgba(255,255,255,0.1),
                inset 0 -1px 0 rgba(0,0,0,0.3);
            position: relative;
            overflow: hidden;
        }

        .kitchen-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 50%;
            background: linear-gradient(180deg, rgba(255,255,255,0.1) 0%, transparent 100%);
            pointer-events: none;
        }

        .current-time {
            font-size: 1.5rem;
            font-weight: bold;
            color: var(--kitchen-accent);
            text-align: right;
        }

        .kitchen-title {
            font-size: 2.5rem;
            font-weight: bold;
            color: #fff;
            text-align: center;
            margin: 0;
        }

        .orders-container {
            padding: 2rem 0;
        }

        .order-card {
            background: linear-gradient(145deg, #ffffff 0%, #f8f9fa 50%, #ffffff 100%);
            border-radius: 15px;
            margin-bottom: 1.5rem;
            box-shadow: 
                0 8px 25px rgba(0,0,0,0.5), 
                0 0 20px rgba(255,255,255,0.1),
                inset 0 1px 0 rgba(255,255,255,0.8),
                inset 0 -1px 0 rgba(0,0,0,0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            height: fit-content;
            overflow: hidden;
            border: 2px solid rgba(255,255,255,0.2);
            position: relative;
        }

        .order-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 50%;
            background: linear-gradient(180deg, rgba(255,255,255,0.6) 0%, rgba(255,255,255,0.1) 100%);
            border-radius: 15px 15px 0 0;
            pointer-events: none;
            z-index: 1;
        }

        .order-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 35px rgba(0,0,0,0.6), 0 0 30px rgba(255,255,255,0.2);
        }

        .order-card.placed {
            border-left: 8px solid #FF0000;
            box-shadow: 0 8px 25px rgba(255,0,0,0.3), 0 0 20px rgba(255,0,0,0.2);
        }

        .order-card.pending {
            border-left: 8px solid #FFFF00;
            box-shadow: 0 8px 25px rgba(255,255,0,0.3), 0 0 20px rgba(255,255,0,0.2);
        }

        .order-card.cooking {
            border-left: 8px solid #00FF00;
            box-shadow: 0 8px 25px rgba(0,255,0,0.3), 0 0 20px rgba(0,255,0,0.2);
        }

        .order-header {
            color: #fff;
            padding: 1rem;
            border-radius: 15px 15px 0 0;
            position: relative;
            overflow: hidden;
        }

        .order-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 60%;
            background: linear-gradient(180deg, rgba(255,255,255,0.4) 0%, rgba(255,255,255,0.1) 50%, transparent 100%);
            border-radius: 15px 15px 0 0;
            pointer-events: none;
            z-index: 1;
        }

        .order-header::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(45deg, rgba(255,255,255,0.1) 0%, transparent 50%, rgba(255,255,255,0.05) 100%);
            border-radius: 15px 15px 0 0;
            pointer-events: none;
            z-index: 1;
        }

        .order-header.placed {
            background: linear-gradient(135deg, #FF0000 0%, #CC0000 50%, #990000 100%);
            color: #FFFFFF;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.8);
            box-shadow: inset 0 1px 0 rgba(255,255,255,0.3), inset 0 -1px 0 rgba(0,0,0,0.2);
        }

        .order-header.pending {
            background: linear-gradient(135deg, #FFFF00 0%, #FFD700 50%, #FFA500 100%);
            color: #000000;
            text-shadow: 1px 1px 2px rgba(255,255,255,0.8);
            box-shadow: inset 0 1px 0 rgba(255,255,255,0.4), inset 0 -1px 0 rgba(0,0,0,0.1);
        }

        .order-header.cooking {
            background: linear-gradient(135deg, #00FF00 0%, #00CC00 50%, #009900 100%);
            color: #000000;
            text-shadow: 1px 1px 2px rgba(255,255,255,0.8);
            box-shadow: inset 0 1px 0 rgba(255,255,255,0.3), inset 0 -1px 0 rgba(0,0,0,0.1);
        }

        .order-number {
            font-size: 1.2rem;
            font-weight: 600;
            margin: 0.5rem 0 0 0;
            letter-spacing: 0.5px;
            opacity: 0.8;
        }

        .order-time {
            font-size: 1.5rem;
            opacity: 0.9;
            margin: 0.5rem 0 0 0;
            font-weight: 700;
        }

        .order-customer {
            font-size: 2rem;
            font-weight: 900;
            margin: 0 0 0.5rem 0;
            letter-spacing: 1px;
        }

        .order-table {
            font-size: 1.4rem;
            background: rgba(255,255,255,0.2);
            padding: 0.5rem 1rem;
            border-radius: 25px;
            display: inline-block;
            margin-top: 0.5rem;
            font-weight: 600;
        }

        .order-header.pending .order-table {
            background: rgba(0,0,0,0.2);
        }

        .order-body {
            padding: 1rem;
        }

        .items-section {
            margin-bottom: 1rem;
        }

        .items-title {
            font-size: 1.2rem;
            font-weight: bold;
            color: var(--kitchen-dark);
            margin-bottom: 0.8rem;
            border-bottom: 2px solid var(--kitchen-accent);
            padding-bottom: 0.3rem;
        }

        .item-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0.6rem;
            margin-bottom: 0.4rem;
            background: linear-gradient(145deg, #f8f9fa 0%, #e9ecef 50%, #f8f9fa 100%);
            border-radius: 8px;
            border-left: 3px solid var(--kitchen-accent);
            box-shadow: 
                inset 0 1px 0 rgba(255,255,255,0.8),
                inset 0 -1px 0 rgba(0,0,0,0.1);
            position: relative;
            overflow: hidden;
        }

        .item-row::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 50%;
            background: linear-gradient(180deg, rgba(255,255,255,0.6) 0%, transparent 100%);
            border-radius: 8px 8px 0 0;
            pointer-events: none;
        }

        .item-name {
            font-size: 1rem;
            font-weight: 600;
            color: var(--kitchen-dark);
            flex-grow: 1;
        }

        .item-quantity {
            background: linear-gradient(135deg, #D4AF37 0%, #B8941F 50%, #9A7B0F 100%);
            color: #000;
            padding: 0.3rem 0.8rem;
            border-radius: 15px;
            font-size: 1rem;
            font-weight: bold;
            margin-left: 0.5rem;
            border: 2px solid #FFFFFF;
            box-shadow: 
                0 0 10px rgba(212,175,55,0.5),
                inset 0 1px 0 rgba(255,255,255,0.4),
                inset 0 -1px 0 rgba(0,0,0,0.2);
            position: relative;
            overflow: hidden;
        }

        .item-quantity::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 50%;
            background: linear-gradient(180deg, rgba(255,255,255,0.4) 0%, transparent 100%);
            border-radius: 15px 15px 0 0;
            pointer-events: none;
        }

        .order-actions {
            text-align: center;
            padding-top: 0.8rem;
            border-top: 2px solid #eee;
        }

        .status-btn {
            padding: 0.6rem 1.2rem;
            font-size: 1rem;
            font-weight: bold;
            border-radius: 20px;
            border: none;
            margin: 0.2rem;
            transition: all 0.3s ease;
            width: 100%;
            position: relative;
            overflow: hidden;
        }

        .status-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 60%;
            background: linear-gradient(180deg, rgba(255,255,255,0.4) 0%, rgba(255,255,255,0.1) 50%, transparent 100%);
            border-radius: 20px 20px 0 0;
            pointer-events: none;
            z-index: 1;
        }

        .status-btn::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(45deg, rgba(255,255,255,0.1) 0%, transparent 50%, rgba(255,255,255,0.05) 100%);
            border-radius: 20px;
            pointer-events: none;
            z-index: 1;
        }

        .btn-cooking {
            background: linear-gradient(135deg, #FF4500 0%, #FF0000 50%, #CC0000 100%);
            color: #fff;
            border: 3px solid #FFFFFF;
            box-shadow: 
                0 0 15px rgba(255,69,0,0.8),
                inset 0 1px 0 rgba(255,255,255,0.3),
                inset 0 -1px 0 rgba(0,0,0,0.2);
            font-weight: 900;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.8);
        }

        .btn-cooking:hover {
            background: linear-gradient(135deg, #FF0000 0%, #CC0000 50%, #990000 100%);
            transform: scale(1.05);
            box-shadow: 
                0 0 20px rgba(255,0,0,1),
                inset 0 1px 0 rgba(255,255,255,0.4),
                inset 0 -1px 0 rgba(0,0,0,0.3);
        }

        .btn-ready {
            background: linear-gradient(135deg, #00FF00 0%, #00CC00 50%, #009900 100%);
            color: #000;
            border: 3px solid #000000;
            box-shadow: 
                0 0 15px rgba(0,255,0,0.8),
                inset 0 1px 0 rgba(255,255,255,0.4),
                inset 0 -1px 0 rgba(0,0,0,0.1);
            font-weight: 900;
            text-shadow: 1px 1px 2px rgba(255,255,255,0.8);
        }

        .btn-ready:hover {
            background: linear-gradient(135deg, #00CC00 0%, #009900 50%, #006600 100%);
            transform: scale(1.05);
            box-shadow: 
                0 0 20px rgba(0,255,0,1),
                inset 0 1px 0 rgba(255,255,255,0.5),
                inset 0 -1px 0 rgba(0,0,0,0.2);
        }

        .status-badge {
            position: absolute;
            top: 1rem;
            right: 1rem;
            z-index: 2;
        }

        .status-badge .badge {
            font-size: 0.9rem;
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-weight: bold;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            position: relative;
            overflow: hidden;
        }

        .status-badge .badge::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 50%;
            background: linear-gradient(180deg, rgba(255,255,255,0.3) 0%, transparent 100%);
            border-radius: 20px 20px 0 0;
            pointer-events: none;
        }

        .badge.placed {
            background: linear-gradient(135deg, #990000 0%, #660000 100%) !important;
            color: #fff;
            border: 2px solid #FFFFFF;
            box-shadow: 
                0 0 10px rgba(255,0,0,0.8),
                inset 0 1px 0 rgba(255,255,255,0.2),
                inset 0 -1px 0 rgba(0,0,0,0.2);
        }

        .badge.pending {
            background: linear-gradient(135deg, #FF8C00 0%, #FF6600 100%) !important;
            color: #000;
            border: 2px solid #000000;
            box-shadow: 
                0 0 10px rgba(255,255,0,0.8),
                inset 0 1px 0 rgba(255,255,255,0.3),
                inset 0 -1px 0 rgba(0,0,0,0.1);
        }

        .badge.cooking {
            background: linear-gradient(135deg, #006600 0%, #004400 100%) !important;
            color: #fff;
            border: 2px solid #FFFFFF;
            box-shadow: 
                0 0 10px rgba(0,255,0,0.8),
                inset 0 1px 0 rgba(255,255,255,0.2),
                inset 0 -1px 0 rgba(0,0,0,0.2);
        }

        .no-orders {
            text-align: center;
            padding: 4rem 2rem;
            background: rgba(255,255,255,0.1);
            border-radius: 15px;
            margin: 2rem 0;
        }

        .no-orders i {
            font-size: 4rem;
            color: var(--kitchen-accent);
            margin-bottom: 1rem;
        }

        .no-orders h3 {
            font-size: 2rem;
            color: #fff;
            margin-bottom: 1rem;
        }

        .refresh-btn {
            position: fixed;
            bottom: 2rem;
            right: 2rem;
            background: linear-gradient(135deg, #D4AF37 0%, #B8941F 50%, #9A7B0F 100%);
            color: #000;
            border: 3px solid #FFFFFF;
            border-radius: 50%;
            width: 60px;
            height: 60px;
            font-size: 1.5rem;
            box-shadow: 
                0 4px 15px rgba(0,0,0,0.3),
                0 0 20px rgba(212,175,55,0.5),
                inset 0 1px 0 rgba(255,255,255,0.4),
                inset 0 -1px 0 rgba(0,0,0,0.2);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .refresh-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 50%;
            background: linear-gradient(180deg, rgba(255,255,255,0.4) 0%, transparent 100%);
            border-radius: 50%;
            pointer-events: none;
        }

        .refresh-btn:hover {
            background: linear-gradient(135deg, #B8941F 0%, #9A7B0F 50%, #7A5F0A 100%);
            transform: scale(1.1);
            box-shadow: 
                0 6px 20px rgba(0,0,0,0.4),
                0 0 25px rgba(212,175,55,0.7),
                inset 0 1px 0 rgba(255,255,255,0.5),
                inset 0 -1px 0 rgba(0,0,0,0.3);
        }

        /* Auto-refresh every 30 seconds */
        .auto-refresh {
            position: fixed;
            top: 1rem;
            left: 1rem;
            background: rgba(0,0,0,0.7);
            color: #fff;
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-size: 0.9rem;
        }

        @media (max-width: 1200px) {
            .order-number {
                font-size: 1.3rem;
            }
            
            .order-time {
                font-size: 1rem;
            }
            
            .order-customer {
                font-size: 1.2rem;
            }
        }

        @media (max-width: 768px) {
            .kitchen-title {
                font-size: 2rem;
            }
            
            .current-time {
                font-size: 1.2rem;
            }
            
            .order-number {
                font-size: 1.2rem;
            }
            
            .item-name {
                font-size: 0.9rem;
            }
            
            .item-quantity {
                font-size: 0.9rem;
            }
            
            .status-btn {
                font-size: 0.9rem;
                padding: 0.5rem 1rem;
            }
        }
    </style>
</head>
<body>
    <!-- Kitchen Header -->
    <header class="kitchen-header">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h1 class="kitchen-title">
                        <i class="fas fa-utensils"></i> KITCHEN ORDERS
                    </h1>
                </div>
                <div class="col-md-4">
                    <div class="current-time" id="currentTime"></div>
                </div>
            </div>
        </div>
    </header>

    <!-- Auto-refresh indicator -->
    <div class="auto-refresh">
        <i class="fas fa-sync-alt"></i> Auto-refresh: 30s
    </div>

    <!-- Orders Container -->
    <div class="container orders-container">
        <?php if (empty($open_orders)): ?>
            <div class="no-orders">
                <i class="fas fa-check-circle"></i>
                <h3>No Open Orders</h3>
                <p>All orders are completed! Great job!</p>
            </div>
        <?php else: ?>
            <div class="row">
                <?php foreach ($open_orders as $order): ?>
                    <?php $statusColors = getStatusColor($order['status']); ?>
                    <div class="col-xl-3 col-lg-4 col-md-6 col-sm-12 mb-3">
                        <div class="order-card <?php echo $order['status']; ?>" data-order-id="<?php echo $order['id']; ?>">
                            <div class="order-header <?php echo $order['status']; ?>">
                                <div class="row align-items-center">
                                    <div class="col-md-8">
                                        <h2 class="order-number">Order #<?php echo $order['order_number']; ?></h2>
                                        <p class="order-time">
                                            <i class="fas fa-clock"></i> 
                                            <?php echo date('H:i', strtotime($order['created_at'])); ?>
                                        </p>
                                        <h4 class="order-customer">
                                            <i class="fas fa-user"></i> <?php echo htmlspecialchars($order['customer_name'] ?? 'Customer'); ?>
                                        </h4>
                                        <div class="order-table">
                                            <i class="fas fa-table"></i> Table <?php echo htmlspecialchars($order['table_number'] ?? 'N/A'); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-4 text-end">
                                        <div class="status-badge">
                                            <span class="badge <?php echo $order['status']; ?>"><?php echo strtoupper($order['status']); ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="order-body">
                                <div class="items-section">
                                    <h3 class="items-title">
                                        <i class="fas fa-list"></i> ORDER ITEMS (<?php echo $order['item_count']; ?> items)
                                    </h3>
                                    
                                    <?php if (isset($grouped_items[$order['id']])): ?>
                                        <?php foreach ($grouped_items[$order['id']] as $item): ?>
                                            <div class="item-row">
                                                <div class="item-name">
                                                    <i class="fas fa-utensils"></i> <?php echo htmlspecialchars($item['item_name'] ?? 'Item'); ?>
                                                </div>
                                                <div class="item-quantity">
                                                    <?php echo $item['quantity']; ?>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="order-actions">
                                    <?php if ($order['status'] == 'placed' || $order['status'] == 'pending'): ?>
                                        <button class="status-btn btn-cooking" onclick="updateOrderStatus(<?php echo $order['id']; ?>, 'cooking')">
                                            <i class="fas fa-fire"></i> START COOKING
                                        </button>
                                    <?php endif; ?>
                                    
                                    <?php if ($order['status'] == 'cooking'): ?>
                                        <button class="status-btn btn-ready" onclick="updateOrderStatus(<?php echo $order['id']; ?>, 'served')">
                                            <i class="fas fa-check"></i> ORDER READY
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <!-- Refresh Button -->
    <button class="refresh-btn" onclick="refreshPage()" title="Refresh Orders">
        <i class="fas fa-sync-alt"></i>
    </button>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Update current time
        function updateTime() {
            const now = new Date();
            const timeString = now.toLocaleTimeString('en-US', {
                hour12: false,
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit'
            });
            document.getElementById('currentTime').textContent = timeString;
        }

        // Update time every second
        setInterval(updateTime, 1000);
        updateTime(); // Initial call

        // Auto-refresh page every 30 seconds
        setInterval(function() {
            location.reload();
        }, 30000);

        // Manual refresh
        function refreshPage() {
            location.reload();
        }

        // Update order status
        async function updateOrderStatus(orderId, newStatus) {
            try {
                const response = await fetch('backend/api/orders.php', {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        order_id: orderId,
                        status: newStatus
                    })
                });

                const result = await response.json();
                
                if (result.success) {
                    // Show success message
                    showNotification('Order status updated successfully!', 'success');
                    
                    // Refresh page after a short delay
                    setTimeout(() => {
                        location.reload();
                    }, 1000);
                } else {
                    showNotification('Failed to update order status: ' + result.message, 'error');
                }
            } catch (error) {
                showNotification('Error updating order status: ' + error.message, 'error');
            }
        }

        // Show notification
        function showNotification(message, type) {
            const notification = document.createElement('div');
            notification.className = `alert alert-${type === 'success' ? 'success' : 'danger'} alert-dismissible fade show position-fixed`;
            notification.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
            notification.innerHTML = `
                <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-triangle'}"></i>
                ${message}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            `;
            
            document.body.appendChild(notification);
            
            // Auto-remove after 3 seconds
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 3000);
        }
    </script>
</body>
</html>
