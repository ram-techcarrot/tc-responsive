<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Handle order placement
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!$input) {
            throw new Exception('Invalid JSON data');
        }
        
        // Validate required fields
        $required_fields = ['customer_name', 'customer_mobile', 'total_amount', 'items'];
        foreach ($required_fields as $field) {
            if (!isset($input[$field])) {
                throw new Exception("Missing required field: $field");
            }
        }
        
        // Generate unique short 4-digit order number
        do {
            $order_number = str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT);
            $check_query = "SELECT id FROM orders WHERE order_number = :order_number";
            $check_stmt = $db->prepare($check_query);
            $check_stmt->bindParam(':order_number', $order_number);
            $check_stmt->execute();
        } while ($check_stmt->fetch());
        
        // Get table ID if table number provided
        $table_id = null;
        if (!empty($input['table_number'])) {
            $query = "SELECT id FROM tables WHERE table_number = :table_number";
            $stmt = $db->prepare($query);
            $stmt->bindParam(':table_number', $input['table_number']);
            $stmt->execute();
            $table = $stmt->fetch();
            if ($table) {
                $table_id = $table['id'];
            }
        }
        
        // Insert order
        $query = "INSERT INTO orders (order_number, customer_name, customer_mobile, table_id, 
                  status, subtotal, gst_rate, gst_amount, total_amount, notes, placed_at) 
                  VALUES (:order_number, :customer_name, :customer_mobile, :table_id, 
                  'placed', :subtotal, :gst_rate, :gst_amount, :total_amount, :notes, NOW())";
        
        $stmt = $db->prepare($query);
        $stmt->bindParam(':order_number', $order_number);
        $stmt->bindParam(':customer_name', $input['customer_name']);
        $stmt->bindParam(':customer_mobile', $input['customer_mobile']);
        $stmt->bindParam(':table_id', $table_id);
        $stmt->bindParam(':subtotal', $input['subtotal']);
        $stmt->bindParam(':gst_rate', $input['gst_rate']);
        $stmt->bindParam(':gst_amount', $input['gst_amount']);
        $stmt->bindParam(':total_amount', $input['total_amount']);
        $stmt->bindParam(':notes', $input['notes']);
        
        if (!$stmt->execute()) {
            throw new Exception('Failed to create order');
        }
        
        $order_id = $db->lastInsertId();
        
        // Insert order items
        foreach ($input['items'] as $item) {
            $unit_price = $item['price'];
            $total_price = $unit_price * $item['quantity'];
            
            $query = "INSERT INTO order_items (order_id, menu_item_id, item_name, quantity, unit_price, total_price, notes) 
                      VALUES (:order_id, :menu_item_id, :item_name, :quantity, :unit_price, :total_price, :notes)";
            $stmt = $db->prepare($query);
            $notes = $item['notes'] ?? null;
            $stmt->bindParam(':order_id', $order_id);
            $stmt->bindParam(':menu_item_id', $item['menu_item_id']);
            $stmt->bindParam(':item_name', $item['item_name']);
            $stmt->bindParam(':quantity', $item['quantity']);
            $stmt->bindParam(':unit_price', $unit_price);
            $stmt->bindParam(':total_price', $total_price);
            $stmt->bindParam(':notes', $notes);
            $stmt->execute();
        }
        
        echo json_encode([
            'success' => true,
            'message' => 'Order placed successfully',
            'order_number' => $order_number,
            'order_id' => $order_id
        ]);
        
    } elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
        // Handle order status check
        $order_number = $_GET['order_number'] ?? '';
        
        if (empty($order_number)) {
            throw new Exception('Order number is required');
        }
        
        $query = "SELECT o.*, t.table_number FROM orders o 
                  LEFT JOIN tables t ON o.table_id = t.id 
                  WHERE o.order_number = :order_number";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':order_number', $order_number);
        $stmt->execute();
        $order = $stmt->fetch();
        
        if (!$order) {
            throw new Exception('Order not found');
        }
        
        // Get order items
        $query = "SELECT oi.*, mi.name as item_name FROM order_items oi 
                  LEFT JOIN menu_items mi ON oi.menu_item_id = mi.id 
                  WHERE oi.order_id = :order_id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':order_id', $order['id']);
        $stmt->execute();
        $items = $stmt->fetchAll();
        
        echo json_encode([
            'success' => true,
            'order' => $order,
            'items' => $items
        ]);
        
    } elseif ($_SERVER['REQUEST_METHOD'] === 'PUT') {
        // Handle PUT request - update order status
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!$input) {
            throw new Exception('Invalid JSON data');
        }
        
        if (!isset($input['order_id']) || !isset($input['status'])) {
            throw new Exception('Missing required fields: order_id and status');
        }
        
        $order_id = $input['order_id'];
        $status = $input['status'];
        
        // Validate status
        $valid_statuses = ['placed', 'pending', 'cooking', 'served', 'completed', 'paid'];
        if (!in_array($status, $valid_statuses)) {
            throw new Exception('Invalid status. Valid statuses: ' . implode(', ', $valid_statuses));
        }
        
        // Update order status
        $query = "UPDATE orders SET status = :status, updated_at = NOW() WHERE id = :order_id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':status', $status);
        $stmt->bindParam(':order_id', $order_id);
        
        if ($stmt->execute()) {
            echo json_encode([
                'success' => true,
                'message' => 'Order status updated successfully'
            ]);
        } else {
            throw new Exception('Failed to update order status');
        }
        
    } else {
        throw new Exception('Method not allowed');
    }
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>