<?php
require_once 'backend/config/database.php';

$database = new Database();
$db = $database->getConnection();

echo "<!DOCTYPE html><html><head><title>Update Categories to SVG</title>";
echo "<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css' rel='stylesheet'>";
echo "<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css'>";
echo "</head><body><div class='container mt-5'>";
echo "<h1><i class='fas fa-sync-alt'></i> Update Categories to Use SVG Icons</h1>";

try {
    // Get all categories
    $query = "SELECT * FROM categories ORDER BY name";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<h3>Current Categories:</h3>";
    echo "<div class='row'>";
    
    $updated_count = 0;
    foreach ($categories as $category) {
        echo "<div class='col-md-4 mb-3'>";
        echo "<div class='card'>";
        echo "<div class='card-body'>";
        echo "<h5 class='card-title'>" . htmlspecialchars($category['name']) . "</h5>";
        echo "<p class='card-text'>";
        echo "<strong>Current Icon:</strong> " . htmlspecialchars($category['icon']) . "<br>";
        
        // Map FontAwesome classes to SVG files
        $icon_mapping = [
            'fas fa-tea' => 'Tea.svg',
            'fas fa-coffee' => 'Coffee.svg',
            'fas fa-lemon' => 'Juice.svg',
            'fas fa-water' => 'Water.svg',
            'fas fa-soda-bottle' => 'Soft Drink.svg',
            'fas fa-cookie-bite' => 'Snacks.svg',
            'fa fa-tea' => 'Tea.svg',
            'fa fa-coffee' => 'Coffee.svg',
            'fa fa-lemon' => 'Juice.svg',
            'fa fa-water' => 'Water.svg',
            'fa fa-soda-bottle' => 'Soft Drink.svg',
            'fa fa-cookie-bite' => 'Snacks.svg',
        ];
        
        $new_icon = $category['icon'];
        if (isset($icon_mapping[$category['icon']])) {
            $new_icon = $icon_mapping[$category['icon']];
            echo "<strong>New Icon:</strong> " . htmlspecialchars($new_icon) . "<br>";
            
            // Update the category
            $update_query = "UPDATE categories SET icon = :new_icon WHERE id = :id";
            $update_stmt = $db->prepare($update_query);
            $update_stmt->bindParam(':new_icon', $new_icon);
            $update_stmt->bindParam(':id', $category['id']);
            
            if ($update_stmt->execute()) {
                echo "<span class='badge bg-success'>Updated</span><br>";
                $updated_count++;
            } else {
                echo "<span class='badge bg-danger'>Failed</span><br>";
            }
        } else {
            echo "<span class='badge bg-info'>No change needed</span><br>";
        }
        
        echo "<strong>Sort Order:</strong> " . $category['sort_order'] . "<br>";
        echo "<strong>Active:</strong> " . ($category['is_active'] ? 'Yes' : 'No');
        echo "</p>";
        echo "</div></div></div>";
    }
    echo "</div>";
    
    echo "<div class='alert alert-success mt-4'>";
    echo "<strong>Summary:</strong> Updated $updated_count categories to use SVG icons.";
    echo "</div>";
    
    // Show updated categories
    echo "<h3>Updated Categories:</h3>";
    $query = "SELECT * FROM categories ORDER BY name";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $updated_categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<div class='row'>";
    foreach ($updated_categories as $category) {
        echo "<div class='col-md-3 mb-2'>";
        echo "<div class='d-flex align-items-center'>";
        if ($category['icon']) {
            echo "<img src='image/" . htmlspecialchars($category['icon']) . "' alt='" . htmlspecialchars($category['name']) . "' style='width: 20px; height: 20px; margin-right: 8px;'>";
        }
        echo "<span>" . htmlspecialchars($category['name']) . "</span>";
        echo "</div></div>";
    }
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div class='alert alert-danger'>Error: " . htmlspecialchars($e->getMessage()) . "</div>";
}

echo "<div class='mt-4'>";
echo "<a href='frontend/ordering.php' class='btn btn-primary'>Test Frontend Ordering</a> ";
echo "<a href='ordering.php' class='btn btn-secondary'>Test Main Ordering</a> ";
echo "<a href='backend/admin/categories.php' class='btn btn-info'>Manage Categories</a>";
echo "</div>";
echo "</div></body></html>";
?>
