<?php
require_once '../auth/check_auth.php';
require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

// Get date range
$start_date = $_GET['start_date'] ?? date('Y-m-d');
$end_date = $_GET['end_date'] ?? date('Y-m-d');

// Daily sales report
$query = "SELECT DATE(placed_at) as date, 
          COUNT(*) as total_orders,
          SUM(CASE WHEN status IN ('served', 'completed', 'paid') THEN total_amount ELSE 0 END) as revenue,
          SUM(CASE WHEN status = 'served' THEN 1 ELSE 0 END) as served_orders
          FROM orders 
          WHERE DATE(placed_at) BETWEEN :start_date AND :end_date
          GROUP BY DATE(placed_at) 
          ORDER BY date DESC";
$stmt = $db->prepare($query);
$stmt->bindParam(':start_date', $start_date);
$stmt->bindParam(':end_date', $end_date);
$stmt->execute();
$daily_reports = $stmt->fetchAll();

// Top selling items
$query = "SELECT mi.name, SUM(oi.quantity) as total_quantity, SUM(oi.total_price) as total_revenue
          FROM order_items oi
          LEFT JOIN menu_items mi ON oi.menu_item_id = mi.id
          LEFT JOIN orders o ON oi.order_id = o.id
          WHERE DATE(o.placed_at) BETWEEN :start_date AND :end_date
          GROUP BY mi.id, mi.name
          ORDER BY total_quantity DESC
          LIMIT 10";
$stmt = $db->prepare($query);
$stmt->bindParam(':start_date', $start_date);
$stmt->bindParam(':end_date', $end_date);
$stmt->execute();
$top_items = $stmt->fetchAll();

// Category performance
$query = "SELECT c.name as category_name, SUM(oi.quantity) as total_quantity, SUM(oi.total_price) as total_revenue
          FROM order_items oi
          LEFT JOIN menu_items mi ON oi.menu_item_id = mi.id
          LEFT JOIN categories c ON mi.category_id = c.id
          LEFT JOIN orders o ON oi.order_id = o.id
          WHERE DATE(o.placed_at) BETWEEN :start_date AND :end_date
          GROUP BY c.id, c.name
          ORDER BY total_revenue DESC";
$stmt = $db->prepare($query);
$stmt->bindParam(':start_date', $start_date);
$stmt->bindParam(':end_date', $end_date);
$stmt->execute();
$category_performance = $stmt->fetchAll();

// Summary statistics
$query = "SELECT 
          COUNT(*) as total_orders,
          SUM(CASE WHEN status IN ('served', 'completed', 'paid') THEN total_amount ELSE 0 END) as total_revenue,
          SUM(CASE WHEN status = 'served' THEN 1 ELSE 0 END) as served_orders,
          AVG(CASE WHEN status IN ('served', 'completed', 'paid') THEN total_amount ELSE NULL END) as avg_order_value
          FROM orders 
          WHERE DATE(placed_at) BETWEEN :start_date AND :end_date";
$stmt = $db->prepare($query);
$stmt->bindParam(':start_date', $start_date);
$stmt->bindParam(':end_date', $end_date);
$stmt->execute();
$summary = $stmt->fetch();
?>

<?php include 'includes/header.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .sidebar {
            min-height: 100vh;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            border-radius: 8px;
            margin: 2px 0;
        }
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            color: white;
            background: rgba(255,255,255,0.1);
        }
        .stat-card {
            background: white;
            border-radius: 15px;
            padding: 1.5rem;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            border-left: 4px solid;
        }
        .stat-card.primary { border-left-color: #007bff; }
        .stat-card.success { border-left-color: #28a745; }
        .stat-card.warning { border-left-color: #ffc107; }
        .stat-card.info { border-left-color: #17a2b8; }
        .stat-number {
            font-size: 2rem;
            font-weight: 700;
            margin: 0;
        }
        .stat-label {
            color: #6c757d;
            font-size: 0.9rem;
            margin: 0;
        }
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.3);
        }
        .chart-container {
            position: relative;
            height: 300px;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <?php include 'includes/sidebar.php'; ?>
            
            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2><i class="fas fa-chart-bar"></i> Reports & Analytics</h2>
                    <div class="text-muted">
                        <?php echo date('d M Y', strtotime($start_date)); ?> - <?php echo date('d M Y', strtotime($end_date)); ?>
                    </div>
                </div>
                
                <!-- Date Range Filter -->
                <div class="card mb-4">
                    <div class="card-body">
                        <form method="GET" class="row g-3">
                            <div class="col-md-4">
                                <label for="start_date" class="form-label">Start Date</label>
                                <input type="date" class="form-control" name="start_date" id="start_date" 
                                       value="<?php echo htmlspecialchars($start_date); ?>">
                            </div>
                            <div class="col-md-4">
                                <label for="end_date" class="form-label">End Date</label>
                                <input type="date" class="form-control" name="end_date" id="end_date" 
                                       value="<?php echo htmlspecialchars($end_date); ?>">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">&nbsp;</label>
                                <div class="d-grid">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-filter"></i> Generate Report
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                
                <!-- Summary Statistics -->
                <div class="row mb-4">
                    <div class="col-md-3 mb-3">
                        <div class="stat-card primary">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <p class="stat-number text-primary"><?php echo $summary['total_orders']; ?></p>
                                    <p class="stat-label">Total Orders</p>
                                </div>
                                <i class="fas fa-shopping-cart fa-2x text-primary"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 mb-3">
                        <div class="stat-card success">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <p class="stat-number text-success">₹<?php echo number_format($summary['total_revenue'], 2); ?></p>
                                    <p class="stat-label">Total Revenue</p>
                                </div>
                                <i class="fas fa-rupee-sign fa-2x text-success"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 mb-3">
                        <div class="stat-card warning">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <p class="stat-number text-warning"><?php echo $summary['served_orders']; ?></p>
                                    <p class="stat-label">Served Orders</p>
                                </div>
                                <i class="fas fa-check-circle fa-2x text-warning"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 mb-3">
                        <div class="stat-card info">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <p class="stat-number text-info">₹<?php echo number_format($summary['avg_order_value'], 2); ?></p>
                                    <p class="stat-label">Avg Order Value</p>
                                </div>
                                <i class="fas fa-chart-line fa-2x text-info"></i>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <!-- Daily Sales Chart -->
                    <div class="col-lg-8 mb-4">
                        <div class="card">
                            <div class="card-header">
                                <h5><i class="fas fa-chart-line"></i> Daily Sales</h5>
                            </div>
                            <div class="card-body">
                                <div class="chart-container">
                                    <canvas id="salesChart"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Top Items -->
                    <div class="col-lg-4 mb-4">
                        <div class="card">
                            <div class="card-header">
                                <h5><i class="fas fa-star"></i> Top Selling Items</h5>
                            </div>
                            <div class="card-body">
                                <?php if (empty($top_items)): ?>
                                    <p class="text-muted text-center">No data available</p>
                                <?php else: ?>
                                    <?php foreach ($top_items as $index => $item): ?>
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <div>
                                                <strong><?php echo $index + 1; ?>.</strong> <?php echo htmlspecialchars($item['name']); ?>
                                                <br>
                                                <small class="text-muted"><?php echo $item['total_quantity']; ?> sold</small>
                                            </div>
                                            <div class="text-end">
                                                <strong class="text-success">₹<?php echo number_format($item['total_revenue'], 2); ?></strong>
                                            </div>
                                        </div>
                                        <?php if ($index < count($top_items) - 1): ?>
                                            <hr class="my-2">
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <!-- Category Performance -->
                    <div class="col-lg-6 mb-4">
                        <div class="card">
                            <div class="card-header">
                                <h5><i class="fas fa-chart-pie"></i> Category Performance</h5>
                            </div>
                            <div class="card-body">
                                <div class="chart-container">
                                    <canvas id="categoryChart"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Daily Report Table -->
                    <div class="col-lg-6 mb-4">
                        <div class="card">
                            <div class="card-header">
                                <h5><i class="fas fa-table"></i> Daily Report</h5>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-sm">
                                        <thead>
                                            <tr>
                                                <th>Date</th>
                                                <th>Orders</th>
                                                <th>Revenue</th>
                                                <th>Served</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($daily_reports as $report): ?>
                                                <tr>
                                                    <td><?php echo date('d M', strtotime($report['date'])); ?></td>
                                                    <td><?php echo $report['total_orders']; ?></td>
                                                    <td>₹<?php echo number_format($report['revenue'], 2); ?></td>
                                                    <td><?php echo $report['served_orders']; ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Daily Sales Chart
        const salesData = <?php echo json_encode($daily_reports); ?>;
        const salesCtx = document.getElementById('salesChart').getContext('2d');
        
        new Chart(salesCtx, {
            type: 'line',
            data: {
                labels: salesData.map(item => new Date(item.date).toLocaleDateString()),
                datasets: [{
                    label: 'Revenue (₹)',
                    data: salesData.map(item => item.revenue),
                    borderColor: '#667eea',
                    backgroundColor: 'rgba(102, 126, 234, 0.1)',
                    tension: 0.4,
                    fill: true
                }, {
                    label: 'Orders',
                    data: salesData.map(item => item.total_orders),
                    borderColor: '#28a745',
                    backgroundColor: 'rgba(40, 167, 69, 0.1)',
                    tension: 0.4,
                    yAxisID: 'y1'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        type: 'linear',
                        display: true,
                        position: 'left',
                        title: {
                            display: true,
                            text: 'Revenue (₹)'
                        }
                    },
                    y1: {
                        type: 'linear',
                        display: true,
                        position: 'right',
                        title: {
                            display: true,
                            text: 'Orders'
                        },
                        grid: {
                            drawOnChartArea: false,
                        },
                    }
                }
            }
        });
        
        // Category Performance Chart
        const categoryData = <?php echo json_encode($category_performance); ?>;
        const categoryCtx = document.getElementById('categoryChart').getContext('2d');
        
        new Chart(categoryCtx, {
            type: 'doughnut',
            data: {
                labels: categoryData.map(item => item.category_name),
                datasets: [{
                    data: categoryData.map(item => item.total_revenue),
                    backgroundColor: [
                        '#667eea',
                        '#764ba2',
                        '#f093fb',
                        '#f5576c',
                        '#4facfe',
                        '#00f2fe',
                        '#43e97b',
                        '#38f9d7'
                    ]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
    </script>
    <?php include 'includes/footer.php'; ?>
