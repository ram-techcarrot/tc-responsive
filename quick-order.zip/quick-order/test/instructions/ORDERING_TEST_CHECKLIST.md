# 🛒 Ordering Page Test Checklist

## ✅ **Pre-Test Setup**

### **1. Database Setup**
- [ ] Run `fix_orders.php` to ensure tables exist
- [ ] Run `add_sample_menu.php` to add menu items
- [ ] Verify database connection works

### **2. File Verification**
- [ ] `ordering.php` exists and loads without errors
- [ ] `backend/api/menu.php` returns JSON data
- [ ] `backend/api/orders.php` responds to requests
- [ ] CSS and image files are accessible

---

## 🧪 **Manual Testing Steps**

### **Step 1: Page Load Test**
**URL**: `http://localhost/quick-order/ordering.php`

**Expected Results:**
- [ ] Page loads without errors
- [ ] SOBHA logo displays correctly
- [ ] Search bar is visible and functional
- [ ] Categories section loads with data
- [ ] Menu items section loads with data
- [ ] Cart section shows "Your cart is empty"

### **Step 2: Menu Loading Test**
**Actions:**
- [ ] Categories load from database (Tea, Coffee, Juice, etc.)
- [ ] Menu items display with names, descriptions, prices
- [ ] Prices show in Rs. currency format
- [ ] "Add" buttons are clickable

**Expected Results:**
- [ ] At least 3-5 categories visible
- [ ] At least 10-15 menu items visible
- [ ] All prices formatted as "Rs. X.XX"
- [ ] Items have proper descriptions

### **Step 3: Category Filtering Test**
**Actions:**
- [ ] Click on "Tea" category
- [ ] Click on "Coffee" category
- [ ] Click on "Snacks" category

**Expected Results:**
- [ ] Category highlights when clicked
- [ ] Menu items filter to show only selected category
- [ ] Items change when switching categories

### **Step 4: Search Functionality Test**
**Actions:**
- [ ] Type "tea" in search box
- [ ] Type "chicken" in search box
- [ ] Clear search box

**Expected Results:**
- [ ] Search filters items in real-time
- [ ] Only matching items show
- [ ] Clearing search shows all items again

### **Step 5: Add to Cart Test**
**Actions:**
- [ ] Click "Add" button on Black Tea
- [ ] Click "Add" button on Chicken Sandwich
- [ ] Click "Add" button on French Fries

**Expected Results:**
- [ ] Items appear in cart on right side
- [ ] Cart shows item names and quantities
- [ ] Cart shows individual item totals
- [ ] Order summary appears with totals

### **Step 6: Cart Management Test**
**Actions:**
- [ ] Use "+" button to increase quantity
- [ ] Use "-" button to decrease quantity
- [ ] Click trash icon to remove item

**Expected Results:**
- [ ] Quantities update in real-time
- [ ] Totals recalculate automatically
- [ ] Items can be removed completely
- [ ] Cart updates immediately

### **Step 7: Order Summary Test**
**Expected Results:**
- [ ] Subtotal shows sum of item totals
- [ ] GST (5%) calculated correctly
- [ ] Total = Subtotal + GST
- [ ] All amounts in Rs. currency

### **Step 8: Place Order Test**
**Actions:**
- [ ] Click "Place Order" button
- [ ] Fill in customer details:
  - Name: "Test Customer"
  - Mobile: "+971501234567"
  - Table: "T01"
  - Notes: "Test order"

**Expected Results:**
- [ ] Modal opens with customer form
- [ ] Form validation works (required fields)
- [ ] Order submits successfully
- [ ] Redirects to order-success.php

### **Step 9: Order Success Test**
**Expected Results:**
- [ ] Success page loads with order details
- [ ] Order information table displays correctly
- [ ] Order items table shows all items
- [ ] Order summary shows correct totals
- [ ] Order number is generated

### **Step 10: Admin Panel Verification**
**Actions:**
- [ ] Login to admin panel (admin/admin123)
- [ ] Go to Orders page
- [ ] Check if new order appears

**Expected Results:**
- [ ] Order appears in orders list
- [ ] Order status is "placed"
- [ ] Order details match what was placed
- [ ] Order can be updated by admin

---

## 🐛 **Common Issues & Solutions**

### **Issue: Menu items not loading**
**Solutions:**
- Check if `add_sample_menu.php` was run
- Verify database connection
- Check browser console for JavaScript errors

### **Issue: Cart not updating**
**Solutions:**
- Check JavaScript console for errors
- Verify all required files are loaded
- Test in different browser

### **Issue: Order not placing**
**Solutions:**
- Check if `backend/api/orders.php` is accessible
- Verify database tables exist
- Check form validation

### **Issue: Success page not loading**
**Solutions:**
- Check if order was created in database
- Verify localStorage has order number
- Check order-success.php file exists

---

## 📊 **Test Results Summary**

### **✅ Pass Criteria:**
- [ ] Page loads without errors
- [ ] Menu data loads from database
- [ ] Cart functionality works
- [ ] Order placement succeeds
- [ ] Success page displays correctly
- [ ] Order appears in admin panel

### **❌ Fail Criteria:**
- [ ] Any JavaScript errors
- [ ] API endpoints not responding
- [ ] Cart not updating
- [ ] Order placement failing
- [ ] Success page not loading

---

## 🚀 **Quick Test Commands**

```bash
# Test ordering page
php -f ordering.php

# Test menu API
php -f backend/api/menu.php

# Test orders API
php -f backend/api/orders.php

# Run comprehensive test
php -f test_ordering_page.php
```

---

## 📝 **Test Notes**

**Browser Testing:**
- Test in Chrome, Firefox, Safari
- Test on mobile devices
- Test with different screen sizes

**Data Testing:**
- Test with different item combinations
- Test with large quantities
- Test with special characters in names

**Performance Testing:**
- Check page load speed
- Test with slow internet connection
- Monitor browser console for errors

---

**The ordering page should provide a smooth, intuitive experience for customers to browse menu items, manage their cart, and place orders successfully!** 🎉
