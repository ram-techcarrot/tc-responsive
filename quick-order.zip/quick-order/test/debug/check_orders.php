<?php
require_once 'backend/config/database.php';

$database = new Database();
$db = $database->getConnection();

echo "<!DOCTYPE html>";
echo "<html><head><title>Check Orders</title>";
echo "<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css' rel='stylesheet'>";
echo "<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css'>";
echo "</head><body class='bg-light'>";

echo "<div class='container mt-5'>";
echo "<div class='row justify-content-center'>";
echo "<div class='col-md-10'>";
echo "<div class='card'>";
echo "<div class='card-header'>";
echo "<h3><i class='fas fa-search'></i> Orders Database Check</h3>";
echo "</div>";
echo "<div class='card-body'>";

try {
    // Check if orders table exists
    echo "<h5>1. Database Tables Check</h5>";
    $query = "SHOW TABLES LIKE 'orders'";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $table_exists = $stmt->fetch();
    
    if ($table_exists) {
        echo "<div class='alert alert-success'>";
        echo "<i class='fas fa-check-circle'></i> Orders table exists";
        echo "</div>";
    } else {
        echo "<div class='alert alert-danger'>";
        echo "<i class='fas fa-times-circle'></i> Orders table does not exist!";
        echo "</div>";
    }
    
    // Check orders count
    echo "<h5>2. Orders Count</h5>";
    $query = "SELECT COUNT(*) as count FROM orders";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $result = $stmt->fetch();
    
    echo "<div class='alert alert-info'>";
    echo "<i class='fas fa-info-circle'></i> Total orders in database: <strong>$result[count]</strong>";
    echo "</div>";
    
    // Check order_items count
    echo "<h5>3. Order Items Count</h5>";
    $query = "SELECT COUNT(*) as count FROM order_items";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $result = $stmt->fetch();
    
    echo "<div class='alert alert-info'>";
    echo "<i class='fas fa-info-circle'></i> Total order items in database: <strong>$result[count]</strong>";
    echo "</div>";
    
    // Check menu_items count
    echo "<h5>4. Menu Items Count</h5>";
    $query = "SELECT COUNT(*) as count FROM menu_items";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $result = $stmt->fetch();
    
    echo "<div class='alert alert-info'>";
    echo "<i class='fas fa-info-circle'></i> Total menu items in database: <strong>$result[count]</strong>";
    echo "</div>";
    
    // Check categories count
    echo "<h5>5. Categories Count</h5>";
    $query = "SELECT COUNT(*) as count FROM categories";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $result = $stmt->fetch();
    
    echo "<div class='alert alert-info'>";
    echo "<i class='fas fa-info-circle'></i> Total categories in database: <strong>$result[count]</strong>";
    echo "</div>";
    
    // Show recent orders if any
    echo "<h5>6. Recent Orders</h5>";
    $query = "SELECT * FROM orders ORDER BY placed_at DESC LIMIT 5";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $orders = $stmt->fetchAll();
    
    if ($orders) {
        echo "<div class='table-responsive'>";
        echo "<table class='table table-striped'>";
        echo "<thead><tr><th>Order #</th><th>Customer</th><th>Table</th><th>Status</th><th>Amount</th><th>Placed At</th></tr></thead>";
        echo "<tbody>";
        foreach ($orders as $order) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($order['order_number']) . "</td>";
            echo "<td>" . htmlspecialchars($order['customer_name']) . "</td>";
            echo "<td>" . htmlspecialchars($order['table_number']) . "</td>";
            echo "<td><span class='badge bg-primary'>" . htmlspecialchars($order['status']) . "</span></td>";
            echo "<td>Rs. " . number_format($order['total_amount'], 2) . "</td>";
            echo "<td>" . htmlspecialchars($order['placed_at']) . "</td>";
            echo "</tr>";
        }
        echo "</tbody></table>";
        echo "</div>";
    } else {
        echo "<div class='alert alert-warning'>";
        echo "<i class='fas fa-exclamation-triangle'></i> No orders found in database";
        echo "</div>";
    }
    
} catch (Exception $e) {
    echo "<div class='alert alert-danger'>";
    echo "<h5><i class='fas fa-exclamation-triangle'></i> Error</h5>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
}

echo "<div class='text-center mt-4'>";
echo "<a href='add_dummy_orders.php' class='btn btn-primary' target='_blank'>";
echo "<i class='fas fa-plus'></i> Add Dummy Orders";
echo "</a>";
echo "<a href='backend/admin/orders.php' class='btn btn-success ms-2' target='_blank'>";
echo "<i class='fas fa-shopping-cart'></i> View Orders Page";
echo "</a>";
echo "<a href='quick-access.html' class='btn btn-secondary ms-2'>";
echo "<i class='fas fa-home'></i> Quick Access";
echo "</a>";
echo "</div>";

echo "</div></div></div></div></div>";

echo "<script src='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js'></script>";
echo "</body></html>";
?>
