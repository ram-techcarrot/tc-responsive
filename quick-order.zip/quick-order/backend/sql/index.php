<?php
/**
 * SQL Directory Index
 * Access denied - SQL files should not be accessible via web
 */

http_response_code(403);
header('Content-Type: text/html');
?>
<!DOCTYPE html>
<html>
<head>
    <title>Access Denied</title>
    <style>
        body { font-family: Arial, sans-serif; text-align: center; padding: 50px; }
        .error { color: #d32f2f; }
    </style>
</head>
<body>
    <h1 class="error">403 - Access Denied</h1>
    <p>SQL files are not accessible via web browser.</p>
    <p><a href="../auth/login.php">← Back to Login</a></p>
</body>
</html>
