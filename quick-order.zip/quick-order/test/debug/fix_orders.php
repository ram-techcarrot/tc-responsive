<?php
require_once 'backend/config/database.php';

$database = new Database();
$db = $database->getConnection();

echo "<!DOCTYPE html>";
echo "<html><head><title>Fix Orders</title>";
echo "<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css' rel='stylesheet'>";
echo "</head><body class='bg-light'>";

echo "<div class='container mt-5'>";
echo "<div class='row justify-content-center'>";
echo "<div class='col-md-10'>";
echo "<div class='card'>";
echo "<div class='card-header'>";
echo "<h3><i class='fas fa-wrench'></i> Fix Orders Database</h3>";
echo "</div>";
echo "<div class='card-body'>";

try {
    // First, let's check what tables exist
    echo "<h5>1. Checking Database Structure</h5>";
    $query = "SHOW TABLES";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    echo "<div class='alert alert-info'>";
    echo "<strong>Tables found:</strong> " . implode(', ', $tables);
    echo "</div>";
    
    // Check if we need to create tables first
    if (!in_array('tables', $tables)) {
        echo "<div class='alert alert-warning'>";
        echo "<i class='fas fa-exclamation-triangle'></i> Tables table missing. Creating it...";
        echo "</div>";
        
        $create_tables = "CREATE TABLE IF NOT EXISTS `tables` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `table_number` varchar(20) NOT NULL UNIQUE,
            `qr_code` varchar(255) DEFAULT NULL,
            `is_active` tinyint(1) DEFAULT 1,
            `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
            `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`)
        )";
        
        $db->exec($create_tables);
        echo "<div class='alert alert-success'>Tables table created!</div>";
    }
    
    // Add some sample tables
    echo "<h5>2. Adding Sample Tables</h5>";
    $table_numbers = ['T01', 'T02', 'T03', 'T04', 'T05', 'T06', 'T07', 'T08', 'T09', 'T10'];
    
    foreach ($table_numbers as $table_num) {
        $query = "INSERT IGNORE INTO tables (table_number) VALUES (:table_number)";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':table_number', $table_num);
        $stmt->execute();
    }
    echo "<div class='alert alert-success'>Sample tables added!</div>";
    
    // Clear existing orders
    echo "<h5>3. Clearing Existing Orders</h5>";
    $db->exec("DELETE FROM order_items");
    $db->exec("DELETE FROM orders");
    echo "<div class='alert alert-info'>Existing orders cleared.</div>";
    
    // Add sample orders with correct structure
    echo "<h5>4. Adding Sample Orders</h5>";
    
    $orders = [
        ['customer_name' => 'John Smith', 'customer_mobile' => '+971501234567', 'table_number' => 'T01', 'status' => 'placed', 'total_amount' => 25.00],
        ['customer_name' => 'Sarah Johnson', 'customer_mobile' => '+971502345678', 'table_number' => 'T02', 'status' => 'pending', 'total_amount' => 30.00],
        ['customer_name' => 'Ahmed Al-Rashid', 'customer_mobile' => '+971503456789', 'table_number' => 'T03', 'status' => 'cooking', 'total_amount' => 35.00],
        ['customer_name' => 'Maria Garcia', 'customer_mobile' => '+971504567890', 'table_number' => 'T04', 'status' => 'served', 'total_amount' => 28.00],
        ['customer_name' => 'David Brown', 'customer_mobile' => '+971505678901', 'table_number' => 'T05', 'status' => 'completed', 'total_amount' => 32.00],
        ['customer_name' => 'Fatima Al-Zahra', 'customer_mobile' => '+971506789012', 'table_number' => 'T06', 'status' => 'paid', 'total_amount' => 40.00]
    ];
    
    $order_number = 1001;
    
    foreach ($orders as $order_data) {
        // Get table_id
        $query = "SELECT id FROM tables WHERE table_number = :table_number";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':table_number', $order_data['table_number']);
        $stmt->execute();
        $table = $stmt->fetch();
        
        if ($table) {
            $query = "INSERT INTO orders (order_number, customer_name, customer_mobile, table_id, 
                      status, total_amount, placed_at) 
                      VALUES (:order_number, :customer_name, :customer_mobile, :table_id, 
                      :status, :total_amount, NOW())";
            
            $stmt = $db->prepare($query);
            $stmt->bindParam(':order_number', $order_number);
            $stmt->bindParam(':customer_name', $order_data['customer_name']);
            $stmt->bindParam(':customer_mobile', $order_data['customer_mobile']);
            $stmt->bindParam(':table_id', $table['id']);
            $stmt->bindParam(':status', $order_data['status']);
            $stmt->bindParam(':total_amount', $order_data['total_amount']);
            
            if ($stmt->execute()) {
                echo "<div class='alert alert-success'>";
                echo "<i class='fas fa-check'></i> Order #$order_number added - " . $order_data['customer_name'] . " - " . $order_data['status'];
                echo "</div>";
                $order_number++;
            } else {
                echo "<div class='alert alert-danger'>";
                echo "<i class='fas fa-times'></i> Failed to add order #$order_number";
                echo "</div>";
            }
        } else {
            echo "<div class='alert alert-warning'>";
            echo "<i class='fas fa-exclamation-triangle'></i> Table " . $order_data['table_number'] . " not found";
            echo "</div>";
        }
    }
    
    // Verify orders were added
    echo "<h5>5. Verification</h5>";
    $query = "SELECT COUNT(*) as count FROM orders";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $result = $stmt->fetch();
    
    echo "<div class='alert alert-success'>";
    echo "<i class='fas fa-check-circle'></i> Total orders in database: " . $result['count'];
    echo "</div>";
    
    // Show sample orders
    $query = "SELECT o.*, t.table_number FROM orders o 
              LEFT JOIN tables t ON o.table_id = t.id 
              ORDER BY o.placed_at DESC LIMIT 3";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $orders = $stmt->fetchAll();
    
    echo "<h6>Sample Orders:</h6>";
    foreach ($orders as $order) {
        echo "<div class='alert alert-light'>";
        echo "<strong>Order #" . $order['order_number'] . "</strong> - " . $order['customer_name'] . " - Table " . $order['table_number'] . " - " . $order['status'] . " - Rs. " . number_format($order['total_amount'], 2);
        echo "</div>";
    }
    
} catch (Exception $e) {
    echo "<div class='alert alert-danger'>";
    echo "<h5><i class='fas fa-exclamation-triangle'></i> Error</h5>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
}

echo "<div class='text-center mt-4'>";
echo "<a href='backend/admin/orders.php' class='btn btn-primary' target='_blank'>";
echo "<i class='fas fa-shopping-cart'></i> View Orders Page";
echo "</a>";
echo "<a href='quick-access.html' class='btn btn-secondary ms-2'>";
echo "<i class='fas fa-home'></i> Quick Access";
echo "</a>";
echo "</div>";

echo "</div></div></div></div></div>";
echo "</body></html>";
?>
