<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Success - Sobha</title>
    
    <!-- Bootstrap 5 CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        body {
            background: #000;
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        /* Header styling */
        .ordering-header {
            background: linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%);
            padding: 1rem 0;
            border-bottom: 2px solid var(--sobha-gold, #D4AF37);
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
        }
        
        .logo-section {
            display: flex;
            align-items: center;
        }
        
        .logo-link {
            text-decoration: none;
            display: flex;
            align-items: center;
        }
        
        .sobha-logo {
            height: 40px;
            width: auto;
            filter: brightness(0) invert(1);
        }
        
        :root {
            --sobha-gold: #D4AF37;
            --sobha-dark: #1a1a1a;
        }
        .success-container {
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            margin: 50px auto;
            max-width: 800px;
            overflow: hidden;
        }
        .success-header {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            color: white;
            padding: 40px;
            text-align: center;
        }
        .success-icon {
            font-size: 4rem;
            margin-bottom: 20px;
        }
        .success-content {
            padding: 40px;
        }
        .order-details {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            margin: 20px 0;
        }
        .order-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 0;
            border-bottom: 1px solid #dee2e6;
        }
        .order-item:last-child {
            border-bottom: none;
        }
        .item-details {
            flex-grow: 1;
        }
        .item-name {
            font-weight: 600;
            color: #333;
        }
        .item-notes {
            font-size: 0.9rem;
            color: #666;
            font-style: italic;
        }
        .item-quantity {
            background: #007bff;
            color: white;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.9rem;
            margin-right: 10px;
        }
        .item-price {
            font-weight: 600;
            color: #28a745;
        }
        .total-section {
            background: #e9ecef;
            border-radius: 10px;
            padding: 20px;
            margin-top: 20px;
        }
        .total-row {
            display: flex;
            justify-content: space-between;
            margin: 10px 0;
        }
        .total-row.final {
            font-size: 1.2rem;
            font-weight: bold;
            color: #333;
            border-top: 2px solid #007bff;
            padding-top: 15px;
            margin-top: 15px;
        }
        .status-badge {
            display: inline-block;
            padding: 8px 16px;
            border-radius: 20px;
            font-weight: 600;
            margin: 10px 0;
        }
        .status-placed {
            background: #fff3cd;
            color: #856404;
        }
        .btn-custom {
            background: linear-gradient(135deg, #007bff 0%, #0056b3 100%);
            border: none;
            color: white;
            padding: 12px 30px;
            border-radius: 25px;
            font-weight: 600;
            text-decoration: none;
            display: inline-block;
            margin: 10px;
            transition: all 0.3s ease;
        }
        .btn-custom:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,123,255,0.3);
            color: white;
        }
    </style>
</head>
<body>
    <!-- Header Section -->
    <header class="ordering-header">
        <div class="container">
            <div class="row align-items-center">
                <!-- Logo Section -->
                <div class="col-auto">
                    <div class="logo-section">
                        <a href="index.php" class="logo-link">
                            <img src="image/sobha-logo.svg" alt="SOBHA Realty" class="sobha-logo">
                        </a>
                    </div>
                </div>
                
                <!-- Title Section -->
                <div class="col">
                    <div class="text-center">
                        <h1 class="mb-0" style="color: var(--sobha-gold); font-weight: 600; font-size: 1.5rem;">Order Success</h1>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <div class="container">
        <div class="success-container">
            <div class="success-header">
                <div class="success-icon">
                    <i class="fas fa-check-circle"></i>
                </div>
                <h1>Order Placed Successfully!</h1>
                <p class="mb-0">Thank you for your order. We'll prepare it right away.</p>
            </div>
            
            <div class="success-content">
                <div id="orderDetails">
                    <!-- Order details will be populated by JavaScript -->
                </div>
                
                <div class="text-center mt-4">
                    <a href="ordering.php" class="btn-custom">
                        <i class="fas fa-plus"></i> Place Another Order
                    </a>
                    <a href="index.html" class="btn-custom">
                        <i class="fas fa-home"></i> Back to Home
                    </a>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const orderNumber = localStorage.getItem('orderNumber');
            const orderStatus = localStorage.getItem('orderStatus');
            const orderData = localStorage.getItem('orderData');
            
            if (!orderNumber || !orderData) {
                document.getElementById('orderDetails').innerHTML = 
                    '<div class="alert alert-warning">No order data found. Please place an order first.</div>';
                return;
            }
            
            const order = JSON.parse(orderData);
            
            let html = `
                <div class="order-details">
                    <h3><i class="fas fa-receipt"></i> Order Details</h3>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <strong>Order Number:</strong> ${orderNumber}
                        </div>
                        <div class="col-md-6">
                            <strong>Customer:</strong> ${order.customer_name}
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <strong>Mobile:</strong> ${order.customer_mobile || 'Not provided'}
                        </div>
                        <div class="col-md-6">
                            <strong>Table:</strong> ${order.table_number}
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <strong>Order Time:</strong> ${new Date().toLocaleString()}
                        </div>
                        <div class="col-md-6">
                            <span class="status-badge status-${orderStatus}">
                                <i class="fas fa-clock"></i> ${orderStatus.charAt(0).toUpperCase() + orderStatus.slice(1)}
                            </span>
                        </div>
                    </div>
                </div>
                
                <div class="order-details">
                    <h4><i class="fas fa-list"></i> Order Items</h4>
            `;
            
            order.items.forEach(item => {
                html += `
                    <div class="order-item">
                        <div class="item-details">
                            <div class="item-name">${item.item_name}</div>
                            ${item.notes ? `<div class="item-notes">Note: ${item.notes}</div>` : ''}
                        </div>
                        <div class="d-flex align-items-center">
                            <span class="item-quantity">${item.quantity}</span>
                            <span class="item-price">Rs. ${(item.price * item.quantity).toFixed(2)}</span>
                        </div>
                    </div>
                `;
            });
            
            html += `
                </div>
                
                <div class="total-section">
                    <h4><i class="fas fa-calculator"></i> Bill Summary</h4>
                    <div class="total-row">
                        <span>Subtotal:</span>
                        <span>Rs. ${order.subtotal.toFixed(2)}</span>
                    </div>
                    <div class="total-row">
                        <span>GST (${(order.gst_rate * 100).toFixed(0)}%):</span>
                        <span>Rs. ${order.gst_amount.toFixed(2)}</span>
                    </div>
                    <div class="total-row final">
                        <span>Total Amount:</span>
                        <span>Rs. ${order.total_amount.toFixed(2)}</span>
                    </div>
                </div>
                
                <div class="alert alert-info mt-4">
                    <i class="fas fa-info-circle"></i>
                    <strong>Payment:</strong> Please pay at the counter when your order is ready.
                </div>
            `;
            
            document.getElementById('orderDetails').innerHTML = html;
        });
    </script>
</body>
</html>
