<?php
require_once 'backend/config/database.php';

$database = new Database();
$db = $database->getConnection();

// Sample categories based on the existing images
$categories = [
    ['name' => 'Tea', 'icon' => 'Tea.svg', 'sort_order' => 1],
    ['name' => 'Coffee', 'icon' => 'Coffee.svg', 'sort_order' => 2],
    ['name' => 'Juice', 'icon' => 'Juice.svg', 'sort_order' => 3],
    ['name' => 'Water', 'icon' => 'Water.svg', 'sort_order' => 4],
    ['name' => 'Soft Drinks', 'icon' => 'Soft Drink.svg', 'sort_order' => 5],
    ['name' => 'Snacks', 'icon' => 'Snacks.svg', 'sort_order' => 6]
];

echo "<!DOCTYPE html>";
echo "<html><head><title>Add Sample Categories</title>";
echo "<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css' rel='stylesheet'>";
echo "</head><body class='bg-light'>";

echo "<div class='container mt-5'>";
echo "<div class='row justify-content-center'>";
echo "<div class='col-md-8'>";
echo "<div class='card'>";
echo "<div class='card-header'>";
echo "<h3><i class='fas fa-tags'></i> Adding Sample Categories</h3>";
echo "</div>";
echo "<div class='card-body'>";

try {
    // Clear existing categories first
    $db->exec("DELETE FROM categories");
    echo "<div class='alert alert-info'>Cleared existing categories.</div>";
    
    $added_count = 0;
    
    foreach ($categories as $category) {
        $query = "INSERT INTO categories (name, icon, sort_order, is_active) VALUES (:name, :icon, :sort_order, 1)";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':name', $category['name']);
        $stmt->bindParam(':icon', $category['icon']);
        $stmt->bindParam(':sort_order', $category['sort_order']);
        
        if ($stmt->execute()) {
            echo "<div class='alert alert-success'>";
            echo "<i class='fas fa-check'></i> Added category: " . htmlspecialchars($category['name']);
            echo "</div>";
            $added_count++;
        } else {
            echo "<div class='alert alert-danger'>";
            echo "<i class='fas fa-times'></i> Failed to add category: " . htmlspecialchars($category['name']);
            echo "</div>";
        }
    }
    
    echo "<hr>";
    echo "<div class='alert alert-success'>";
    echo "<h5><i class='fas fa-check-circle'></i> Success!</h5>";
    echo "<p>Added $added_count sample categories to the database.</p>";
    echo "</div>";
    
    // Show current categories
    echo "<h5>Current Categories:</h5>";
    $query = "SELECT * FROM categories ORDER BY sort_order";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $current_categories = $stmt->fetchAll();
    
    echo "<div class='row'>";
    foreach ($current_categories as $cat) {
        echo "<div class='col-md-6 mb-2'>";
        echo "<div class='card'>";
        echo "<div class='card-body p-2'>";
        echo "<h6 class='mb-1'>" . htmlspecialchars($cat['name']) . "</h6>";
        echo "<small class='text-muted'>Icon: " . htmlspecialchars($cat['icon']) . " | Order: " . $cat['sort_order'] . "</small>";
        echo "</div></div></div>";
    }
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div class='alert alert-danger'>";
    echo "<h5><i class='fas fa-exclamation-triangle'></i> Error</h5>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
}

echo "<div class='text-center mt-4'>";
echo "<a href='backend/admin/categories.php' class='btn btn-primary'>";
echo "<i class='fas fa-tags'></i> Manage Categories";
echo "</a>";
echo "<a href='quick-access.html' class='btn btn-secondary ms-2'>";
echo "<i class='fas fa-home'></i> Quick Access";
echo "</a>";
echo "</div>";

echo "</div></div></div></div></div>";

echo "<script src='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js'></script>";
echo "<script src='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/js/all.min.js'></script>";
echo "</body></html>";
?>
