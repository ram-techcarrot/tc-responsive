<?php
require_once 'backend/config/database.php';

$database = new Database();
$db = $database->getConnection();

echo "Testing ordering page data...\n";

if (!$db) {
    echo "Database connection failed!\n";
    exit;
}

echo "Database connection successful!\n";

try {
    // Check categories
    $query = "SELECT COUNT(*) as count FROM categories WHERE is_active = 1";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $result = $stmt->fetch();
    echo "Active categories: " . $result['count'] . "\n";
    
    // Check menu items
    $query = "SELECT COUNT(*) as count FROM menu_items WHERE is_available = 1";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $result = $stmt->fetch();
    echo "Available menu items: " . $result['count'] . "\n";
    
    // Show sample data
    $query = "SELECT * FROM categories WHERE is_active = 1 ORDER BY sort_order, name LIMIT 3";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "\nSample categories:\n";
    foreach ($categories as $cat) {
        echo "- " . $cat['name'] . " (ID: " . $cat['id'] . ")\n";
    }
    
    $query = "SELECT mi.*, c.name as category_name FROM menu_items mi 
              LEFT JOIN categories c ON mi.category_id = c.id 
              WHERE mi.is_available = 1
              ORDER BY c.sort_order, mi.sort_order, mi.name LIMIT 3";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $menu_items = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "\nSample menu items:\n";
    foreach ($menu_items as $item) {
        echo "- " . $item['name'] . " (Rs. " . $item['price'] . ") - Category: " . $item['category_name'] . "\n";
    }
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>
