<?php
echo "<!DOCTYPE html>";
echo "<html><head><title>Order Success Test</title>";
echo "<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css' rel='stylesheet'>";
echo "<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css'>";
echo "</head><body class='bg-light'>";

echo "<div class='container mt-5'>";
echo "<div class='row justify-content-center'>";
echo "<div class='col-md-10'>";
echo "<div class='card'>";
echo "<div class='card-header'>";
echo "<h3><i class='fas fa-check-circle'></i> Order Success Page Test</h3>";
echo "</div>";
echo "<div class='card-body'>";

echo "<div class='alert alert-info'>";
echo "<h6><i class='fas fa-info-circle'></i> Order Success Page Features</h6>";
echo "<p>The order success page now displays order details in a professional table format:</p>";
echo "</div>";

echo "<h5>Table Format Features:</h5>";
echo "<div class='row'>";
echo "<div class='col-md-6'>";
echo "<h6>✅ Order Information Table:</h6>";
echo "<ul>";
echo "<li>Order Number</li>";
echo "<li>Status (with color-coded badge)</li>";
echo "<li>Customer Name</li>";
echo "<li>Mobile Number</li>";
echo "<li>Table Number</li>";
echo "<li>Placed At (formatted date/time)</li>";
echo "<li>Total Amount</li>";
echo "</ul>";
echo "</div>";

echo "<div class='col-md-6'>";
echo "<h6>✅ Order Items Table:</h6>";
echo "<ul>";
echo "<li>Item Name</li>";
echo "<li>Quantity (centered)</li>";
echo "<li>Unit Price (centered)</li>";
echo "<li>Total (right-aligned)</li>";
echo "</ul>";
echo "</div>";
echo "</div>";

echo "<hr>";

echo "<h5>Visual Improvements:</h5>";
echo "<div class='row'>";
echo "<div class='col-md-4'>";
echo "<div class='card'>";
echo "<div class='card-body text-center'>";
echo "<i class='fas fa-table fa-2x text-primary mb-2'></i>";
echo "<h6>Professional Tables</h6>";
echo "<p class='text-muted'>Clean, organized table layout</p>";
echo "</div></div></div>";

echo "<div class='col-md-4'>";
echo "<div class='card'>";
echo "<div class='card-body text-center'>";
echo "<i class='fas fa-palette fa-2x text-success mb-2'></i>";
echo "<h6>Color Coding</h6>";
echo "<p class='text-muted'>Status badges with colors</p>";
echo "</div></div></div>";

echo "<div class='col-md-4'>";
echo "<div class='card'>";
echo "<div class='card-body text-center'>";
echo "<i class='fas fa-mobile-alt fa-2x text-info mb-2'></i>";
echo "<h6>Responsive Design</h6>";
echo "<p class='text-muted'>Works on all devices</p>";
echo "</div></div></div>";
echo "</div>";

echo "<hr>";

echo "<h5>Test the Order Success Page:</h5>";
echo "<div class='alert alert-warning'>";
echo "<h6><i class='fas fa-exclamation-triangle'></i> How to Test</h6>";
echo "<ol>";
echo "<li><strong>Place an Order:</strong> Go to <code>ordering.php</code> and place a test order</li>";
echo "<li><strong>View Success Page:</strong> You'll be redirected to <code>order-success.php</code></li>";
echo "<li><strong>Check Tables:</strong> Verify the table format displays correctly</li>";
echo "<li><strong>Test Auto-refresh:</strong> Wait 30 seconds to see status updates</li>";
echo "</ol>";
echo "</div>";

echo "<div class='row'>";
echo "<div class='col-md-6 mb-3'>";
echo "<div class='card'>";
echo "<div class='card-body text-center'>";
echo "<i class='fas fa-shopping-cart fa-2x text-success mb-2'></i>";
echo "<h6>Place Test Order</h6>";
echo "<p class='text-muted'>Start the ordering process</p>";
echo "<a href='ordering.php' class='btn btn-success' target='_blank'>";
echo "<i class='fas fa-plus'></i> Place Order";
echo "</a>";
echo "</div></div></div>";

echo "<div class='col-md-6 mb-3'>";
echo "<div class='card'>";
echo "<div class='card-body text-center'>";
echo "<i class='fas fa-eye fa-2x text-info mb-2'></i>";
echo "<h6>View Success Page</h6>";
echo "<p class='text-muted'>See the table format</p>";
echo "<a href='order-success.php' class='btn btn-info' target='_blank'>";
echo "<i class='fas fa-external-link-alt'></i> View Page";
echo "</a>";
echo "</div></div></div>";
echo "</div>";

echo "<hr>";

echo "<h5>Sample Table Structure:</h5>";
echo "<div class='table-responsive'>";
echo "<table class='table table-striped'>";
echo "<thead class='table-dark'>";
echo "<tr><th>Field</th><th>Value</th></tr>";
echo "</thead>";
echo "<tbody>";
echo "<tr><td>Order Number</td><td>ORD202412011234</td></tr>";
echo "<tr><td>Status</td><td><span class='badge bg-primary'>Placed</span></td></tr>";
echo "<tr><td>Customer Name</td><td>John Smith</td></tr>";
echo "<tr><td>Mobile Number</td><td>+971501234567</td></tr>";
echo "<tr><td>Table Number</td><td>T01</td></tr>";
echo "<tr><td>Placed At</td><td>Dec 1, 2024 2:30 PM</td></tr>";
echo "<tr><td>Total Amount</td><td>Rs. 125.50</td></tr>";
echo "</tbody>";
echo "</table>";
echo "</div>";

echo "<div class='text-center mt-4'>";
echo "<a href='test_frontend.php' class='btn btn-secondary'>";
echo "<i class='fas fa-arrow-left'></i> Back to Frontend Test";
echo "</a>";
echo "<a href='quick-access.html' class='btn btn-primary ms-2'>";
echo "<i class='fas fa-home'></i> Quick Access";
echo "</a>";
echo "</div>";

echo "</div></div></div></div></div>";

echo "<script src='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js'></script>";
echo "</body></html>";
?>
