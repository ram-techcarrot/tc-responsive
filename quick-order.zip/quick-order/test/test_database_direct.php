<?php
echo "<!DOCTYPE html>";
echo "<html><head><title>Direct Database Test</title>";
echo "<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css' rel='stylesheet'>";
echo "</head><body class='bg-light'>";

echo "<div class='container mt-5'>";
echo "<div class='row justify-content-center'>";
echo "<div class='col-md-8'>";
echo "<div class='card'>";
echo "<div class='card-header'>";
echo "<h3><i class='fas fa-database'></i> Direct Database Test</h3>";
echo "</div>";
echo "<div class='card-body'>";

try {
    // Direct database connection
    $host = 'localhost';
    $dbname = 'quickorder';
    $username = 'root';
    $password = '';
    
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "<div class='alert alert-success'>";
    echo "<i class='fas fa-check-circle'></i> Direct database connection successful!";
    echo "</div>";
    
    // Check tables
    echo "<h5>Database Tables:</h5>";
    $stmt = $pdo->query("SHOW TABLES");
    $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    foreach ($tables as $table) {
        echo "<div class='alert alert-info'>";
        echo "<i class='fas fa-table'></i> Table: $table";
        echo "</div>";
    }
    
    // Check if orders table exists and has data
    if (in_array('orders', $tables)) {
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM orders");
        $result = $stmt->fetch();
        echo "<div class='alert alert-info'>";
        echo "<i class='fas fa-shopping-cart'></i> Orders count: " . $result['count'];
        echo "</div>";
        
        if ($result['count'] > 0) {
            $stmt = $pdo->query("SELECT * FROM orders LIMIT 3");
            $orders = $stmt->fetchAll();
            echo "<h6>Sample Orders:</h6>";
            foreach ($orders as $order) {
                echo "<div class='alert alert-light'>";
                echo "Order #" . $order['order_number'] . " - " . $order['customer_name'] . " - " . $order['status'];
                echo "</div>";
            }
        }
    }
    
    // Check menu_items
    if (in_array('menu_items', $tables)) {
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM menu_items");
        $result = $stmt->fetch();
        echo "<div class='alert alert-info'>";
        echo "<i class='fas fa-book'></i> Menu items count: " . $result['count'];
        echo "</div>";
    }
    
    // Check categories
    if (in_array('categories', $tables)) {
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM categories");
        $result = $stmt->fetch();
        echo "<div class='alert alert-info'>";
        echo "<i class='fas fa-tags'></i> Categories count: " . $result['count'];
        echo "</div>";
    }
    
} catch (Exception $e) {
    echo "<div class='alert alert-danger'>";
    echo "<h5><i class='fas fa-exclamation-triangle'></i> Error</h5>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
}

echo "<div class='text-center mt-4'>";
echo "<a href='add_dummy_orders.php' class='btn btn-primary' target='_blank'>";
echo "<i class='fas fa-plus'></i> Add Dummy Orders";
echo "</a>";
echo "</div>";

echo "</div></div></div></div></div>";
echo "</body></html>";
?>
