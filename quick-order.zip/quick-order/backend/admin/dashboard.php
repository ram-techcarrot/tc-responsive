<?php
require_once '../auth/check_auth.php';
require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

// Get today's statistics
$today = date('Y-m-d');
$stats = [];

// Total orders today
$query = "SELECT COUNT(*) as total_orders FROM orders WHERE DATE(placed_at) = :today";
$stmt = $db->prepare($query);
$stmt->bindParam(':today', $today);
$stmt->execute();
$stats['total_orders'] = $stmt->fetch()['total_orders'];

// Total revenue today
$query = "SELECT SUM(total_amount) as total_revenue FROM orders WHERE DATE(placed_at) = :today AND status IN ('served', 'completed', 'paid')";
$stmt = $db->prepare($query);
$stmt->bindParam(':today', $today);
$stmt->execute();
$stats['total_revenue'] = $stmt->fetch()['total_revenue'] ?? 0;

// Pending orders
$query = "SELECT COUNT(*) as pending_orders FROM orders WHERE status IN ('placed', 'pending', 'cooking')";
$stmt = $db->prepare($query);
$stmt->execute();
$stats['pending_orders'] = $stmt->fetch()['pending_orders'];

// Served orders today
$query = "SELECT COUNT(*) as served_orders FROM orders WHERE DATE(served_at) = :today";
$stmt = $db->prepare($query);
$stmt->bindParam(':today', $today);
$stmt->execute();
$stats['served_orders'] = $stmt->fetch()['served_orders'];

// Sales today (completed and paid orders)
$query = "SELECT COUNT(*) as sales_today FROM orders WHERE DATE(placed_at) = :today AND status IN ('completed', 'paid')";
$stmt = $db->prepare($query);
$stmt->bindParam(':today', $today);
$stmt->execute();
$stats['sales_today'] = $stmt->fetch()['sales_today'];

// Customers served today (unique customers who had orders served)
$query = "SELECT COUNT(DISTINCT customer_name) as customers_served FROM orders WHERE DATE(served_at) = :today";
$stmt = $db->prepare($query);
$stmt->bindParam(':today', $today);
$stmt->execute();
$stats['customers_served'] = $stmt->fetch()['customers_served'];

// Unpaid orders (served/completed but not paid)
$query = "SELECT COUNT(*) as unpaid_orders FROM orders WHERE status IN ('served', 'completed')";
$stmt = $db->prepare($query);
$stmt->execute();
$stats['unpaid_orders'] = $stmt->fetch()['unpaid_orders'];

// Total earned today (sum of all completed and paid orders)
$query = "SELECT SUM(total_amount) as total_earned FROM orders WHERE DATE(placed_at) = :today AND status IN ('completed', 'paid')";
$stmt = $db->prepare($query);
$stmt->bindParam(':today', $today);
$stmt->execute();
$stats['total_earned'] = $stmt->fetch()['total_earned'] ?? 0;

// Completed orders today
$query = "SELECT COUNT(*) as completed_orders FROM orders WHERE DATE(placed_at) = :today AND status = 'completed'";
$stmt = $db->prepare($query);
$stmt->bindParam(':today', $today);
$stmt->execute();
$stats['completed_orders'] = $stmt->fetch()['completed_orders'];

// Get recent orders
$query = "SELECT o.*, t.table_number FROM orders o 
          LEFT JOIN tables t ON o.table_id = t.id 
          ORDER BY o.placed_at DESC LIMIT 10";
$stmt = $db->prepare($query);
$stmt->execute();
$recent_orders = $stmt->fetchAll();

// Get order status counts
$query = "SELECT status, COUNT(*) as count FROM orders GROUP BY status";
$stmt = $db->prepare($query);
$stmt->execute();
$status_counts = $stmt->fetchAll();
?>

<?php include 'includes/header.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .stat-card {
            background: white;
            border-radius: 15px;
            padding: 1.5rem;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            border-left: 4px solid;
        }
        .stat-card.primary { border-left-color: #007bff; }
        .stat-card.success { border-left-color: #28a745; }
        .stat-card.warning { border-left-color: #ffc107; }
        .stat-card.info { border-left-color: #17a2b8; }
        .stat-card.danger { border-left-color: #dc3545; }
        .stat-card.secondary { border-left-color: #6c757d; }
        .stat-card.dark { border-left-color: #343a40; }
        .stat-card.light { border-left-color: #f8f9fa; }
        .stat-number {
            font-size: 2rem;
            font-weight: 700;
            margin: 0;
        }
        .stat-label {
            color: #6c757d;
            font-size: 0.9rem;
            margin: 0;
        }
        .order-card {
            background: white;
            border-radius: 10px;
            padding: 1rem;
            margin-bottom: 1rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            border-left: 4px solid;
        }
        .order-card.placed { border-left-color: #6c757d; }
        .order-card.pending { border-left-color: #ffc107; }
        .order-card.cooking { border-left-color: #fd7e14; }
        .order-card.served { border-left-color: #28a745; }
        .order-card.completed { border-left-color: #20c997; }
        .order-card.paid { border-left-color: #007bff; }
        .status-badge {
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
            text-transform: uppercase;
        }
        .status-placed { background: #e9ecef; color: #495057; }
        .status-pending { background: #fff3cd; color: #856404; }
        .status-cooking { background: #ffeaa7; color: #d63031; }
        .status-served { background: #d4edda; color: #155724; }
        .status-completed { background: #d1ecf1; color: #0c5460; }
        .status-paid { background: #cce5ff; color: #004085; }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <?php include 'includes/sidebar.php'; ?>
            
            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2><i class="fas fa-tachometer-alt"></i> Dashboard</h2>
                    <div class="text-muted">
                        Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>
                    </div>
                </div>
                
                <!-- Statistics Cards -->
                <div class="row mb-4">
                    <div class="col-md-3 mb-3">
                        <div class="stat-card primary">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <p class="stat-number text-primary"><?php echo $stats['total_orders']; ?></p>
                                    <p class="stat-label">Orders Today</p>
                                </div>
                                <i class="fas fa-shopping-cart fa-2x text-primary"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 mb-3">
                        <div class="stat-card success">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <p class="stat-number text-success">Rs. <?php echo number_format($stats['total_revenue'], 2); ?></p>
                                    <p class="stat-label">Revenue Today</p>
                                </div>
                                <i class="fas fa-rupee-sign fa-2x text-success"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 mb-3">
                        <div class="stat-card warning">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <p class="stat-number text-warning"><?php echo $stats['pending_orders']; ?></p>
                                    <p class="stat-label">Pending Orders</p>
                                </div>
                                <i class="fas fa-clock fa-2x text-warning"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 mb-3">
                        <div class="stat-card info">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <p class="stat-number text-info"><?php echo $stats['served_orders']; ?></p>
                                    <p class="stat-label">Served Today</p>
                                </div>
                                <i class="fas fa-check-circle fa-2x text-info"></i>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Additional Statistics Row -->
                <div class="row mb-4">
                    <div class="col-md-3 mb-3">
                        <div class="stat-card danger">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <p class="stat-number text-danger"><?php echo $stats['sales_today']; ?></p>
                                    <p class="stat-label">Sales Today</p>
                                </div>
                                <i class="fas fa-chart-line fa-2x text-danger"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 mb-3">
                        <div class="stat-card secondary">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <p class="stat-number text-secondary"><?php echo $stats['customers_served']; ?></p>
                                    <p class="stat-label">Customers Served</p>
                                </div>
                                <i class="fas fa-users fa-2x text-secondary"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 mb-3">
                        <div class="stat-card dark">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <p class="stat-number text-dark">Rs. <?php echo number_format($stats['total_earned'], 2); ?></p>
                                    <p class="stat-label">Total Earned Today</p>
                                </div>
                                <i class="fas fa-coins fa-2x text-dark"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 mb-3">
                        <div class="stat-card light">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <p class="stat-number text-muted"><?php echo $stats['completed_orders']; ?></p>
                                    <p class="stat-label">Completed Orders</p>
                                </div>
                                <i class="fas fa-check-double fa-2x text-muted"></i>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-3 mb-3">
                        <div class="stat-card danger">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <p class="stat-number text-danger"><?php echo $stats['unpaid_orders']; ?></p>
                                    <p class="stat-label">Unpaid Orders</p>
                                </div>
                                <i class="fas fa-credit-card fa-2x text-danger"></i>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <!-- Recent Orders -->
                    <div class="col-lg-8">
                        <div class="card">
                            <div class="card-header">
                                <h5><i class="fas fa-list"></i> Recent Orders</h5>
                            </div>
                            <div class="card-body">
                                <?php if (empty($recent_orders)): ?>
                                    <p class="text-muted text-center">No orders found</p>
                                <?php else: ?>
                                    <?php foreach ($recent_orders as $order): ?>
                                        <div class="order-card <?php echo $order['status']; ?>">
                                            <div class="row align-items-center">
                                                <div class="col-md-3">
                                                    <strong>#<?php echo htmlspecialchars($order['order_number']); ?></strong>
                                                    <br>
                                                    <small class="text-muted"><?php echo htmlspecialchars($order['customer_name']); ?></small>
                                                </div>
                                                <div class="col-md-2">
                                                    <small class="text-muted">Table: <?php echo $order['table_number'] ?: 'N/A'; ?></small>
                                                </div>
                                                <div class="col-md-2">
                                                    <span class="status-badge status-<?php echo $order['status']; ?>">
                                                        <?php echo ucfirst($order['status']); ?>
                                                    </span>
                                                </div>
                                                <div class="col-md-2">
                                                    <strong>₹<?php echo number_format($order['total_amount'], 2); ?></strong>
                                                </div>
                                                <div class="col-md-3 text-end">
                                                    <small class="text-muted">
                                                        <?php echo date('H:i', strtotime($order['placed_at'])); ?>
                                                    </small>
                                                    <br>
                                                    <a href="orders.php?id=<?php echo $order['id']; ?>" class="btn btn-sm btn-outline-primary">
                                                        View
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Order Status Chart -->
                    <div class="col-lg-4">
                        <div class="card">
                            <div class="card-header">
                                <h5><i class="fas fa-chart-pie"></i> Order Status</h5>
                            </div>
                            <div class="card-body">
                                <canvas id="statusChart" width="300" height="300"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Order Status Chart
        const statusData = <?php echo json_encode($status_counts); ?>;
        const ctx = document.getElementById('statusChart').getContext('2d');
        
        const colors = {
            'placed': '#6c757d',
            'pending': '#ffc107',
            'cooking': '#fd7e14',
            'served': '#28a745',
            'completed': '#20c997',
            'paid': '#007bff'
        };
        
        new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: statusData.map(item => item.status.charAt(0).toUpperCase() + item.status.slice(1)),
                datasets: [{
                    data: statusData.map(item => item.count),
                    backgroundColor: statusData.map(item => colors[item.status]),
                    borderWidth: 2,
                    borderColor: '#fff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
    </script>
    <?php include 'includes/footer.php'; ?>
