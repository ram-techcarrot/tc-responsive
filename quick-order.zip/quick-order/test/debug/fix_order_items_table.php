<?php
require_once 'backend/config/database.php';

$database = new Database();
$db = $database->getConnection();

echo "<!DOCTYPE html><html><head><title>Fix Order Items Table</title>";
echo "<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css' rel='stylesheet'>";
echo "</head><body><div class='container mt-5'>";
echo "<h1>Fix Order Items Table</h1>";

try {
    // Add item_name column to order_items table
    $query = "ALTER TABLE order_items ADD COLUMN item_name VARCHAR(100) AFTER menu_item_id";
    $db->exec($query);
    echo "<div class='alert alert-success'>Added 'item_name' column to order_items table.</div>";
    
    // Update existing records with item names
    $query = "UPDATE order_items oi 
              LEFT JOIN menu_items mi ON oi.menu_item_id = mi.id 
              SET oi.item_name = mi.name 
              WHERE oi.item_name IS NULL";
    $stmt = $db->prepare($query);
    $stmt->execute();
    echo "<div class='alert alert-success'>Updated existing order items with item names.</div>";
    
    echo "<div class='alert alert-info'>Order items table has been fixed!</div>";
    
} catch (Exception $e) {
    if (strpos($e->getMessage(), 'Duplicate column name') !== false) {
        echo "<div class='alert alert-info'>Column 'item_name' already exists in order_items table.</div>";
    } else {
        echo "<div class='alert alert-danger'>Error: " . htmlspecialchars($e->getMessage()) . "</div>";
    }
}

echo "<div class='mt-4'><a href='ordering.php' class='btn btn-primary'>Test Ordering Page</a></div>";
echo "</div></body></html>";
?>
