<?php
require_once '../auth/check_auth.php';
require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

// Handle status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $order_id = $_POST['order_id'];
    $new_status = $_POST['status'];
    
    $query = "UPDATE orders SET status = :status";
    
    // Add timestamp based on status
    if ($new_status === 'served') {
        $query .= ", served_at = NOW()";
    } elseif ($new_status === 'completed') {
        $query .= ", completed_at = NOW()";
    } elseif ($new_status === 'paid') {
        $query .= ", paid_at = NOW()";
    }
    
    $query .= " WHERE id = :order_id";
    
    $stmt = $db->prepare($query);
    $stmt->bindParam(':status', $new_status);
    $stmt->bindParam(':order_id', $order_id);
    
    if ($stmt->execute()) {
        $success = 'Order status updated successfully!';
    } else {
        $error = 'Failed to update order status.';
    }
}

// Get filter parameters
$status_filter = $_GET['status'] ?? '';
$date_filter = $_GET['date'] ?? date('Y-m-d');

// Build query based on filters
$where_conditions = [];
$params = [];

if ($status_filter) {
    $where_conditions[] = "o.status = :status";
    $params[':status'] = $status_filter;
}

if ($date_filter) {
    $where_conditions[] = "DATE(o.placed_at) = :date";
    $params[':date'] = $date_filter;
}

$where_clause = $where_conditions ? 'WHERE ' . implode(' AND ', $where_conditions) : '';

// Get orders
$query = "SELECT o.*, t.table_number, 
          (SELECT COUNT(*) FROM order_items oi WHERE oi.order_id = o.id) as item_count
          FROM orders o 
          LEFT JOIN tables t ON o.table_id = t.id 
          $where_clause
          ORDER BY o.placed_at DESC";
          
$stmt = $db->prepare($query);
foreach ($params as $key => $value) {
    $stmt->bindValue($key, $value);
}
$stmt->execute();
$orders = $stmt->fetchAll();

// Get order details for specific order
$order_details = null;
if (isset($_GET['id'])) {
    $order_id = $_GET['id'];
    
    // Get order info
    $query = "SELECT o.*, t.table_number FROM orders o 
              LEFT JOIN tables t ON o.table_id = t.id 
              WHERE o.id = :id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $order_id);
    $stmt->execute();
    $order_details = $stmt->fetch();
    
    if ($order_details) {
        // Get order items
        $query = "SELECT oi.*, mi.name as item_name, mi.image as item_image 
                  FROM order_items oi 
                  LEFT JOIN menu_items mi ON oi.menu_item_id = mi.id 
                  WHERE oi.order_id = :id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':id', $order_id);
        $stmt->execute();
        $order_items = $stmt->fetchAll();
    }
}

// Get status counts for today
$today = date('Y-m-d');
$query = "SELECT status, COUNT(*) as count FROM orders 
          WHERE DATE(placed_at) = :today 
          GROUP BY status";
$stmt = $db->prepare($query);
$stmt->bindParam(':today', $today);
$stmt->execute();
$status_counts = $stmt->fetchAll();
?>

<?php include 'includes/header.php'; ?>
    <style>
        .order-card {
            background: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%);
            border-radius: 20px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 8px 32px rgba(0,0,0,0.1);
            border: 1px solid rgba(255,255,255,0.2);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        
        .order-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
        }
        
        .order-card.placed::before { background: linear-gradient(90deg, #6c757d 0%, #495057 100%); }
        .order-card.pending::before { background: linear-gradient(90deg, #ffc107 0%, #ff8c00 100%); }
        .order-card.cooking::before { background: linear-gradient(90deg, #fd7e14 0%, #dc3545 100%); }
        .order-card.served::before { background: linear-gradient(90deg, #28a745 0%, #20c997 100%); }
        .order-card.completed::before { background: linear-gradient(90deg, #20c997 0%, #17a2b8 100%); }
        .order-card.paid::before { background: linear-gradient(90deg, #007bff 0%, #6f42c1 100%); }
        
        .order-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(0,0,0,0.15);
        }
        .status-badge {
            padding: 8px 16px;
            border-radius: 25px;
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            border: 2px solid rgba(255,255,255,0.3);
        }
        .status-placed { 
            background: linear-gradient(135deg, #e9ecef 0%, #dee2e6 100%); 
            color: #495057; 
        }
        .status-pending { 
            background: linear-gradient(135deg, #fff3cd 0%, #ffeaa7 100%); 
            color: #856404; 
        }
        .status-cooking { 
            background: linear-gradient(135deg, #ffeaa7 0%, #ff7675 100%); 
            color: #d63031; 
        }
        .status-served { 
            background: linear-gradient(135deg, #d4edda 0%, #a8e6cf 100%); 
            color: #155724; 
        }
        .status-completed { 
            background: linear-gradient(135deg, #d1ecf1 0%, #74b9ff 100%); 
            color: #0c5460; 
        }
        .status-paid { 
            background: linear-gradient(135deg, #cce5ff 0%, #a29bfe 100%); 
            color: #004085; 
        }
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.3);
        }
        .filter-card {
            background: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%);
            border-radius: 20px;
            padding: 1.5rem;
            margin-bottom: 2rem;
            box-shadow: 0 8px 32px rgba(0,0,0,0.1);
            border: 1px solid rgba(255,255,255,0.2);
        }
        
        .order-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
        }
        
        .order-number {
            font-size: 1.2rem;
            font-weight: 700;
            color: #2c3e50;
            margin: 0;
        }
        
        .order-customer {
            font-size: 1rem;
            font-weight: 600;
            color: #34495e;
            margin: 0.5rem 0;
        }
        
        .order-details {
            color: #7f8c8d;
            font-size: 0.9rem;
            margin: 0.3rem 0;
        }
        
        .order-amount {
            font-size: 1.1rem;
            font-weight: 700;
            color: #27ae60;
            margin: 0.5rem 0;
        }
        
        .order-time {
            font-size: 0.8rem;
            color: #95a5a6;
            text-align: right;
        }
        
        .view-btn {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            border-radius: 15px;
            padding: 8px 16px;
            color: white;
            font-weight: 600;
            font-size: 0.85rem;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
        }
        
        .view-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
            color: white;
        }
        
        .card-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 1rem;
            font-size: 1.2rem;
        }
        
        .card-icon.placed { background: linear-gradient(135deg, #6c757d 0%, #495057 100%); color: white; }
        .card-icon.pending { background: linear-gradient(135deg, #ffc107 0%, #ff8c00 100%); color: white; }
        .card-icon.cooking { background: linear-gradient(135deg, #fd7e14 0%, #dc3545 100%); color: white; }
        .card-icon.served { background: linear-gradient(135deg, #28a745 0%, #20c997 100%); color: white; }
        .card-icon.completed { background: linear-gradient(135deg, #20c997 0%, #17a2b8 100%); color: white; }
        .card-icon.paid { background: linear-gradient(135deg, #007bff 0%, #6f42c1 100%); color: white; }
    </style>

    <?php include 'includes/sidebar.php'; ?>
            
            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2><i class="fas fa-shopping-cart"></i> Order Management</h2>
                    <div class="text-muted">
                        <?php echo count($orders); ?> orders found
                    </div>
                </div>
                
                <?php if (isset($success)): ?>
                    <div class="alert alert-success alert-dismissible fade show">
                        <i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <?php if (isset($error)): ?>
                    <div class="alert alert-danger alert-dismissible fade show">
                        <i class="fas fa-exclamation-triangle"></i> <?php echo htmlspecialchars($error); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <!-- Filters -->
                <div class="filter-card">
                    <form method="GET" class="row g-3">
                        <div class="col-md-4">
                            <label for="status" class="form-label">Status</label>
                            <select class="form-select" name="status" id="status">
                                <option value="">All Status</option>
                                <option value="placed" <?php echo $status_filter === 'placed' ? 'selected' : ''; ?>>Placed</option>
                                <option value="pending" <?php echo $status_filter === 'pending' ? 'selected' : ''; ?>>Pending</option>
                                <option value="cooking" <?php echo $status_filter === 'cooking' ? 'selected' : ''; ?>>Cooking</option>
                                <option value="served" <?php echo $status_filter === 'served' ? 'selected' : ''; ?>>Served</option>
                                <option value="completed" <?php echo $status_filter === 'completed' ? 'selected' : ''; ?>>Completed</option>
                                <option value="paid" <?php echo $status_filter === 'paid' ? 'selected' : ''; ?>>Paid</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label for="date" class="form-label">Date</label>
                            <input type="date" class="form-control" name="date" id="date" 
                                   value="<?php echo htmlspecialchars($date_filter); ?>">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">&nbsp;</label>
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-filter"></i> Filter
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
                
                <?php if (isset($order_details)): ?>
                    <!-- Order Details View -->
                    <div class="card">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5><i class="fas fa-receipt"></i> Order #<?php echo htmlspecialchars($order_details['order_number']); ?></h5>
                            <a href="orders.php" class="btn btn-outline-secondary">
                                <i class="fas fa-arrow-left"></i> Back to Orders
                            </a>
                        </div>
                        <div class="card-body">
                            <div class="row mb-4">
                                <div class="col-md-6">
                                    <h6>Customer Information</h6>
                                    <p><strong>Name:</strong> <?php echo htmlspecialchars($order_details['customer_name']); ?></p>
                                    <p><strong>Mobile:</strong> <?php echo htmlspecialchars($order_details['customer_mobile']); ?></p>
                                    <p><strong>Table:</strong> <?php echo $order_details['table_number'] ?: 'N/A'; ?></p>
                                </div>
                                <div class="col-md-6">
                                    <h6>Order Information</h6>
                                    <p><strong>Status:</strong> 
                                        <span class="status-badge status-<?php echo $order_details['status']; ?>">
                                            <?php echo ucfirst($order_details['status']); ?>
                                        </span>
                                    </p>
                                    <p><strong>Placed:</strong> <?php echo date('d M Y H:i', strtotime($order_details['placed_at'])); ?></p>
                                    <?php if ($order_details['served_at']): ?>
                                        <p><strong>Served:</strong> <?php echo date('d M Y H:i', strtotime($order_details['served_at'])); ?></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <h6>Order Items</h6>
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Item</th>
                                            <th>Quantity</th>
                                            <th>Unit Price</th>
                                            <th>Total</th>
                                            <th>Notes</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($order_items as $item): ?>
                                            <tr>
                                                <td>
                                                    <div class="d-flex align-items-center">
                                                        <img src="../../image/<?php echo htmlspecialchars($item['item_image']); ?>" 
                                                             alt="<?php echo htmlspecialchars($item['item_name']); ?>" 
                                                             class="me-2" style="width: 40px; height: 40px; object-fit: cover; border-radius: 4px;">
                                                        <?php echo htmlspecialchars($item['item_name']); ?>
                                                    </div>
                                                </td>
                                                <td><?php echo $item['quantity']; ?></td>
                                                <td>₹<?php echo number_format($item['unit_price'], 2); ?></td>
                                                <td>₹<?php echo number_format($item['total_price'], 2); ?></td>
                                                <td><?php echo htmlspecialchars($item['notes'] ?: '-'); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            
                            <div class="row mt-4">
                                <div class="col-md-8">
                                    <?php if ($order_details['notes']): ?>
                                        <h6>Order Notes</h6>
                                        <p><?php echo htmlspecialchars($order_details['notes']); ?></p>
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-4">
                                    <div class="card bg-light">
                                        <div class="card-body">
                                            <h6>Order Summary</h6>
                                            <p>Subtotal: ₹<?php echo number_format($order_details['subtotal'], 2); ?></p>
                                            <?php if ($order_details['gst_amount'] > 0): ?>
                                                <p>GST (<?php echo $order_details['gst_rate']; ?>%): ₹<?php echo number_format($order_details['gst_amount'], 2); ?></p>
                                            <?php endif; ?>
                                            <hr>
                                            <h6>Total: ₹<?php echo number_format($order_details['total_amount'], 2); ?></h6>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Status Update -->
                            <div class="mt-4">
                                <h6>Update Status</h6>
                                <form method="POST" class="d-inline">
                                    <input type="hidden" name="order_id" value="<?php echo $order_details['id']; ?>">
                                    <div class="btn-group" role="group">
                                        <input type="radio" class="btn-check" name="status" id="status_placed" value="placed" 
                                               <?php echo $order_details['status'] === 'placed' ? 'checked' : ''; ?>>
                                        <label class="btn btn-outline-secondary" for="status_placed">Placed</label>
                                        
                                        <input type="radio" class="btn-check" name="status" id="status_pending" value="pending" 
                                               <?php echo $order_details['status'] === 'pending' ? 'checked' : ''; ?>>
                                        <label class="btn btn-outline-warning" for="status_pending">Pending</label>
                                        
                                        <input type="radio" class="btn-check" name="status" id="status_cooking" value="cooking" 
                                               <?php echo $order_details['status'] === 'cooking' ? 'checked' : ''; ?>>
                                        <label class="btn btn-outline-danger" for="status_cooking">Cooking</label>
                                        
                                        <input type="radio" class="btn-check" name="status" id="status_served" value="served" 
                                               <?php echo $order_details['status'] === 'served' ? 'checked' : ''; ?>>
                                        <label class="btn btn-outline-success" for="status_served">Served</label>
                                        
                                        <input type="radio" class="btn-check" name="status" id="status_completed" value="completed" 
                                               <?php echo $order_details['status'] === 'completed' ? 'checked' : ''; ?>>
                                        <label class="btn btn-outline-info" for="status_completed">Completed</label>
                                        
                                        <input type="radio" class="btn-check" name="status" id="status_paid" value="paid" 
                                               <?php echo $order_details['status'] === 'paid' ? 'checked' : ''; ?>>
                                        <label class="btn btn-outline-primary" for="status_paid">Paid</label>
                                    </div>
                                    <button type="submit" name="update_status" class="btn btn-primary ms-3">
                                        <i class="fas fa-save"></i> Update Status
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <!-- Orders List -->
                    <div class="row">
                        <?php foreach ($orders as $order): ?>
                            <div class="col-md-6 col-lg-4 mb-4">
                                <div class="order-card <?php echo $order['status']; ?>">
                                    <!-- Card Icon -->
                                    <div class="card-icon <?php echo $order['status']; ?>">
                                        <?php 
                                        $icons = [
                                            'placed' => 'fas fa-clock',
                                            'pending' => 'fas fa-hourglass-half',
                                            'cooking' => 'fas fa-fire',
                                            'served' => 'fas fa-check-circle',
                                            'completed' => 'fas fa-check-double',
                                            'paid' => 'fas fa-credit-card'
                                        ];
                                        echo '<i class="' . ($icons[$order['status']] ?? 'fas fa-shopping-cart') . '"></i>';
                                        ?>
                                    </div>
                                    
                                    <!-- Order Header -->
                                    <div class="order-header">
                                        <h5 class="order-number">#<?php echo htmlspecialchars($order['order_number']); ?></h5>
                                        <span class="status-badge status-<?php echo $order['status']; ?>">
                                            <?php echo ucfirst($order['status']); ?>
                                        </span>
                                    </div>
                                    
                                    <!-- Customer Info -->
                                    <div class="order-customer">
                                        <i class="fas fa-user me-2"></i><?php echo htmlspecialchars($order['customer_name']); ?>
                                    </div>
                                    
                                    <!-- Order Details -->
                                    <div class="order-details">
                                        <div><i class="fas fa-phone me-2"></i><?php echo htmlspecialchars($order['customer_mobile']); ?></div>
                                        <div><i class="fas fa-table me-2"></i>Table: <?php echo $order['table_number'] ?: 'N/A'; ?></div>
                                        <div><i class="fas fa-shopping-basket me-2"></i><?php echo $order['item_count']; ?> items</div>
                                    </div>
                                    
                                    <!-- Amount and Time -->
                                    <div class="d-flex justify-content-between align-items-center mt-3">
                                        <div class="order-amount">
                                            <i class="fas fa-rupee-sign me-1"></i><?php echo number_format($order['total_amount'], 2); ?>
                                        </div>
                                        <div class="order-time">
                                            <i class="fas fa-clock me-1"></i><?php echo date('H:i', strtotime($order['placed_at'])); ?>
                                        </div>
                                    </div>
                                    
                                    <!-- Action Button -->
                                    <div class="mt-3 text-center">
                                        <a href="orders.php?id=<?php echo $order['id']; ?>" class="view-btn">
                                            <i class="fas fa-eye me-2"></i>View Details
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <?php if (empty($orders)): ?>
                        <div class="text-center py-5">
                            <div class="order-card" style="max-width: 400px; margin: 0 auto;">
                                <div class="card-icon placed" style="margin: 0 auto 1.5rem;">
                                    <i class="fas fa-shopping-cart"></i>
                                </div>
                                <h4 class="order-number" style="color: #7f8c8d;">No Orders Found</h4>
                                <p class="order-details" style="text-align: center; margin-top: 1rem;">
                                    Try adjusting your filters or check back later.
                                </p>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <?php include 'includes/footer.php'; ?>
