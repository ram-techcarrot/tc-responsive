<?php
require_once '../auth/protect.php';
require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

// Handle payment status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'mark_paid' && isset($_POST['order_id'])) {
        try {
            $order_id = $_POST['order_id'];
            $query = "UPDATE orders SET status = 'paid', paid_at = NOW(), updated_at = NOW() WHERE id = :order_id";
            $stmt = $db->prepare($query);
            $stmt->bindParam(':order_id', $order_id);
            
            if ($stmt->execute()) {
                $success_message = "Order marked as paid successfully!";
            } else {
                $error_message = "Failed to update order status.";
            }
        } catch (Exception $e) {
            $error_message = "Error updating order: " . $e->getMessage();
        }
    } elseif ($_POST['action'] === 'mark_ready' && isset($_POST['order_id'])) {
        try {
            $order_id = $_POST['order_id'];
            $query = "UPDATE orders SET status = 'served', served_at = NOW(), updated_at = NOW() WHERE id = :order_id";
            $stmt = $db->prepare($query);
            $stmt->bindParam(':order_id', $order_id);
            
            if ($stmt->execute()) {
                $success_message = "Order marked as ready for payment!";
            } else {
                $error_message = "Failed to update order status.";
            }
        } catch (Exception $e) {
            $error_message = "Error updating order: " . $e->getMessage();
        }
    }
}

// Get unpaid orders (served, completed but not paid)
$unpaid_orders = [];
try {
    $query = "SELECT o.*, t.table_number,
                     GROUP_CONCAT(CONCAT(oi.item_name, ' (', oi.quantity, ')') SEPARATOR ', ') as items_summary,
                     COUNT(oi.id) as item_count
              FROM orders o 
              LEFT JOIN tables t ON o.table_id = t.id
              LEFT JOIN order_items oi ON o.id = oi.order_id 
              WHERE o.status IN ('served', 'completed')
              GROUP BY o.id 
              ORDER BY o.created_at ASC";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $unpaid_orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    error_log("Error fetching unpaid orders: " . $e->getMessage());
}

// Get kitchen orders (placed, pending, cooking) for sidebar
$kitchen_orders = [];
try {
    $query = "SELECT o.*, t.table_number,
                     GROUP_CONCAT(CONCAT(oi.item_name, ' (', oi.quantity, ')') SEPARATOR ', ') as items_summary,
                     COUNT(oi.id) as item_count
              FROM orders o 
              LEFT JOIN tables t ON o.table_id = t.id
              LEFT JOIN order_items oi ON o.id = oi.order_id 
              WHERE o.status IN ('placed', 'pending', 'cooking')
              GROUP BY o.id 
              ORDER BY o.created_at ASC";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $kitchen_orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    error_log("Error fetching kitchen orders: " . $e->getMessage());
}

// Get detailed order items for each order
$order_items = [];
if (!empty($unpaid_orders)) {
    $order_ids = array_column($unpaid_orders, 'id');
    $placeholders = str_repeat('?,', count($order_ids) - 1) . '?';
    
    $query = "SELECT oi.*, t.table_number, o.customer_name, o.created_at, o.total_amount 
              FROM order_items oi 
              JOIN orders o ON oi.order_id = o.id 
              LEFT JOIN tables t ON o.table_id = t.id
              WHERE oi.order_id IN ($placeholders) 
              ORDER BY o.created_at ASC, oi.order_id ASC";
    $stmt = $db->prepare($query);
    $stmt->execute($order_ids);
    $order_items = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Group items by order
$grouped_items = [];
foreach ($order_items as $item) {
    $grouped_items[$item['order_id']][] = $item;
}
?>

<?php include 'includes/header.php'; ?>
    
    <style>
        :root {
            --admin-primary: #2c3e50;
            --admin-secondary: #34495e;
            --admin-accent: #e74c3c;
            --admin-success: #27ae60;
            --admin-warning: #f39c12;
            --admin-light: #ecf0f1;
            --admin-dark: #2c3e50;
        }

        body {
            background: linear-gradient(135deg, var(--admin-primary) 0%, var(--admin-secondary) 100%);
            font-family: 'Arial', sans-serif;
            min-height: 100vh;
            color: #fff;
        }

        .admin-header {
            background: var(--admin-dark);
            padding: 1rem 0;
            border-bottom: 3px solid var(--admin-accent);
            box-shadow: 0 4px 15px rgba(0,0,0,0.3);
        }

        .admin-title {
            font-size: 2.5rem;
            font-weight: bold;
            color: #fff;
            text-align: center;
            margin: 0;
        }

        .orders-container {
            padding: 2rem 0;
        }

        .order-card {
            background: #fff;
            border-radius: 15px;
            margin-bottom: 1.5rem;
            box-shadow: 0 8px 25px rgba(0,0,0,0.3);
            border-left: 8px solid var(--admin-warning);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            height: fit-content;
        }

        .order-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 35px rgba(0,0,0,0.4);
        }

        .order-header {
            background: linear-gradient(135deg, var(--admin-warning) 0%, #e67e22 100%);
            color: #fff;
            padding: 1rem;
            border-radius: 15px 15px 0 0;
        }

        .order-number {
            font-size: 1.5rem;
            font-weight: bold;
            margin: 0;
        }

        .order-time {
            font-size: 1.2rem;
            opacity: 0.9;
            margin: 0.5rem 0 0 0;
        }

        .order-customer {
            font-size: 1.4rem;
            font-weight: 600;
            margin: 0.5rem 0;
        }

        .order-table {
            font-size: 1.3rem;
            background: rgba(255,255,255,0.2);
            padding: 0.5rem 1rem;
            border-radius: 25px;
            display: inline-block;
            margin-top: 0.5rem;
        }

        .order-body {
            padding: 1rem;
        }

        .items-section {
            margin-bottom: 1rem;
        }

        .items-title {
            font-size: 1.2rem;
            font-weight: bold;
            color: var(--admin-dark);
            margin-bottom: 0.8rem;
            border-bottom: 2px solid var(--admin-accent);
            padding-bottom: 0.3rem;
        }

        .item-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0.6rem;
            margin-bottom: 0.4rem;
            background: var(--admin-light);
            border-radius: 8px;
            border-left: 3px solid var(--admin-success);
        }

        .item-name {
            font-size: 1rem;
            font-weight: 600;
            color: var(--admin-dark);
            flex-grow: 1;
        }

        .item-quantity {
            background: var(--admin-success);
            color: #fff;
            padding: 0.3rem 0.8rem;
            border-radius: 15px;
            font-size: 1rem;
            font-weight: bold;
            margin-left: 0.5rem;
        }

        .payment-section {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            border-radius: 10px;
            padding: 1rem;
            margin-bottom: 1rem;
            border: 2px solid var(--admin-success);
        }

        .payment-amount {
            font-size: 1.8rem;
            font-weight: bold;
            color: var(--admin-success);
            text-align: center;
            margin-bottom: 1rem;
        }

        .order-actions {
            text-align: center;
            padding-top: 0.8rem;
            border-top: 2px solid #eee;
        }

        .status-btn {
            padding: 0.6rem 1.2rem;
            font-size: 1rem;
            font-weight: bold;
            border-radius: 20px;
            border: none;
            margin: 0.2rem;
            transition: all 0.3s ease;
            width: 100%;
        }

        .btn-paid {
            background: var(--admin-success);
            color: #fff;
        }

        .btn-paid:hover {
            background: #229954;
            transform: scale(1.05);
        }

        .btn-receipt {
            background: var(--admin-primary);
            color: #fff;
        }

        .btn-receipt:hover {
            background: #1a252f;
            transform: scale(1.05);
        }

        .no-orders {
            text-align: center;
            padding: 4rem 2rem;
            background: rgba(255,255,255,0.1);
            border-radius: 15px;
            margin: 2rem 0;
        }

        .no-orders i {
            font-size: 4rem;
            color: var(--admin-accent);
            margin-bottom: 1rem;
        }

        .no-orders h3 {
            font-size: 2rem;
            color: #fff;
            margin-bottom: 1rem;
        }

        .alert {
            margin: 1rem 0;
        }

        /* Auto-refresh indicator */
        .auto-refresh {
            position: fixed;
            top: 1rem;
            left: 1rem;
            background: rgba(0,0,0,0.7);
            color: #fff;
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-size: 0.9rem;
            z-index: 1000;
        }

        /* Sidebar styles */
        .kitchen-sidebar {
            background: rgba(255,255,255,0.1);
            border-radius: 15px;
            padding: 1rem;
            margin-bottom: 2rem;
            max-height: 80vh;
            overflow-y: auto;
        }

        .sidebar-title {
            font-size: 1.2rem;
            font-weight: bold;
            color: #fff;
            margin-bottom: 1rem;
            text-align: center;
            border-bottom: 2px solid var(--admin-accent);
            padding-bottom: 0.5rem;
        }

        .kitchen-order-card {
            background: #fff;
            border-radius: 10px;
            margin-bottom: 0.8rem;
            padding: 0.8rem;
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
            border-left: 4px solid var(--admin-warning);
            transition: transform 0.2s ease;
            cursor: pointer;
        }

        .kitchen-order-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(0,0,0,0.3);
        }

        .kitchen-order-card.placed {
            border-left-color: #e74c3c;
        }

        .kitchen-order-card.pending {
            border-left-color: #f39c12;
        }

        .kitchen-order-card.cooking {
            border-left-color: #27ae60;
        }

        .kitchen-order-number {
            font-size: 0.9rem;
            font-weight: bold;
            color: var(--admin-dark);
            margin-bottom: 0.3rem;
        }

        .kitchen-order-customer {
            font-size: 0.8rem;
            color: #666;
            margin-bottom: 0.3rem;
        }

        .kitchen-order-table {
            font-size: 0.8rem;
            color: #666;
            margin-bottom: 0.3rem;
        }

        .kitchen-order-status {
            font-size: 0.7rem;
            font-weight: bold;
            text-transform: uppercase;
            padding: 0.2rem 0.5rem;
            border-radius: 10px;
            display: inline-block;
        }

        .kitchen-order-status.placed {
            background: #e74c3c;
            color: #fff;
        }

        .kitchen-order-status.pending {
            background: #f39c12;
            color: #fff;
        }

        .kitchen-order-status.cooking {
            background: #27ae60;
            color: #fff;
        }

        .kitchen-order-time {
            font-size: 0.7rem;
            color: #999;
            margin-top: 0.3rem;
        }

        .mark-ready-btn {
            background: var(--admin-success);
            color: #fff;
            border: none;
            padding: 0.3rem 0.6rem;
            border-radius: 15px;
            font-size: 0.7rem;
            font-weight: bold;
            margin-top: 0.5rem;
            width: 100%;
            transition: all 0.2s ease;
        }

        .mark-ready-btn:hover {
            background: #229954;
            transform: scale(1.05);
        }

        .no-kitchen-orders {
            text-align: center;
            color: #999;
            font-size: 0.9rem;
            padding: 2rem 1rem;
        }

        @media (max-width: 768px) {
            .admin-title {
                font-size: 2rem;
            }
            
            .order-number {
                font-size: 1.2rem;
            }
            
            .item-name {
                font-size: 0.9rem;
            }
            
            .status-btn {
                font-size: 0.9rem;
                padding: 0.5rem 1rem;
            }
        }
    </style>
</head>
<body>
    <!-- Auto-refresh indicator -->
    <div class="auto-refresh">
        <i class="fas fa-sync-alt"></i> Auto-refresh: 20s
    </div>

    <?php include 'includes/sidebar.php'; ?>
            
    <!-- Main Content -->
    <div class="col-md-9 col-lg-10 p-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2><i class="fas fa-credit-card"></i> Unpaid Orders</h2>
            <div class="text-muted">
                <?php echo count($unpaid_orders); ?> unpaid orders found
            </div>
        </div>
        <?php if (isset($success_message)): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <i class="fas fa-check-circle"></i> <?php echo $success_message; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php if (isset($error_message)): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <i class="fas fa-exclamation-triangle"></i> <?php echo $error_message; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <div class="row">
            <!-- Main Content - Unpaid Orders -->
            <div class="col-lg-8">
                <?php if (empty($unpaid_orders)): ?>
                    <div class="no-orders">
                        <i class="fas fa-check-circle"></i>
                        <h3>No Unpaid Orders</h3>
                        <p>All orders have been paid! Great job!</p>
                    </div>
                <?php else: ?>
                    <div class="row">
                        <?php foreach ($unpaid_orders as $order): ?>
                            <div class="col-xl-6 col-lg-12 mb-3">
                                <div class="order-card" data-order-id="<?php echo $order['id']; ?>">
                                    <div class="order-header">
                                        <div class="row align-items-center">
                                            <div class="col-md-8">
                                                <h2 class="order-number">Order #<?php echo $order['order_number']; ?></h2>
                                                <p class="order-time">
                                                    <i class="fas fa-clock"></i> 
                                                    <?php echo date('H:i', strtotime($order['created_at'])); ?>
                                                </p>
                                                <h4 class="order-customer">
                                                    <i class="fas fa-user"></i> <?php echo htmlspecialchars($order['customer_name'] ?? 'Customer'); ?>
                                                </h4>
                                                <div class="order-table">
                                                    <i class="fas fa-table"></i> Table <?php echo htmlspecialchars($order['table_number'] ?? 'N/A'); ?>
                                                </div>
                                            </div>
                                            <div class="col-md-4 text-end">
                                                <div class="status-badge">
                                                    <span class="badge bg-warning fs-4"><?php echo strtoupper($order['status']); ?></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="order-body">
                                        <div class="items-section">
                                            <h3 class="items-title">
                                                <i class="fas fa-list"></i> ORDER ITEMS (<?php echo $order['item_count']; ?> items)
                                            </h3>
                                            
                                            <?php if (isset($grouped_items[$order['id']])): ?>
                                                <?php foreach ($grouped_items[$order['id']] as $item): ?>
                                                    <div class="item-row">
                                                        <div class="item-name">
                                                            <i class="fas fa-utensils"></i> <?php echo htmlspecialchars($item['item_name'] ?? 'Item'); ?>
                                                        </div>
                                                        <div class="item-quantity">
                                                            <?php echo $item['quantity']; ?>
                                                        </div>
                                                    </div>
                                                <?php endforeach; ?>
                                            <?php endif; ?>
                                        </div>

                                        <div class="payment-section">
                                            <div class="payment-amount">
                                                <i class="fas fa-rupee-sign"></i> <?php echo number_format($order['total_amount'], 2); ?>
                                            </div>
                                            <div class="text-center text-muted">
                                                <small>Total Amount to be Paid</small>
                                            </div>
                                        </div>
                                        
                                        <div class="order-actions">
                                            <button class="status-btn btn-receipt" onclick="generateReceipt(<?php echo $order['id']; ?>)">
                                                <i class="fas fa-print"></i> GENERATE RECEIPT
                                            </button>
                                            <button class="status-btn btn-paid" onclick="markAsPaid(<?php echo $order['id']; ?>)">
                                                <i class="fas fa-check"></i> MARK AS PAID
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Sidebar - Kitchen Orders -->
            <div class="col-lg-4">
                <div class="kitchen-sidebar">
                    <div class="sidebar-title">
                        <i class="fas fa-utensils"></i> KITCHEN ORDERS
                    </div>
                    
                    <?php if (empty($kitchen_orders)): ?>
                        <div class="no-kitchen-orders">
                            <i class="fas fa-check-circle"></i>
                            <p>No orders in kitchen</p>
                        </div>
                    <?php else: ?>
                        <?php foreach ($kitchen_orders as $kitchen_order): ?>
                            <div class="kitchen-order-card <?php echo $kitchen_order['status']; ?>" data-order-id="<?php echo $kitchen_order['id']; ?>">
                                <div class="kitchen-order-number">Order #<?php echo $kitchen_order['order_number']; ?></div>
                                <div class="kitchen-order-customer">
                                    <i class="fas fa-user"></i> <?php echo htmlspecialchars($kitchen_order['customer_name'] ?? 'Customer'); ?>
                                </div>
                                <div class="kitchen-order-table">
                                    <i class="fas fa-table"></i> Table <?php echo htmlspecialchars($kitchen_order['table_number'] ?? 'N/A'); ?>
                                </div>
                                <div class="kitchen-order-status <?php echo $kitchen_order['status']; ?>">
                                    <?php echo strtoupper($kitchen_order['status']); ?>
                                </div>
                                <div class="kitchen-order-time">
                                    <i class="fas fa-clock"></i> <?php echo date('H:i', strtotime($kitchen_order['created_at'])); ?>
                                </div>
                                <button class="mark-ready-btn" onclick="markAsReady(<?php echo $kitchen_order['id']; ?>)">
                                    <i class="fas fa-check"></i> ORDER IS READY
                                </button>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        // Auto-refresh page every 20 seconds
        setInterval(function() {
            location.reload();
        }, 20000);

        // Mark order as paid
        function markAsPaid(orderId) {
            if (confirm('Are you sure you want to mark this order as paid?')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="action" value="mark_paid">
                    <input type="hidden" name="order_id" value="${orderId}">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }

        // Generate receipt
        function generateReceipt(orderId) {
            // Open receipt in new window for printing
            const receiptWindow = window.open(`receipt.php?order_id=${orderId}`, '_blank', 'width=400,height=600');
            receiptWindow.focus();
        }

        // Mark order as ready (moves from kitchen to unpaid orders)
        function markAsReady(orderId) {
            if (confirm('Mark this order as ready for payment?')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="action" value="mark_ready">
                    <input type="hidden" name="order_id" value="${orderId}">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }
    </script>
    <?php include 'includes/footer.php'; ?>
