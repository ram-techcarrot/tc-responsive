<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    // Store the current page URL for redirect after login
    $current_page = $_SERVER['REQUEST_URI'];
    $_SESSION['redirect_after_login'] = $current_page;
    
    header('Location: ../auth/login.php');
    exit();
}

// Check session timeout (optional - 2 hours)
$session_timeout = 7200; // 2 hours in seconds
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $session_timeout)) {
    // Session expired
    session_unset();
    session_destroy();
    header('Location: ../auth/login.php?expired=1');
    exit();
}

// Update last activity time
$_SESSION['last_activity'] = time();

// Check if user has admin role (optional security check)
if (isset($_SESSION['role']) && $_SESSION['role'] !== 'admin') {
    // Log out non-admin users
    session_unset();
    session_destroy();
    header('Location: ../auth/login.php?unauthorized=1');
    exit();
}
?>
