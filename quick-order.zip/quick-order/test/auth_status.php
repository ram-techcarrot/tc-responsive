<?php
session_start();

echo "<!DOCTYPE html>";
echo "<html><head><title>Authentication Status</title>";
echo "<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css' rel='stylesheet'>";
echo "</head><body class='bg-light'>";

echo "<div class='container mt-5'>";
echo "<div class='row justify-content-center'>";
echo "<div class='col-md-8'>";
echo "<div class='card'>";
echo "<div class='card-header'>";
echo "<h3><i class='fas fa-user-check'></i> Authentication Status</h3>";
echo "</div>";
echo "<div class='card-body'>";

if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
    echo "<div class='alert alert-success'>";
    echo "<h4>✅ User is Logged In</h4>";
    echo "</div>";
    
    echo "<div class='row'>";
    echo "<div class='col-md-6'>";
    echo "<h5>Session Information:</h5>";
    echo "<table class='table table-striped'>";
    echo "<tr><td><strong>User ID:</strong></td><td>" . ($_SESSION['user_id'] ?? 'N/A') . "</td></tr>";
    echo "<tr><td><strong>Username:</strong></td><td>" . htmlspecialchars($_SESSION['username'] ?? 'N/A') . "</td></tr>";
    echo "<tr><td><strong>Role:</strong></td><td>" . htmlspecialchars($_SESSION['role'] ?? 'N/A') . "</td></tr>";
    echo "<tr><td><strong>Last Activity:</strong></td><td>" . (isset($_SESSION['last_activity']) ? date('Y-m-d H:i:s', $_SESSION['last_activity']) : 'N/A') . "</td></tr>";
    echo "<tr><td><strong>Session ID:</strong></td><td>" . session_id() . "</td></tr>";
    echo "</table>";
    echo "</div>";
    
    echo "<div class='col-md-6'>";
    echo "<h5>Quick Actions:</h5>";
    echo "<div class='d-grid gap-2'>";
    echo "<a href='backend/admin/dashboard.php' class='btn btn-primary'>Admin Dashboard</a>";
    echo "<a href='backend/admin/orders.php' class='btn btn-success'>Manage Orders</a>";
    echo "<a href='backend/auth/logout.php' class='btn btn-danger'>Logout</a>";
    echo "</div>";
    echo "</div>";
    echo "</div>";
    
} else {
    echo "<div class='alert alert-warning'>";
    echo "<h4>⚠️ User is NOT Logged In</h4>";
    echo "<p>No active session found. Please login to access admin features.</p>";
    echo "</div>";
    
    echo "<div class='text-center'>";
    echo "<a href='backend/auth/login.php' class='btn btn-primary btn-lg'>";
    echo "<i class='fas fa-sign-in-alt'></i> Login to Admin Panel";
    echo "</a>";
    echo "</div>";
}

echo "<hr>";
echo "<div class='text-center'>";
echo "<a href='quick-access.html' class='btn btn-outline-secondary'>← Back to Quick Access</a>";
echo "</div>";

echo "</div></div></div></div></div>";

echo "<script src='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js'></script>";
echo "<script src='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/js/all.min.js'></script>";
echo "</body></html>";
?>
