<?php
/**
 * Frontend Directory Index
 * Redirects to ordering system
 */

header('Location: ordering.php');
exit();
?>
