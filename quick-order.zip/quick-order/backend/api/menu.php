<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

try {
    // Get categories
    $query = "SELECT * FROM categories WHERE is_active = 1 ORDER BY sort_order, name";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $categories = $stmt->fetchAll();
    
    // Get menu items with categories
    $query = "SELECT mi.*, c.name as category_name FROM menu_items mi 
              LEFT JOIN categories c ON mi.category_id = c.id 
              WHERE mi.is_available = 1
              ORDER BY c.sort_order, mi.sort_order, mi.name";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $menu_items = $stmt->fetchAll();
    
    echo json_encode([
        'success' => true,
        'categories' => $categories,
        'menu_items' => $menu_items
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Failed to fetch menu data',
        'error' => $e->getMessage()
    ]);
}
?>
