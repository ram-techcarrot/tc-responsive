<?php
require_once 'backend/auth/protect.php';
require_once 'backend/config/database.php';

echo "<!DOCTYPE html>";
echo "<html><head><title>Authentication Test</title>";
echo "<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css' rel='stylesheet'>";
echo "</head><body class='bg-light'>";

echo "<div class='container mt-5'>";
echo "<div class='row justify-content-center'>";
echo "<div class='col-md-8'>";
echo "<div class='card'>";
echo "<div class='card-header'>";
echo "<h3><i class='fas fa-shield-alt'></i> Authentication Test Page</h3>";
echo "</div>";
echo "<div class='card-body'>";

echo "<div class='alert alert-success'>";
echo "<h4>✅ Authentication Successful!</h4>";
echo "<p>You are successfully logged in and can access this protected page.</p>";
echo "</div>";

echo "<div class='row'>";
echo "<div class='col-md-6'>";
echo "<h5>Session Information:</h5>";
echo "<ul class='list-group'>";
echo "<li class='list-group-item'><strong>User ID:</strong> " . $_SESSION['user_id'] . "</li>";
echo "<li class='list-group-item'><strong>Username:</strong> " . htmlspecialchars($_SESSION['username']) . "</li>";
echo "<li class='list-group-item'><strong>Role:</strong> " . htmlspecialchars($_SESSION['role']) . "</li>";
echo "<li class='list-group-item'><strong>Login Time:</strong> " . date('Y-m-d H:i:s', $_SESSION['last_activity']) . "</li>";
echo "</ul>";
echo "</div>";

echo "<div class='col-md-6'>";
echo "<h5>Quick Actions:</h5>";
echo "<div class='d-grid gap-2'>";
echo "<a href='backend/admin/dashboard.php' class='btn btn-primary'>";
echo "<i class='fas fa-tachometer-alt'></i> Admin Dashboard";
echo "</a>";
echo "<a href='backend/admin/orders.php' class='btn btn-success'>";
echo "<i class='fas fa-shopping-cart'></i> Manage Orders";
echo "</a>";
echo "<a href='backend/admin/menu.php' class='btn btn-info'>";
echo "<i class='fas fa-book'></i> Manage Menu";
echo "</a>";
echo "<a href='backend/auth/logout.php' class='btn btn-danger'>";
echo "<i class='fas fa-sign-out-alt'></i> Logout";
echo "</a>";
echo "</div>";
echo "</div>";
echo "</div>";

echo "<hr>";
echo "<div class='alert alert-info'>";
echo "<h5><i class='fas fa-info-circle'></i> Authentication Features:</h5>";
echo "<ul>";
echo "<li>✅ Session-based authentication</li>";
echo "<li>✅ Automatic redirect to login page</li>";
echo "<li>✅ Session timeout protection (2 hours)</li>";
echo "<li>✅ Role-based access control</li>";
echo "<li>✅ Redirect back to original page after login</li>";
echo "<li>✅ Secure logout with session cleanup</li>";
echo "</ul>";
echo "</div>";

echo "</div></div></div></div></div>";

echo "<script src='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js'></script>";
echo "<script src='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/js/all.min.js'></script>";
echo "</body></html>";
?>
