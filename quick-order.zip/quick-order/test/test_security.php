<?php
echo "<!DOCTYPE html>";
echo "<html><head><title>Security Test</title>";
echo "<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css' rel='stylesheet'>";
echo "</head><body class='bg-light'>";

echo "<div class='container mt-5'>";
echo "<div class='row justify-content-center'>";
echo "<div class='col-md-10'>";
echo "<div class='card'>";
echo "<div class='card-header'>";
echo "<h3><i class='fas fa-shield-alt'></i> Security Configuration Test</h3>";
echo "</div>";
echo "<div class='card-body'>";

echo "<div class='alert alert-info'>";
echo "<h5><i class='fas fa-info-circle'></i> Security Features Implemented</h5>";
echo "<p>This page tests the security configuration of the Quick Order system.</p>";
echo "</div>";

echo "<div class='row'>";
echo "<div class='col-md-6'>";
echo "<h5>🔒 Protected Directories</h5>";
echo "<ul class='list-group'>";
echo "<li class='list-group-item list-group-item-danger'>";
echo "<i class='fas fa-ban'></i> /backend/config/ - Access Denied";
echo "</li>";
echo "<li class='list-group-item list-group-item-danger'>";
echo "<i class='fas fa-ban'></i> /backend/sql/ - Access Denied";
echo "</li>";
echo "<li class='list-group-item list-group-item-danger'>";
echo "<i class='fas fa-ban'></i> /css/ - Access Denied";
echo "</li>";
echo "<li class='list-group-item list-group-item-danger'>";
echo "<i class='fas fa-ban'></i> /js/ - Access Denied";
echo "</li>";
echo "<li class='list-group-item list-group-item-danger'>";
echo "<i class='fas fa-ban'></i> /image/ - Access Denied";
echo "</li>";
echo "</ul>";
echo "</div>";

echo "<div class='col-md-6'>";
echo "<h5>✅ Smart Redirects</h5>";
echo "<ul class='list-group'>";
echo "<li class='list-group-item list-group-item-success'>";
echo "<i class='fas fa-home'></i> / - Smart redirect based on login";
echo "</li>";
echo "<li class='list-group-item list-group-item-success'>";
echo "<i class='fas fa-cogs'></i> /backend/ - Login or Dashboard";
echo "</li>";
echo "<li class='list-group-item list-group-item-success'>";
echo "<i class='fas fa-shopping-cart'></i> /frontend/ - Ordering System";
echo "</li>";
echo "<li class='list-group-item list-group-item-success'>";
echo "<i class='fas fa-user-shield'></i> /backend/admin/ - Dashboard";
echo "</li>";
echo "<li class='list-group-item list-group-item-success'>";
echo "<i class='fas fa-sign-in-alt'></i> /backend/auth/ - Login";
echo "</li>";
echo "</ul>";
echo "</div>";
echo "</div>";

echo "<hr>";

echo "<h5>🧪 Test Links</h5>";
echo "<p>Click these links to test the security configuration:</p>";

echo "<div class='row'>";
echo "<div class='col-md-6'>";
echo "<h6>Protected Areas (Should show 403):</h6>";
echo "<div class='d-grid gap-2'>";
echo "<a href='backend/config/' class='btn btn-outline-danger btn-sm' target='_blank'>";
echo "<i class='fas fa-ban'></i> Test /backend/config/";
echo "</a>";
echo "<a href='backend/sql/' class='btn btn-outline-danger btn-sm' target='_blank'>";
echo "<i class='fas fa-ban'></i> Test /backend/sql/";
echo "</a>";
echo "<a href='css/' class='btn btn-outline-danger btn-sm' target='_blank'>";
echo "<i class='fas fa-ban'></i> Test /css/";
echo "</a>";
echo "</div>";
echo "</div>";

echo "<div class='col-md-6'>";
echo "<h6>Smart Redirects:</h6>";
echo "<div class='d-grid gap-2'>";
echo "<a href='backend/' class='btn btn-outline-success btn-sm' target='_blank'>";
echo "<i class='fas fa-arrow-right'></i> Test /backend/";
echo "</a>";
echo "<a href='frontend/' class='btn btn-outline-success btn-sm' target='_blank'>";
echo "<i class='fas fa-arrow-right'></i> Test /frontend/";
echo "</a>";
echo "<a href='backend/admin/' class='btn btn-outline-success btn-sm' target='_blank'>";
echo "<i class='fas fa-arrow-right'></i> Test /backend/admin/";
echo "</a>";
echo "</div>";
echo "</div>";
echo "</div>";

echo "<hr>";

echo "<div class='alert alert-success'>";
echo "<h5><i class='fas fa-check-circle'></i> Security Status: PROTECTED</h5>";
echo "<ul class='mb-0'>";
echo "<li>✅ Directory indexing disabled</li>";
echo "<li>✅ Sensitive files protected</li>";
echo "<li>✅ Smart redirects implemented</li>";
echo "<li>✅ Custom error pages configured</li>";
echo "<li>✅ Security headers enabled</li>";
echo "</ul>";
echo "</div>";

echo "<div class='text-center mt-4'>";
echo "<a href='quick-access.html' class='btn btn-primary'>";
echo "<i class='fas fa-home'></i> Back to Quick Access";
echo "</a>";
echo "</div>";

echo "</div></div></div></div></div>";

echo "<script src='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js'></script>";
echo "<script src='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/js/all.min.js'></script>";
echo "</body></html>";
?>
