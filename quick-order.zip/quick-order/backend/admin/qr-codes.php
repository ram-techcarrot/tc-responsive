<?php
require_once '../auth/check_auth.php';
require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

// Handle base URL input
$base_url = '';
$qr_codes = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['base_url'])) {
    $base_url = trim($_POST['base_url']);
    
    // Get all active tables
    $query = "SELECT * FROM tables WHERE is_active = 1 ORDER BY table_number";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $tables = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Generate QR codes for each table
    foreach ($tables as $table) {
        $qr_url = rtrim($base_url, '/') . '/ordering.php?table=' . urlencode($table['table_number']);
        $qr_codes[] = [
            'table_number' => $table['table_number'],
            'url' => $qr_url
        ];
    }
}
?>

<?php include 'includes/header.php'; ?>
    <style>
        .qr-container {
            background: white;
            border-radius: 15px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: 0 8px 32px rgba(0,0,0,0.1);
        }
        
        .url-input-section {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            border-radius: 15px;
            padding: 2rem;
            margin-bottom: 2rem;
            border: 2px dashed #dee2e6;
        }
        
        .url-input {
            font-size: 1.1rem;
            padding: 0.75rem 1rem;
            border-radius: 10px;
            border: 2px solid #dee2e6;
            width: 100%;
            max-width: 600px;
        }
        
        .url-input:focus {
            border-color: var(--admin-primary);
            box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
        }
        
        .generate-btn {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            border-radius: 10px;
            padding: 0.75rem 2rem;
            color: white;
            font-weight: 600;
            font-size: 1rem;
            transition: all 0.3s ease;
        }
        
        .generate-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.3);
        }
        
        /* A4 Print Styles */
        @media print {
            * {
                margin: 0 !important;
                padding: 0 !important;
            }
            
            body {
                margin: 0 !important;
                padding: 0 !important;
                background: white !important;
                font-family: Arial, sans-serif !important;
            }
            
            .container-fluid,
            .row,
            .col-md-9,
            .col-lg-10 {
                margin: 0 !important;
                padding: 0 !important;
                width: 100% !important;
                max-width: none !important;
            }
            
            .no-print,
            .sidebar,
            .navbar,
            .header,
            .btn,
            .url-input-section,
            .qr-container > h4,
            .qr-container > .d-flex {
                display: none !important;
            }
            
            .qr-grid {
                display: grid !important;
                grid-template-columns: repeat(2, 1fr) !important;
                gap: 20mm !important;
                padding: 15mm !important;
                page-break-inside: avoid;
                width: 100% !important;
                height: 100vh !important;
            }
            
            .qr-card {
                border: 2px solid #000 !important;
                border-radius: 8px !important;
                padding: 10mm !important;
                text-align: center !important;
                page-break-inside: avoid;
                height: 80mm !important;
                display: flex !important;
                flex-direction: column !important;
                justify-content: center !important;
                align-items: center !important;
                background: white !important;
                box-shadow: none !important;
            }
            
            .qr-code {
                width: 50mm !important;
                height: 50mm !important;
                margin-bottom: 5mm !important;
                border: 1px solid #ccc !important;
                padding: 2mm !important;
                background: white !important;
            }
            
            .table-number {
                font-size: 14pt !important;
                font-weight: bold !important;
                margin-bottom: 2mm !important;
                color: #000 !important;
            }
            
            .table-label {
                font-size: 10pt !important;
                color: #666 !important;
                margin-bottom: 2mm !important;
            }
            
            .restaurant-name {
                font-size: 12pt !important;
                font-weight: bold !important;
                margin-bottom: 3mm !important;
                color: #000 !important;
            }
            
            .scan-text {
                font-size: 8pt !important;
                color: #888 !important;
                margin-top: 2mm !important;
            }
            
            .qr-url {
                display: none !important;
            }
        }
        
        /* Screen Preview Styles */
        .qr-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-top: 2rem;
        }
        
        .qr-card {
            background: white;
            border: 2px solid #dee2e6;
            border-radius: 15px;
            padding: 1.5rem;
            text-align: center;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            transition: transform 0.2s ease;
        }
        
        .qr-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
        }
        
        .qr-code {
            width: 120px;
            height: 120px;
            margin: 0 auto 1rem;
            border: 1px solid #dee2e6;
            border-radius: 8px;
            padding: 0.5rem;
            background: white;
        }
        
        .table-number {
            font-size: 1.2rem;
            font-weight: bold;
            color: #2c3e50;
            margin-bottom: 0.5rem;
        }
        
        .table-label {
            font-size: 0.9rem;
            color: #6c757d;
            margin-bottom: 0.5rem;
        }
        
        .qr-url {
            font-size: 0.7rem;
            color: #adb5bd;
            word-break: break-all;
            margin-top: 0.5rem;
        }
        
        .print-btn {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            border: none;
            border-radius: 10px;
            padding: 0.75rem 2rem;
            color: white;
            font-weight: 600;
            font-size: 1rem;
            margin-top: 1rem;
            transition: all 0.3s ease;
        }
        
        .print-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(40, 167, 69, 0.3);
        }
        
        .restaurant-name {
            font-size: 1.1rem;
            font-weight: bold;
            color: #2c3e50;
            margin-bottom: 0.5rem;
        }
        
        .scan-text {
            font-size: 0.8rem;
            color: #6c757d;
            font-style: italic;
        }
    </style>

    <?php include 'includes/sidebar.php'; ?>
            
    <!-- Main Content -->
    <div class="col-md-9 col-lg-10 p-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2><i class="fas fa-qrcode"></i> QR Code Generator</h2>
            <div class="text-muted">
                Generate QR codes for all tables
            </div>
        </div>
        
        <!-- URL Input Section -->
        <div class="url-input-section no-print">
            <h4 class="mb-3">
                <i class="fas fa-link"></i> Enter Base URL
            </h4>
            <p class="text-muted mb-3">
                Enter your website's base URL. QR codes will be generated for each table with the format: <br>
                <code>YOUR_URL/ordering.php?table=TABLE_NUMBER</code>
            </p>
            
            <form method="POST">
                <div class="row">
                    <div class="col-md-8">
                        <input type="url" 
                               class="url-input" 
                               name="base_url" 
                               placeholder="https://yourdomain.com" 
                               value="<?php echo htmlspecialchars($base_url); ?>"
                               required>
                    </div>
                    <div class="col-md-4">
                        <button type="submit" class="generate-btn w-100">
                            <i class="fas fa-magic"></i> Generate QR Codes
                        </button>
                    </div>
                </div>
            </form>
        </div>
        
        <?php if (!empty($qr_codes)): ?>
            <!-- QR Codes Display -->
            <div class="qr-container">
                <div class="d-flex justify-content-between align-items-center mb-3 no-print">
                    <h4>
                        <i class="fas fa-table"></i> Table QR Codes 
                        <span class="badge bg-primary"><?php echo count($qr_codes); ?> Tables</span>
                    </h4>
                    <div>
                        <button onclick="testQRGeneration()" class="btn btn-outline-info me-2">
                            <i class="fas fa-bug"></i> Test QR
                        </button>
                        <button onclick="window.print()" class="print-btn">
                            <i class="fas fa-print"></i> Print QR Codes
                        </button>
                    </div>
                </div>
                
                <!-- Debug Info -->
                <div class="alert alert-info no-print" id="debugInfo" style="display: none;">
                    <h6><i class="fas fa-info-circle"></i> Debug Information</h6>
                    <div id="debugContent"></div>
                </div>
                
                <div class="qr-grid">
                    <?php foreach ($qr_codes as $qr): ?>
                        <div class="qr-card">
                            <div class="restaurant-name">SOBHA Restaurant</div>
                            <div class="qr-code" id="qr-<?php echo $qr['table_number']; ?>"></div>
                            <div class="table-number">Table <?php echo htmlspecialchars($qr['table_number']); ?></div>
                            <div class="table-label">Scan to Order</div>
                            <div class="scan-text">Point your camera at the QR code</div>
                            <div class="qr-url"><?php echo htmlspecialchars($qr['url']); ?></div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>
</div>

<!-- QR Code Generation Script -->
<script src="https://cdn.jsdelivr.net/npm/qrcode@1.5.3/build/qrcode.min.js"></script>
<script>
    <?php if (!empty($qr_codes)): ?>
    // Generate QR codes for each table
    document.addEventListener('DOMContentLoaded', function() {
        <?php foreach ($qr_codes as $qr): ?>
            const canvas = document.getElementById('qr-<?php echo $qr['table_number']; ?>');
            if (canvas) {
                QRCode.toCanvas(canvas, '<?php echo addslashes($qr['url']); ?>', {
                    width: 120,
                    height: 120,
                    color: {
                        dark: '#2c3e50',
                        light: '#ffffff'
                    },
                    margin: 1,
                    errorCorrectionLevel: 'M'
                }, function (error) {
                    if (error) {
                        console.error('QR Code generation error for table <?php echo $qr['table_number']; ?>:', error);
                        // Fallback: create a simple text display
                        canvas.innerHTML = '<div style="width: 120px; height: 120px; border: 2px solid #ccc; display: flex; align-items: center; justify-content: center; background: #f8f9fa; color: #666; font-size: 10px; text-align: center;">QR Code<br>Table <?php echo $qr['table_number']; ?></div>';
                    } else {
                        console.log('QR Code generated successfully for table <?php echo $qr['table_number']; ?>');
                    }
                });
            }
        <?php endforeach; ?>
    });
    
    // Test QR generation function
    function testQRGeneration() {
        const debugInfo = document.getElementById('debugInfo');
        const debugContent = document.getElementById('debugContent');
        
        let debugText = '<ul>';
        debugText += '<li>QRCode library loaded: ' + (typeof QRCode !== 'undefined' ? 'Yes' : 'No') + '</li>';
        
        <?php if (!empty($qr_codes)): ?>
            <?php foreach ($qr_codes as $qr): ?>
                const canvas<?php echo $qr['table_number']; ?> = document.getElementById('qr-<?php echo $qr['table_number']; ?>');
                debugText += '<li>Canvas for Table <?php echo $qr['table_number']; ?>: ' + (canvas<?php echo $qr['table_number']; ?> ? 'Found' : 'Not Found') + '</li>';
                if (canvas<?php echo $qr['table_number']; ?>) {
                    debugText += '<li>Canvas dimensions: ' + canvas<?php echo $qr['table_number']; ?>.offsetWidth + 'x' + canvas<?php echo $qr['table_number']; ?>.offsetHeight + '</li>';
                }
            <?php endforeach; ?>
        <?php endif; ?>
        
        debugText += '</ul>';
        debugContent.innerHTML = debugText;
        debugInfo.style.display = 'block';
        
        // Regenerate QR codes
        <?php if (!empty($qr_codes)): ?>
            <?php foreach ($qr_codes as $qr): ?>
                const canvas<?php echo $qr['table_number']; ?> = document.getElementById('qr-<?php echo $qr['table_number']; ?>');
                if (canvas<?php echo $qr['table_number']; ?>) {
                    // Clear canvas first
                    canvas<?php echo $qr['table_number']; ?>.innerHTML = '';
                    
                    QRCode.toCanvas(canvas<?php echo $qr['table_number']; ?>, '<?php echo addslashes($qr['url']); ?>', {
                        width: 120,
                        height: 120,
                        color: {
                            dark: '#000000',
                            light: '#ffffff'
                        },
                        margin: 1,
                        errorCorrectionLevel: 'M'
                    }, function (error) {
                        if (error) {
                            console.error('QR Code generation error for table <?php echo $qr['table_number']; ?>:', error);
                            canvas<?php echo $qr['table_number']; ?>.innerHTML = '<div style="width: 120px; height: 120px; border: 2px solid #ccc; display: flex; align-items: center; justify-content: center; background: #f8f9fa; color: #666; font-size: 10px; text-align: center;">QR Error<br>Table <?php echo $qr['table_number']; ?></div>';
                        } else {
                            console.log('QR Code regenerated successfully for table <?php echo $qr['table_number']; ?>');
                        }
                    });
                }
            <?php endforeach; ?>
        <?php endif; ?>
    }
    <?php endif; ?>
</script>

<?php include 'includes/footer.php'; ?>
