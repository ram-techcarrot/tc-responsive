<?php
echo "<!DOCTYPE html>";
echo "<html><head><title>Admin Status</title>";
echo "<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css' rel='stylesheet'>";
echo "<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css'>";
echo "</head><body class='bg-light'>";

echo "<div class='container mt-5'>";
echo "<div class='row justify-content-center'>";
echo "<div class='col-md-12'>";
echo "<div class='card'>";
echo "<div class='card-header'>";
echo "<h3><i class='fas fa-clipboard-check'></i> Admin Panel Status</h3>";
echo "</div>";
echo "<div class='card-body'>";

// Test database connection
echo "<h5>1. Database Status</h5>";
try {
    require_once 'backend/config/database.php';
    $database = new Database();
    $db = $database->getConnection();
    
    if ($db) {
        echo "<div class='alert alert-success'>";
        echo "<i class='fas fa-check-circle'></i> Database connection: <strong>WORKING</strong>";
        echo "</div>";
        
        // Check tables
        $tables = ['users', 'categories', 'menu_items', 'orders', 'tables', 'settings'];
        foreach ($tables as $table) {
            try {
                $query = "SELECT COUNT(*) as count FROM $table";
                $stmt = $db->prepare($query);
                $stmt->execute();
                $result = $stmt->fetch();
                echo "<div class='alert alert-info'>";
                echo "<i class='fas fa-table'></i> Table '$table': " . $result['count'] . " records";
                echo "</div>";
            } catch (Exception $e) {
                echo "<div class='alert alert-danger'>";
                echo "<i class='fas fa-times-circle'></i> Table '$table': ERROR - " . $e->getMessage();
                echo "</div>";
            }
        }
    } else {
        echo "<div class='alert alert-danger'>";
        echo "<i class='fas fa-times-circle'></i> Database connection: <strong>FAILED</strong>";
        echo "</div>";
    }
} catch (Exception $e) {
    echo "<div class='alert alert-danger'>";
    echo "<i class='fas fa-times-circle'></i> Database error: " . $e->getMessage();
    echo "</div>";
}

echo "<hr>";

// Check admin pages
echo "<h5>2. Admin Pages Status</h5>";
$admin_pages = [
    'dashboard.php' => 'Dashboard',
    'orders.php' => 'Orders Management',
    'menu.php' => 'Menu Management',
    'categories.php' => 'Categories Management',
    'tables.php' => 'Tables Management',
    'reports.php' => 'Reports',
    'settings.php' => 'Settings'
];

echo "<div class='row'>";
foreach ($admin_pages as $file => $name) {
    echo "<div class='col-md-6 col-lg-4 mb-3'>";
    echo "<div class='card'>";
    echo "<div class='card-body text-center'>";
    
    $file_path = "backend/admin/$file";
    
    if (file_exists($file_path)) {
        // Test syntax
        $output = shell_exec("php -l \"$file_path\" 2>&1");
        
        if (strpos($output, 'No syntax errors') !== false) {
            echo "<i class='fas fa-check-circle fa-2x text-success mb-2'></i>";
            echo "<h6 class='text-success'>$name</h6>";
            echo "<small class='text-muted'>Syntax: OK</small>";
            echo "<br><a href='$file_path' class='btn btn-sm btn-outline-primary mt-2' target='_blank'>";
            echo "<i class='fas fa-external-link-alt'></i> Open";
            echo "</a>";
        } else {
            echo "<i class='fas fa-exclamation-triangle fa-2x text-warning mb-2'></i>";
            echo "<h6 class='text-warning'>$name</h6>";
            echo "<small class='text-danger'>Syntax Error</small>";
        }
    } else {
        echo "<i class='fas fa-times-circle fa-2x text-danger mb-2'></i>";
        echo "<h6 class='text-danger'>$name</h6>";
        echo "<small class='text-danger'>File Missing</small>";
    }
    
    echo "</div></div></div>";
}
echo "</div>";

echo "<hr>";

// Authentication status
echo "<h5>3. Authentication Status</h5>";
$auth_files = [
    'backend/auth/login.php' => 'Login Page',
    'backend/auth/logout.php' => 'Logout Page',
    'backend/auth/check_auth.php' => 'Auth Check',
    'backend/auth/protect.php' => 'Protect Middleware'
];

echo "<div class='row'>";
foreach ($auth_files as $file => $name) {
    echo "<div class='col-md-6 col-lg-3 mb-3'>";
    echo "<div class='card'>";
    echo "<div class='card-body text-center'>";
    
    if (file_exists($file)) {
        $output = shell_exec("php -l \"$file\" 2>&1");
        
        if (strpos($output, 'No syntax errors') !== false) {
            echo "<i class='fas fa-check-circle fa-2x text-success mb-2'></i>";
            echo "<h6 class='text-success'>$name</h6>";
            echo "<small class='text-muted'>OK</small>";
        } else {
            echo "<i class='fas fa-exclamation-triangle fa-2x text-warning mb-2'></i>";
            echo "<h6 class='text-warning'>$name</h6>";
            echo "<small class='text-danger'>Error</small>";
        }
    } else {
        echo "<i class='fas fa-times-circle fa-2x text-danger mb-2'></i>";
        echo "<h6 class='text-danger'>$name</h6>";
        echo "<small class='text-danger'>Missing</small>";
    }
    
    echo "</div></div></div>";
}
echo "</div>";

echo "<hr>";

// Quick actions
echo "<h5>4. Quick Actions</h5>";
echo "<div class='row'>";
echo "<div class='col-md-6 mb-3'>";
echo "<div class='card'>";
echo "<div class='card-body text-center'>";
echo "<i class='fas fa-sign-in-alt fa-2x text-primary mb-2'></i>";
echo "<h6>Admin Login</h6>";
echo "<p class='text-muted'>Access the admin panel</p>";
echo "<a href='backend/auth/login.php' class='btn btn-primary' target='_blank'>";
echo "<i class='fas fa-sign-in-alt'></i> Login";
echo "</a>";
echo "</div></div></div>";

echo "<div class='col-md-6 mb-3'>";
echo "<div class='card'>";
echo "<div class='card-body text-center'>";
echo "<i class='fas fa-tags fa-2x text-success mb-2'></i>";
echo "<h6>Add Sample Data</h6>";
echo "<p class='text-muted'>Add sample categories</p>";
echo "<a href='add_sample_categories.php' class='btn btn-success' target='_blank'>";
echo "<i class='fas fa-plus'></i> Add Categories";
echo "</a>";
echo "</div></div></div>";
echo "</div>";

echo "<div class='row'>";
echo "<div class='col-md-6 mb-3'>";
echo "<div class='card'>";
echo "<div class='card-body text-center'>";
echo "<i class='fas fa-cogs fa-2x text-info mb-2'></i>";
echo "<h6>Test Backend</h6>";
echo "<p class='text-muted'>Test backend functionality</p>";
echo "<a href='test_backend.php' class='btn btn-info' target='_blank'>";
echo "<i class='fas fa-play'></i> Test";
echo "</a>";
echo "</div></div></div>";

echo "<div class='col-md-6 mb-3'>";
echo "<div class='card'>";
echo "<div class='card-body text-center'>";
echo "<i class='fas fa-home fa-2x text-secondary mb-2'></i>";
echo "<h6>Quick Access</h6>";
echo "<p class='text-muted'>Back to main hub</p>";
echo "<a href='quick-access.html' class='btn btn-secondary'>";
echo "<i class='fas fa-home'></i> Home";
echo "</a>";
echo "</div></div></div>";
echo "</div>";

echo "<hr>";

// Current credentials
echo "<div class='alert alert-info'>";
echo "<h6><i class='fas fa-key'></i> Current Admin Credentials</h6>";
echo "<p class='mb-0'><strong>Username:</strong> admin | <strong>Password:</strong> admin123</p>";
echo "</div>";

echo "</div></div></div></div></div>";

echo "<script src='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js'></script>";
echo "</body></html>";
?>
