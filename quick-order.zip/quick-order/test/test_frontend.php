<?php
echo "<!DOCTYPE html>";
echo "<html><head><title>Frontend Test</title>";
echo "<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css' rel='stylesheet'>";
echo "<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css'>";
echo "</head><body class='bg-light'>";

echo "<div class='container mt-5'>";
echo "<div class='row justify-content-center'>";
echo "<div class='col-md-10'>";
echo "<div class='card'>";
echo "<div class='card-header'>";
echo "<h3><i class='fas fa-globe'></i> Frontend System Test</h3>";
echo "</div>";
echo "<div class='card-body'>";

// Test API endpoints
echo "<h5>1. API Endpoints Test</h5>";

// Test menu API
echo "<div class='alert alert-info'>";
echo "<h6><i class='fas fa-book'></i> Menu API Test</h6>";
echo "<p>Testing: <code>backend/api/menu.php</code></p>";
echo "</div>";

try {
    $menu_response = file_get_contents('http://localhost/quick-order/backend/api/menu.php');
    $menu_data = json_decode($menu_response, true);
    
    if ($menu_data && $menu_data['success']) {
        echo "<div class='alert alert-success'>";
        echo "<i class='fas fa-check-circle'></i> Menu API working!";
        echo "<br><strong>Categories:</strong> " . count($menu_data['categories']);
        echo "<br><strong>Menu Items:</strong> " . count($menu_data['menu_items']);
        echo "</div>";
        
        // Show sample categories
        echo "<h6>Sample Categories:</h6>";
        echo "<div class='row'>";
        foreach (array_slice($menu_data['categories'], 0, 3) as $category) {
            echo "<div class='col-md-4 mb-2'>";
            echo "<div class='card'>";
            echo "<div class='card-body p-2'>";
            echo "<h6 class='mb-1'>" . htmlspecialchars($category['name']) . "</h6>";
            echo "<small class='text-muted'>Icon: " . htmlspecialchars($category['icon']) . "</small>";
            echo "</div></div></div>";
        }
        echo "</div>";
        
        // Show sample menu items
        echo "<h6>Sample Menu Items:</h6>";
        echo "<div class='row'>";
        foreach (array_slice($menu_data['menu_items'], 0, 3) as $item) {
            echo "<div class='col-md-4 mb-2'>";
            echo "<div class='card'>";
            echo "<div class='card-body p-2'>";
            echo "<h6 class='mb-1'>" . htmlspecialchars($item['name']) . "</h6>";
            echo "<small class='text-muted'>Rs. " . number_format($item['price'], 2) . "</small>";
            echo "</div></div></div>";
        }
        echo "</div>";
        
    } else {
        echo "<div class='alert alert-danger'>";
        echo "<i class='fas fa-times-circle'></i> Menu API failed!";
        echo "<br>Response: " . htmlspecialchars($menu_response);
        echo "</div>";
    }
} catch (Exception $e) {
    echo "<div class='alert alert-danger'>";
    echo "<i class='fas fa-times-circle'></i> Menu API error: " . $e->getMessage();
    echo "</div>";
}

echo "<hr>";

// Test orders API
echo "<h5>2. Orders API Test</h5>";
echo "<div class='alert alert-info'>";
echo "<h6><i class='fas fa-shopping-cart'></i> Orders API Test</h6>";
echo "<p>Testing: <code>backend/api/orders.php</code></p>";
echo "</div>";

try {
    // Test with a sample order number
    $order_response = file_get_contents('http://localhost/quick-order/backend/api/orders.php?order_number=ORD202412011234');
    
    if ($order_response) {
        $order_data = json_decode($order_response, true);
        
        if ($order_data && $order_data['success']) {
            echo "<div class='alert alert-success'>";
            echo "<i class='fas fa-check-circle'></i> Orders API working!";
            echo "<br><strong>Order Found:</strong> " . $order_data['order']['order_number'];
            echo "</div>";
        } else {
            echo "<div class='alert alert-warning'>";
            echo "<i class='fas fa-exclamation-triangle'></i> Orders API working (no test order found)";
            echo "<br>Response: " . htmlspecialchars($order_response);
            echo "</div>";
        }
    } else {
        echo "<div class='alert alert-danger'>";
        echo "<i class='fas fa-times-circle'></i> Orders API failed!";
        echo "</div>";
    }
} catch (Exception $e) {
    echo "<div class='alert alert-danger'>";
    echo "<i class='fas fa-times-circle'></i> Orders API error: " . $e->getMessage();
    echo "</div>";
}

echo "<hr>";

// Frontend pages test
echo "<h5>3. Frontend Pages Test</h5>";
echo "<div class='row'>";
echo "<div class='col-md-4 mb-3'>";
echo "<div class='card'>";
echo "<div class='card-body text-center'>";
echo "<i class='fas fa-home fa-2x text-primary mb-2'></i>";
echo "<h6>Landing Page</h6>";
echo "<p class='text-muted'>Static HTML page</p>";
echo "<a href='index.html' class='btn btn-primary btn-sm' target='_blank'>";
echo "<i class='fas fa-external-link-alt'></i> Test";
echo "</a>";
echo "</div></div></div>";

echo "<div class='col-md-4 mb-3'>";
echo "<div class='card'>";
echo "<div class='card-body text-center'>";
echo "<i class='fas fa-shopping-cart fa-2x text-success mb-2'></i>";
echo "<h6>Ordering Page</h6>";
echo "<p class='text-muted'>Dynamic PHP with API</p>";
echo "<a href='ordering.php' class='btn btn-success btn-sm' target='_blank'>";
echo "<i class='fas fa-external-link-alt'></i> Test";
echo "</a>";
echo "</div></div></div>";

echo "<div class='col-md-4 mb-3'>";
echo "<div class='card'>";
echo "<div class='card-body text-center'>";
echo "<i class='fas fa-check-circle fa-2x text-info mb-2'></i>";
echo "<h6>Order Success</h6>";
echo "<p class='text-muted'>Dynamic PHP with status</p>";
echo "<a href='order-success.php' class='btn btn-info btn-sm' target='_blank'>";
echo "<i class='fas fa-external-link-alt'></i> Test";
echo "</a>";
echo "</div></div></div>";
echo "</div>";

echo "<hr>";

// Complete flow test
echo "<h5>4. Complete Ordering Flow Test</h5>";
echo "<div class='alert alert-info'>";
echo "<h6><i class='fas fa-list-ol'></i> Test Steps</h6>";
echo "<ol>";
echo "<li><strong>Landing Page:</strong> Click 'CLICK HERE' button to go to ordering</li>";
echo "<li><strong>Ordering Page:</strong> Browse categories and menu items</li>";
echo "<li><strong>Add to Cart:</strong> Click 'Add' buttons to add items to cart</li>";
echo "<li><strong>Cart Management:</strong> Adjust quantities, remove items</li>";
echo "<li><strong>Place Order:</strong> Click 'Place Order' and fill customer details</li>";
echo "<li><strong>Order Success:</strong> View order confirmation and status</li>";
echo "<li><strong>Admin Panel:</strong> Check order in admin dashboard</li>";
echo "</ol>";
echo "</div>";

echo "<div class='row'>";
echo "<div class='col-md-6 mb-3'>";
echo "<div class='card'>";
echo "<div class='card-body text-center'>";
echo "<i class='fas fa-play fa-2x text-success mb-2'></i>";
echo "<h6>Start Ordering Flow</h6>";
echo "<p class='text-muted'>Begin the complete ordering process</p>";
echo "<a href='index.html' class='btn btn-success' target='_blank'>";
echo "<i class='fas fa-play'></i> Start Flow";
echo "</a>";
echo "</div></div></div>";

echo "<div class='col-md-6 mb-3'>";
echo "<div class='card'>";
echo "<div class='card-body text-center'>";
echo "<i class='fas fa-tachometer-alt fa-2x text-primary mb-2'></i>";
echo "<h6>Admin Dashboard</h6>";
echo "<p class='text-muted'>Check orders in admin panel</p>";
echo "<a href='backend/admin/dashboard.php' class='btn btn-primary' target='_blank'>";
echo "<i class='fas fa-cog'></i> Admin Panel";
echo "</a>";
echo "</div></div></div>";
echo "</div>";

echo "<hr>";

// Features overview
echo "<h5>5. Frontend Features</h5>";
echo "<div class='row'>";
echo "<div class='col-md-6'>";
echo "<h6>✅ Working Features:</h6>";
echo "<ul>";
echo "<li>Dynamic menu loading from database</li>";
echo "<li>Category filtering</li>";
echo "<li>Search functionality</li>";
echo "<li>Add to cart with quantities</li>";
echo "<li>Cart management (add/remove/update)</li>";
echo "<li>Order placement with customer details</li>";
echo "<li>Real-time order status updates</li>";
echo "<li>Responsive design</li>";
echo "<li>Currency: Rs. (Rupees)</li>";
echo "</ul>";
echo "</div>";

echo "<div class='col-md-6'>";
echo "<h6>🔧 Technical Details:</h6>";
echo "<ul>";
echo "<li>Frontend: HTML5, CSS3, JavaScript</li>";
echo "<li>Backend: PHP with MySQL</li>";
echo "<li>API: RESTful endpoints</li>";
echo "<li>Framework: Bootstrap 5</li>";
echo "<li>Icons: Font Awesome</li>";
echo "<li>Auto-refresh: Order status updates</li>";
echo "<li>Local Storage: Order tracking</li>";
echo "<li>Responsive: Mobile-friendly</li>";
echo "</ul>";
echo "</div>";
echo "</div>";

echo "<div class='text-center mt-4'>";
echo "<a href='quick-access.html' class='btn btn-secondary'>";
echo "<i class='fas fa-home'></i> Back to Quick Access";
echo "</a>";
echo "</div>";

echo "</div></div></div></div></div>";

echo "<script src='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js'></script>";
echo "</body></html>";
?>
