<?php
echo "<!DOCTYPE html>";
echo "<html><head><title>Admin Pages Test</title>";
echo "<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css' rel='stylesheet'>";
echo "<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css'>";
echo "</head><body class='bg-light'>";

echo "<div class='container mt-5'>";
echo "<div class='row justify-content-center'>";
echo "<div class='col-md-10'>";
echo "<div class='card'>";
echo "<div class='card-header'>";
echo "<h3><i class='fas fa-cogs'></i> Admin Pages Test</h3>";
echo "</div>";
echo "<div class='card-body'>";

// Test database connection first
echo "<h5>1. Database Connection Test</h5>";
try {
    require_once 'backend/config/database.php';
    $database = new Database();
    $db = $database->getConnection();
    
    if ($db) {
        echo "<div class='alert alert-success'>";
        echo "<i class='fas fa-check-circle'></i> Database connection successful!";
        echo "</div>";
    } else {
        echo "<div class='alert alert-danger'>";
        echo "<i class='fas fa-times-circle'></i> Database connection failed!";
        echo "</div>";
    }
} catch (Exception $e) {
    echo "<div class='alert alert-danger'>";
    echo "<i class='fas fa-times-circle'></i> Database error: " . $e->getMessage();
    echo "</div>";
}

echo "<hr>";

// Test each admin page
$admin_pages = [
    'dashboard.php' => 'Dashboard',
    'orders.php' => 'Orders Management',
    'menu.php' => 'Menu Management',
    'categories.php' => 'Categories Management',
    'tables.php' => 'Tables Management',
    'reports.php' => 'Reports',
    'settings.php' => 'Settings'
];

echo "<h5>2. Admin Pages Test</h5>";
echo "<p>Testing each admin page for syntax errors and basic functionality:</p>";

echo "<div class='row'>";
foreach ($admin_pages as $file => $name) {
    echo "<div class='col-md-6 mb-3'>";
    echo "<div class='card'>";
    echo "<div class='card-body'>";
    
    $file_path = "backend/admin/$file";
    
    if (file_exists($file_path)) {
        // Test syntax
        $output = shell_exec("php -l \"$file_path\" 2>&1");
        
        if (strpos($output, 'No syntax errors') !== false) {
            echo "<div class='d-flex justify-content-between align-items-center'>";
            echo "<h6 class='mb-0'><i class='fas fa-check-circle text-success'></i> $name</h6>";
            echo "<span class='badge bg-success'>OK</span>";
            echo "</div>";
            echo "<small class='text-muted'>File: $file</small>";
        } else {
            echo "<div class='d-flex justify-content-between align-items-center'>";
            echo "<h6 class='mb-0'><i class='fas fa-exclamation-triangle text-warning'></i> $name</h6>";
            echo "<span class='badge bg-warning'>Check</span>";
            echo "</div>";
            echo "<small class='text-danger'>Syntax issue: " . htmlspecialchars($output) . "</small>";
        }
    } else {
        echo "<div class='d-flex justify-content-between align-items-center'>";
        echo "<h6 class='mb-0'><i class='fas fa-times-circle text-danger'></i> $name</h6>";
        echo "<span class='badge bg-danger'>Missing</span>";
        echo "</div>";
        echo "<small class='text-danger'>File not found: $file_path</small>";
    }
    
    echo "</div></div></div>";
}
echo "</div>";

echo "<hr>";

// Test authentication files
echo "<h5>3. Authentication Files Test</h5>";
$auth_files = [
    'backend/auth/login.php' => 'Login Page',
    'backend/auth/logout.php' => 'Logout Page',
    'backend/auth/check_auth.php' => 'Auth Check',
    'backend/auth/protect.php' => 'Protect Middleware'
];

echo "<div class='row'>";
foreach ($auth_files as $file => $name) {
    echo "<div class='col-md-6 mb-3'>";
    echo "<div class='card'>";
    echo "<div class='card-body'>";
    
    if (file_exists($file)) {
        $output = shell_exec("php -l \"$file\" 2>&1");
        
        if (strpos($output, 'No syntax errors') !== false) {
            echo "<div class='d-flex justify-content-between align-items-center'>";
            echo "<h6 class='mb-0'><i class='fas fa-check-circle text-success'></i> $name</h6>";
            echo "<span class='badge bg-success'>OK</span>";
            echo "</div>";
        } else {
            echo "<div class='d-flex justify-content-between align-items-center'>";
            echo "<h6 class='mb-0'><i class='fas fa-exclamation-triangle text-warning'></i> $name</h6>";
            echo "<span class='badge bg-warning'>Check</span>";
            echo "</div>";
            echo "<small class='text-danger'>" . htmlspecialchars($output) . "</small>";
        }
    } else {
        echo "<div class='d-flex justify-content-between align-items-center'>";
        echo "<h6 class='mb-0'><i class='fas fa-times-circle text-danger'></i> $name</h6>";
        echo "<span class='badge bg-danger'>Missing</span>";
        echo "</div>";
    }
    
    echo "</div></div></div>";
}
echo "</div>";

echo "<hr>";

// Direct links to test pages
echo "<h5>4. Direct Access Test</h5>";
echo "<p>Click these links to test direct access to admin pages:</p>";

echo "<div class='row'>";
foreach ($admin_pages as $file => $name) {
    echo "<div class='col-md-6 mb-2'>";
    echo "<a href='backend/admin/$file' class='btn btn-outline-primary btn-sm w-100' target='_blank'>";
    echo "<i class='fas fa-external-link-alt'></i> $name";
    echo "</a>";
    echo "</div>";
}
echo "</div>";

echo "<hr>";

// Login test
echo "<h5>5. Login Test</h5>";
echo "<div class='alert alert-info'>";
echo "<h6><i class='fas fa-info-circle'></i> Test Login Access</h6>";
echo "<p>To test admin pages, you need to login first:</p>";
echo "<ul>";
echo "<li><strong>Username:</strong> admin</li>";
echo "<li><strong>Password:</strong> admin123</li>";
echo "</ul>";
echo "<a href='backend/auth/login.php' class='btn btn-primary' target='_blank'>";
echo "<i class='fas fa-sign-in-alt'></i> Go to Login Page";
echo "</a>";
echo "</div>";

echo "<div class='text-center mt-4'>";
echo "<a href='quick-access.html' class='btn btn-secondary'>";
echo "<i class='fas fa-home'></i> Back to Quick Access";
echo "</a>";
echo "</div>";

echo "</div></div></div></div></div>";

echo "<script src='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js'></script>";
echo "</body></html>";
?>
