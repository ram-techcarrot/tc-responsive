<?php
/**
 * API Directory Index
 * Returns API information
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

echo json_encode([
    'success' => true,
    'message' => 'Quick Order API',
    'version' => '1.0',
    'endpoints' => [
        'GET /menu.php' => 'Fetch menu data with categories',
        'GET /tables.php' => 'Fetch available tables',
        'POST /orders.php' => 'Create new order',
        'GET /orders.php?order_number=XXX' => 'Get order status'
    ],
    'documentation' => 'See README.md for API documentation'
]);
?>
