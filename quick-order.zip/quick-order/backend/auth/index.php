<?php
/**
 * Auth Directory Index
 * Redirects to login page
 */

header('Location: login.php');
exit();
?>
