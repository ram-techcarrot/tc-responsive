<?php
require_once 'backend/config/database.php';

$database = new Database();
$db = $database->getConnection();

// Get table number from URL parameter
$table_number = $_GET['table'] ?? '';
$is_table_locked = !empty($table_number);

$categories = [];
$menu_items = [];

try {
    // Get categories
    $query = "SELECT * FROM categories WHERE is_active = 1 ORDER BY sort_order, name";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get menu items with categories
    $query = "SELECT mi.*, c.name as category_name FROM menu_items mi 
              LEFT JOIN categories c ON mi.category_id = c.id 
              WHERE mi.is_available = 1
              ORDER BY c.sort_order, mi.sort_order, mi.name";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $menu_items = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (Exception $e) {
    error_log("Error fetching menu data: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sobha - Order Online</title>
    
    <!-- Bootstrap 5 CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Swiper CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css" />
    
    <!-- Font Awesome for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Custom CSS -->
    <link href="css/ordering-styles.css" rel="stylesheet">
    
    <style>
        /* Price tile styling */
        .item-name-price {
            display: flex;
            align-items: center;
            justify-content: space-between;
            width: 100%;
            margin-bottom: 0.5rem;
        }

        .price-tile {
            background: linear-gradient(135deg, var(--sobha-gold), #F3D487);
            color: var(--sobha-dark);
            font-size: 0.9rem;
            font-weight: 800;
            padding: 0.4rem 0.8rem;
            border-radius: 8px;
            text-align: center;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
            border: 1px solid rgba(255, 255, 255, 0.2);
            min-width: 60px;
            display: inline-block;
            margin: 0;
            flex-shrink: 0;
        }
        
        /* Cart price styling */
        .item-price-info {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin: 5px 0;
            font-size: 0.9rem;
        }
        
        .unit-price {
            color: #666;
            font-size: 0.8rem;
        }
        
        .item-total {
            font-weight: bold;
            color: #28a745;
        }
        
        .grand-total {
            font-weight: bold;
            font-size: 1.1rem;
            color: #007bff;
            margin-top: 5px;
        }
        
        .total-items {
            text-align: center;
            padding: 10px;
        }
        
        /* Cart totals styling */
        .cart-totals {
            display: flex;
            flex-direction: column;
            align-items: flex-end;
            margin-left: auto;
        }
        
        .cart-item-count {
            font-size: 0.9rem;
            color: #666;
            margin-bottom: 2px;
        }
        
        .cart-total-amount {
            font-size: 1.1rem;
            font-weight: bold;
            color: var(--sobha-gold);
        }
        
        .cart-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        
        /* Search functionality styling */
        .search-input {
            transition: all 0.3s ease;
        }
        
        .search-input:focus {
            border-color: var(--sobha-gold);
            box-shadow: 0 0 0 0.2rem rgba(212, 175, 55, 0.25);
        }
        
        .no-results-message {
            grid-column: 1 / -1;
            margin: 2rem 0;
        }
        
        .menu-item-card[style*="display: none"] {
            display: none !important;
        }
        
        .nav-link[style*="display: none"] {
            display: none !important;
        }
        
        .tab-pane[style*="display: none"] {
            display: none !important;
        }
        
        /* Modal styling with theme gradient */
        .modal-content {
            background: linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 50%, #1a1a1a 100%);
            border: 1px solid var(--sobha-gold);
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
        }
        
        .modal-header {
            background: linear-gradient(135deg, var(--sobha-gold) 0%, #F3D487 100%);
            color: var(--sobha-dark);
            border-bottom: 1px solid var(--sobha-gold);
            border-radius: 15px 15px 0 0;
        }
        
        .modal-title {
            font-weight: 700;
            color: var(--sobha-dark);
        }
        
        .btn-close {
            filter: brightness(0) saturate(100%);
        }
        
        .modal-body {
            background: transparent;
            color: var(--sobha-white);
        }
        
        .modal-footer {
            background: linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%);
            border-top: 1px solid var(--sobha-gold);
            border-radius: 0 0 15px 15px;
        }
        
        .form-label {
            color: var(--sobha-white);
            font-weight: 600;
        }
        
        .form-control {
            background-color: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(212, 175, 55, 0.3);
            color: var(--sobha-white);
            border-radius: 8px;
        }
        
        .form-control:focus {
            background-color: rgba(255, 255, 255, 0.15);
            border-color: var(--sobha-gold);
            box-shadow: 0 0 0 0.2rem rgba(212, 175, 55, 0.25);
            color: var(--sobha-white);
        }
        
        .form-control::placeholder {
            color: rgba(255, 255, 255, 0.6);
        }
        
        .order-summary {
            background: rgba(212, 175, 55, 0.1);
            border: 1px solid rgba(212, 175, 55, 0.3);
            border-radius: 10px;
            padding: 1rem;
            margin-top: 1rem;
        }
        
        .order-summary h6 {
            color: var(--sobha-gold);
            font-weight: 700;
        }
        
        .order-item-row {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 8px;
            border: 1px solid rgba(212, 175, 55, 0.2) !important;
        }
        
        .order-totals {
            background: rgba(0, 0, 0, 0.3);
            border-radius: 8px;
            padding: 1rem;
            margin-top: 1rem;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, var(--sobha-gold) 0%, #F3D487 100%);
            border: 1px solid var(--sobha-gold);
            color: var(--sobha-dark);
            font-weight: 700;
            border-radius: 8px;
        }
        
        .btn-primary:hover {
            background: linear-gradient(135deg, #F3D487 0%, var(--sobha-gold) 100%);
            border-color: #F3D487;
            color: var(--sobha-dark);
        }
        
        /* Table input readonly styling */
        #tableNumber[readonly] {
            background-color: rgba(212, 175, 55, 0.1);
            border-color: var(--sobha-gold);
            color: var(--sobha-dark);
            font-weight: 600;
        }
        
        .table-lock-indicator {
            display: block;
            margin-top: 0.25rem;
            font-size: 0.8rem;
        }
        
        /* Table indicator badge */
        .table-indicator {
            margin-left: 1rem;
        }
        
        .table-badge {
            background: linear-gradient(135deg, var(--sobha-gold) 0%, #F3D487 100%);
            color: var(--sobha-dark);
            padding: 0.5rem 1rem;
            border-radius: 25px;
            font-weight: 600;
            font-size: 0.9rem;
            box-shadow: 0 2px 8px rgba(212, 175, 55, 0.3);
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .table-badge i {
            font-size: 1rem;
        }
        
        .btn-secondary {
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.3);
            color: var(--sobha-white);
            border-radius: 8px;
        }
        
        .btn-secondary:hover {
            background: rgba(255, 255, 255, 0.2);
            border-color: rgba(255, 255, 255, 0.5);
            color: var(--sobha-white);
        }
    </style>
</head>
<body>
    <!-- Header Section -->
    <header class="ordering-header">
        <div class="container">
            <div class="row align-items-center">
                <!-- Logo Section -->
                <div class="col-auto">
                    <div class="logo-section ">
                        <a href="index.html" class="logo-link">
                            <img src="image/sobha-logo.svg" alt="SOBHA Realty" class="sobha-logo">
                        </a>
                    </div>
                </div>
                
                <!-- Search Section -->
                <div class="col">
                    <div class="search-section">
                        <div class="search-container">
                            <input type="text" class="search-input" id="menuSearchInput" placeholder="Search menu items or categories...">
                            <i class="fas fa-search search-icon"></i>
                        </div>
                    </div>
                </div>
                
                <!-- Table Indicator -->
                <?php if ($is_table_locked): ?>
                <div class="col-auto">
                    <div class="table-indicator">
                        <span class="table-badge">
                            <i class="fas fa-table"></i> Table <?php echo htmlspecialchars($table_number); ?>
                        </span>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </header>

    <!-- Main Content Area -->
    <main class="main-content">
        <div class="container">
            <div class="row">
                <!-- Left Column - Categories and Menu Items (8 columns) -->
                <div class="col-xl-8 col-lg-8 col-md-12 col-sm-12 col-12">
                    <div class="content-column left-column">
                        <h2 class="section-title">CATEGORIES</h2>

                        <!-- Category Tabs -->
                        <div class="categories-scroll-container">
                            <ul class="nav nav-pills sobha-pills" id="categoryTabs" role="tablist">
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link" id="all-tab" data-bs-toggle="tab" data-bs-target="#tab-all" type="button" role="tab" aria-controls="tab-all" aria-selected="false">
                                        <span class="category-text">All</span>
                                    </button>
                                </li>
                                <?php foreach ($categories as $index => $category): ?>
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link <?php echo $index === 0 ? 'active' : ''; ?>" id="<?php echo strtolower(str_replace(' ', '-', $category['name'])); ?>-tab" data-bs-toggle="tab" data-bs-target="#tab-<?php echo strtolower(str_replace(' ', '-', $category['name'])); ?>" type="button" role="tab" aria-controls="tab-<?php echo strtolower(str_replace(' ', '-', $category['name'])); ?>" aria-selected="<?php echo $index === 0 ? 'true' : 'false'; ?>">
                                            <?php if ($category['icon']): ?>
                                                <img src="image/<?php echo htmlspecialchars($category['icon']); ?>" alt="<?php echo htmlspecialchars($category['name']); ?>" class="category-icon">
                                            <?php endif; ?>
                                            <span class="category-text"><?php echo htmlspecialchars($category['name']); ?></span>
                                        </button>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        </div>

                        <!-- Tab Content -->
                        <div class="tab-content" id="categoryTabsContent">
                            <!-- All Items Pane -->
                            <div class="tab-pane fade" id="tab-all" role="tabpanel" aria-labelledby="all-tab">
                                <div class="menu-section">
                                    <h3 class="menu-section-title">ALL ITEMS</h3>
                                    <div class="menu-items-grid">
                                        <?php foreach ($menu_items as $item): ?>
                                            <div class="menu-item-card" data-item-id="<?php echo $item['id']; ?>" data-item-name="<?php echo htmlspecialchars($item['name']); ?>" data-item-price="<?php echo $item['price']; ?>">
                                                <div class="item-image">
                                                    <?php if ($item['image']): ?>
                                                        <img src="image/<?php echo htmlspecialchars($item['image']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>">
                                                    <?php else: ?>
                                                        <img src="image/Tea.svg" alt="<?php echo htmlspecialchars($item['name']); ?>">
                                                    <?php endif; ?>
                                                </div>
                                                <div class="item-info-row">
                                                    <div class="item-name-price">
                                                        <div class="item-name"><?php echo htmlspecialchars($item['name']); ?></div>
                                                        <div class="price-tile">₹<?php echo $item['price']; ?></div>
                                                    </div>
                                                    <div class="quantity-controls">
                                                        <button class="qty-btn minus"></button>
                                                        <span class="qty-display">0</span>
                                                        <button class="qty-btn plus"></button>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                        <!-- Add empty cards to fill the grid -->
                                        <?php for ($i = count($menu_items); $i < 12; $i++): ?>
                                            <div class="menu-item-card empty"></div>
                                        <?php endfor; ?>
                                    </div>
                                </div>
                            </div>
                            
                            <?php foreach ($categories as $index => $category): ?>
                                <!-- <?php echo htmlspecialchars($category['name']); ?> Pane -->
                                <div class="tab-pane fade <?php echo $index === 0 ? 'show active' : ''; ?>" id="tab-<?php echo strtolower(str_replace(' ', '-', $category['name'])); ?>" role="tabpanel" aria-labelledby="<?php echo strtolower(str_replace(' ', '-', $category['name'])); ?>-tab">
                                    <div class="menu-section">
                                        <h3 class="menu-section-title"><?php echo strtoupper(htmlspecialchars($category['name'])); ?></h3>
                                        <div class="menu-items-grid">
                                            <?php 
                                            $category_items = array_filter($menu_items, function($item) use ($category) {
                                                return $item['category_id'] == $category['id'];
                                            });
                                            ?>
                                            <?php foreach ($category_items as $item): ?>
                                                <div class="menu-item-card" data-item-id="<?php echo $item['id']; ?>" data-item-name="<?php echo htmlspecialchars($item['name']); ?>" data-item-price="<?php echo $item['price']; ?>">
                                                    <div class="item-image">
                                                        <?php if ($item['image']): ?>
                                                            <img src="image/<?php echo htmlspecialchars($item['image']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>">
                                                        <?php else: ?>
                                                            <img src="image/Tea.svg" alt="<?php echo htmlspecialchars($item['name']); ?>">
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="item-info-row">
                                                        <div class="item-name-price">
                                                            <div class="item-name"><?php echo htmlspecialchars($item['name']); ?></div>
                                                            <div class="price-tile">₹<?php echo $item['price']; ?></div>
                                                        </div>
                                                        <div class="quantity-controls">
                                                            <button class="qty-btn minus"></button>
                                                            <span class="qty-display">0</span>
                                                            <button class="qty-btn plus"></button>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                            <!-- Add empty cards to fill the grid -->
                                            <?php for ($i = count($category_items); $i < 12; $i++): ?>
                                                <div class="menu-item-card empty"></div>
                                            <?php endfor; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>

                <!-- Right Column - Shopping Cart (4 columns) -->
                <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12">
                    <div class="content-column right-column">
                        <!-- Cart Header -->
                        <div class="cart-header">
                            <div class="cart-icon">
                                <img src="image/Cart.svg" alt="Cart" width="24" height="24">
                                <span class="cart-title">Cart</span>
                            </div>
                            <div class="cart-totals">
                                <div class="cart-item-count">0 items</div>
                                <div class="cart-total-amount">₹0.00</div>
                            </div>
                        </div>

                        <!-- Cart Items -->
                        <div class="cart-items">
                            <!-- Empty cart message -->
                            <div class="empty-cart-message">
                                <p>Click on menu items to add them to cart</p>
                            </div>
                        </div>

                        <!-- Cart Footer -->
                        <div class="cart-footer">
                            <!-- Scroll Indicator -->
                            <div class="scroll-indicator">
                                <img src="image/Down Arrow.svg" alt="Scroll Down" width="20" height="20">
                            </div>
                            <button class="place-order-btn">Place Order</button>
                            <div class="total-items">Total 0 items</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Swiper JS -->
    <script src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script>
    
    <!-- Custom JS -->
    <script src="js/ordering-script.js"></script>
    
    <!-- Order Placement Script -->
    <script>
        // Override the place order functionality to use API
        document.addEventListener('DOMContentLoaded', function() {
            // Check if table number is locked from URL parameter
            const tableInput = document.getElementById('tableNumber');
            const urlParams = new URLSearchParams(window.location.search);
            const tableFromUrl = urlParams.get('table');
            
            if (tableFromUrl && tableInput.value === tableFromUrl) {
                tableInput.readOnly = true;
                
                // Add visual indicator that table is locked
                const tableGroup = tableInput.closest('.mb-3');
                let lockIndicator = tableGroup.querySelector('.table-lock-indicator');
                if (!lockIndicator) {
                    lockIndicator = document.createElement('small');
                    lockIndicator.className = 'text-muted table-lock-indicator';
                    lockIndicator.innerHTML = '<i class="fas fa-lock"></i> Table number is locked from URL parameter';
                    tableGroup.appendChild(lockIndicator);
                }
            }
            
            const placeOrderBtn = document.querySelector('.place-order-btn');
            
            if (placeOrderBtn) {
                // Remove existing event listener
                placeOrderBtn.replaceWith(placeOrderBtn.cloneNode(true));
                const newPlaceOrderBtn = document.querySelector('.place-order-btn');
                
                newPlaceOrderBtn.addEventListener('click', () => {
                    // Check if cart has items
                    const cartItems = document.querySelectorAll('.cart-item');
                    if (cartItems.length === 0) {
                        alert('Please add items to your cart before placing an order.');
                        return;
                    }
                    
                    // Get table number from URL parameter
                    const urlParams = new URLSearchParams(window.location.search);
                    const tableFromUrl = urlParams.get('table');
                    
                    // Populate modal with cart data
                    populateOrderModal(cartItems, tableFromUrl);
                    
                    // Show modal
                    const orderModal = new bootstrap.Modal(document.getElementById('orderModal'));
                    orderModal.show();
                });
                
                // Function to populate order modal
                function populateOrderModal(cartItems, tableFromUrl) {
                    // Set table number from URL if available
                    if (tableFromUrl) {
                        const tableInput = document.getElementById('tableNumber');
                        tableInput.value = tableFromUrl;
                        tableInput.readOnly = true;
                        
                        // Add visual indicator that table is locked
                        const tableGroup = tableInput.closest('.mb-3');
                        let lockIndicator = tableGroup.querySelector('.table-lock-indicator');
                        if (!lockIndicator) {
                            lockIndicator = document.createElement('small');
                            lockIndicator.className = 'text-muted table-lock-indicator';
                            lockIndicator.innerHTML = '<i class="fas fa-lock"></i> Table number is locked from URL parameter';
                            tableGroup.appendChild(lockIndicator);
                        }
                    }
                    
                    // Clear previous order items
                    const orderItemsList = document.getElementById('orderItemsList');
                    orderItemsList.innerHTML = '';
                    
                    let subtotal = 0;
                    
                    // Add cart items to modal
                    cartItems.forEach(item => {
                        const itemName = item.querySelector('.item-name').textContent;
                        const quantity = parseInt(item.querySelector('.qty-display').textContent);
                        
                        // Find the menu item data
                        const menuItem = document.querySelector(`[data-item-name="${itemName}"]`);
                        if (menuItem) {
                            const price = parseFloat(menuItem.getAttribute('data-item-price'));
                            const itemTotal = price * quantity;
                            subtotal += itemTotal;
                            
                            // Create order item row
                            const itemRow = document.createElement('div');
                            itemRow.className = 'order-item-row d-flex justify-content-between align-items-center mb-2 p-2 border-bottom';
                            itemRow.innerHTML = `
                                <div>
                                    <strong>${itemName}</strong>
                                </div>
                                <div class="text-end">
                                    <div>Qty: ${quantity}</div>
                                    <div class="fw-bold">₹${itemTotal.toFixed(2)}</div>
                                </div>
                            `;
                            orderItemsList.appendChild(itemRow);
                        }
                    });
                    
                    // Calculate totals
                    const gst_rate = 0.05; // 5% GST
                    const gst_amount = subtotal * gst_rate;
                    const total_amount = subtotal + gst_amount;
                    
                    // Update totals in modal
                    document.getElementById('orderSubtotal').textContent = `₹${subtotal.toFixed(2)}`;
                    document.getElementById('orderGst').textContent = `₹${gst_amount.toFixed(2)}`;
                    document.getElementById('orderTotal').textContent = `₹${total_amount.toFixed(2)}`;
                }
                
                // Handle modal order placement
                document.getElementById('placeOrderBtn').addEventListener('click', async () => {
                    const form = document.getElementById('orderForm');
                    const formData = new FormData(form);
                    
                    // Validate form
                    if (!form.checkValidity()) {
                        form.reportValidity();
                        return;
                    }
                    
                    // Collect cart data
                    const cartItems = document.querySelectorAll('.cart-item');
                    const orderData = {
                        customer_name: formData.get('customer_name'),
                        customer_mobile: formData.get('customer_mobile'),
                        table_number: formData.get('table_number'),
                        items: []
                    };
                    
                    cartItems.forEach(item => {
                        const itemName = item.querySelector('.item-name').textContent;
                        const quantity = parseInt(item.querySelector('.qty-display').textContent);
                        
                        // Find the menu item data
                        const menuItem = document.querySelector(`[data-item-name="${itemName}"]`);
                        if (menuItem) {
                            orderData.items.push({
                                menu_item_id: parseInt(menuItem.getAttribute('data-item-id')),
                                item_name: itemName,
                                quantity: quantity,
                                price: parseFloat(menuItem.getAttribute('data-item-price'))
                            });
                        }
                    });
                    
                    // Calculate totals
                    let subtotal = 0;
                    orderData.items.forEach(item => {
                        subtotal += item.price * item.quantity;
                    });
                    
                    const gst_rate = 0.05; // 5% GST
                    const gst_amount = subtotal * gst_rate;
                    const total_amount = subtotal + gst_amount;
                    
                    orderData.subtotal = subtotal;
                    orderData.gst_rate = gst_rate;
                    orderData.gst_amount = gst_amount;
                    orderData.total_amount = total_amount;
                    
                    // Disable button and show loading
                    const placeOrderBtn = document.getElementById('placeOrderBtn');
                    const originalText = placeOrderBtn.textContent;
                    placeOrderBtn.disabled = true;
                    placeOrderBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Placing Order...';
                    
                    try {
                        const response = await fetch('backend/api/orders.php', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                            },
                            body: JSON.stringify(orderData)
                        });
                        
                        const result = await response.json();
                        
                        if (result.success) {
                            // Close modal
                            const orderModal = bootstrap.Modal.getInstance(document.getElementById('orderModal'));
                            orderModal.hide();
                            
                            // Store order number for success page
                            localStorage.setItem('orderNumber', result.order_number);
                            localStorage.setItem('orderStatus', 'placed');
                            localStorage.setItem('orderData', JSON.stringify(orderData));
                            
                            // Redirect to success page
                            window.location.href = 'order-success.php';
                        } else {
                            alert('Failed to place order: ' + result.message);
                        }
                    } catch (error) {
                        console.error('Error placing order:', error);
                        alert('Error placing order. Please try again.');
                    } finally {
                        // Re-enable button
                        placeOrderBtn.disabled = false;
                        placeOrderBtn.textContent = originalText;
                    }
                });
            }
            
            // Search functionality
            const searchInput = document.getElementById('menuSearchInput');
            if (searchInput) {
                searchInput.addEventListener('input', function() {
                    const searchTerm = this.value.toLowerCase().trim();
                    filterMenuItems(searchTerm);
                });
            }
            
            // Function to filter menu items and categories
            function filterMenuItems(searchTerm) {
                const menuItemCards = document.querySelectorAll('.menu-item-card:not(.empty)');
                const categoryTabs = document.querySelectorAll('.nav-link');
                const categoryPanes = document.querySelectorAll('.tab-pane');
                
                if (searchTerm === '') {
                    // Show all items and categories
                    menuItemCards.forEach(card => {
                        card.style.display = 'flex';
                    });
                    categoryTabs.forEach(tab => {
                        tab.style.display = 'block';
                    });
                    categoryPanes.forEach(pane => {
                        pane.style.display = '';
                    });
                    return;
                }
                
                let hasVisibleItems = false;
                let visibleCategories = new Set();
                
                // Filter menu items
                menuItemCards.forEach(card => {
                    const itemName = card.querySelector('.item-name').textContent.toLowerCase();
                    const itemPrice = card.querySelector('.price-tile').textContent.toLowerCase();
                    
                    // Check if item matches search term
                    const matchesItem = itemName.includes(searchTerm) || itemPrice.includes(searchTerm);
                    
                    if (matchesItem) {
                        card.style.display = 'flex';
                        hasVisibleItems = true;
                        
                        // Find the category this item belongs to
                        const categoryPane = card.closest('.tab-pane');
                        if (categoryPane) {
                            const categoryId = categoryPane.id.replace('tab-', '');
                            visibleCategories.add(categoryId);
                        }
                    } else {
                        card.style.display = 'none';
                    }
                });
                
                // Filter categories based on visible items
                categoryTabs.forEach(tab => {
                    const tabId = tab.getAttribute('data-bs-target').replace('#tab-', '');
                    const tabText = tab.querySelector('.category-text').textContent.toLowerCase();
                    
                    // Show category if it has visible items or if category name matches search
                    const hasVisibleItemsInCategory = visibleCategories.has(tabId);
                    const categoryMatches = tabText.includes(searchTerm);
                    
                    if (hasVisibleItemsInCategory || categoryMatches) {
                        tab.style.display = 'block';
                    } else {
                        tab.style.display = 'none';
                    }
                });
                
                // Show/hide category panes
                categoryPanes.forEach(pane => {
                    const paneId = pane.id.replace('tab-', '');
                    const hasVisibleItemsInPane = visibleCategories.has(paneId);
                    
                    if (hasVisibleItemsInPane) {
                        pane.style.display = '';
                    } else {
                        pane.style.display = 'none';
                    }
                });
                
                // Show "All" tab if there are any visible items
                const allTab = document.getElementById('all-tab');
                const allPane = document.getElementById('tab-all');
                
                if (allTab && allPane) {
                    if (hasVisibleItems) {
                        allTab.style.display = 'block';
                        allPane.style.display = '';
                    } else {
                        allTab.style.display = 'none';
                        allPane.style.display = 'none';
                    }
                }
                
                // Update empty state message
                const emptyCartMessage = document.querySelector('.empty-cart-message');
                if (emptyCartMessage) {
                    if (!hasVisibleItems) {
                        // Show "No items found" message
                        const noResultsMessage = document.querySelector('.no-results-message');
                        if (!noResultsMessage) {
                            const message = document.createElement('div');
                            message.className = 'no-results-message';
                            message.innerHTML = `
                                <div class="text-center p-4">
                                    <i class="fas fa-search fa-2x text-muted mb-3"></i>
                                    <h5 class="text-muted">No items found</h5>
                                    <p class="text-muted">Try searching for a different term or browse categories</p>
                                </div>
                            `;
                            document.querySelector('.menu-items-grid').appendChild(message);
                        }
                    } else {
                        // Remove "No items found" message
                        const noResultsMessage = document.querySelector('.no-results-message');
                        if (noResultsMessage) {
                            noResultsMessage.remove();
                        }
                    }
                }
            }
        });
    </script>

    <!-- Order Modal -->
    <div class="modal fade" id="orderModal" tabindex="-1" aria-labelledby="orderModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="orderModalLabel">Place Your Order</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="orderForm">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="customerName" class="form-label">Customer Name *</label>
                                    <input type="text" class="form-control" id="customerName" name="customer_name" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="customerMobile" class="form-label">Mobile Number</label>
                                    <input type="tel" class="form-control" id="customerMobile" name="customer_mobile">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="tableNumber" class="form-label">Table Number *</label>
                                    <input type="text" class="form-control" id="tableNumber" name="table_number" 
                                           value="<?php echo htmlspecialchars($table_number); ?>" 
                                           <?php echo $is_table_locked ? 'readonly' : ''; ?> required>
                                    <?php if ($is_table_locked): ?>
                                        <small class="text-muted">
                                            <i class="fas fa-lock"></i> Table number is locked from Scanner
                                        </small>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Order Summary -->
                        <div class="order-summary">
                            <h6 class="mb-3">Order Summary</h6>
                            <div id="orderItemsList" class="mb-3"></div>
                            <div class="order-totals">
                                <div class="d-flex justify-content-between">
                                    <span>Subtotal:</span>
                                    <span id="orderSubtotal">₹0.00</span>
                                </div>
                                <div class="d-flex justify-content-between">
                                    <span>GST (5%):</span>
                                    <span id="orderGst">₹0.00</span>
                                </div>
                                <hr>
                                <div class="d-flex justify-content-between fw-bold">
                                    <span>Total:</span>
                                    <span id="orderTotal">₹0.00</span>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="placeOrderBtn">Place Order</button>
                </div>
            </div>
        </div>
    </div>
</body>
</html>