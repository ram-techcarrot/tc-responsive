<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sobha - Order Online</title>
    
    <!-- Bootstrap 5 CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Swiper CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css" />
    
    <!-- Font Awesome for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Custom CSS -->
    <link href="../css/ordering-styles.css" rel="stylesheet">
    
    <style>
        /* Fix for SVG icons in category tabs */
        .category-icon {
            width: 24px;
            height: 24px;
            margin-right: 8px;
            filter: brightness(0) invert(1); /* Make SVG icons white */
        }
        
        /* Ensure proper spacing for category text */
        .nav-link .category-text {
            margin-left: 4px;
        }
        
        /* Cart price styling */
        .item-price-info {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin: 5px 0;
            font-size: 0.9rem;
        }
        
        .unit-price {
            color: #666;
            font-size: 0.8rem;
        }
        
        .item-total {
            font-weight: bold;
            color: #28a745;
        }
        
        .grand-total {
            font-weight: bold;
            font-size: 1.1rem;
            color: #007bff;
            margin-top: 5px;
        }
        
        .total-items {
            text-align: center;
            padding: 10px;
        }
    </style>
</head>
<body>
    <!-- Header Section -->
    <header class="ordering-header">
        <div class="container">
            <div class="row align-items-center">
                <!-- Logo Section -->
                <div class="col-auto">
                    <div class="logo-section ">
                        <a href="../index.html" class="logo-link">
                            <img src="../image/sobha-logo.svg" alt="SOBHA Realty" class="sobha-logo">
                        </a>
                    </div>
                </div>
                
                <!-- Search Section -->
                <div class="col">
                    <div class="search-section">
                        <div class="search-container">
                            <input type="text" class="search-input" placeholder="Search" id="searchInput">
                            <i class="fas fa-search search-icon"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- Main Content Area -->
    <main class="main-content">
        <div class="container">
            <div class="row">
                <!-- Left Column - Categories and Menu Items (8 columns) -->
                <div class="col-xl-8 col-lg-8 col-md-12 col-sm-12 col-12">
                    <div class="content-column left-column">
                        <h2 class="section-title">CATEGORIES</h2>

                        <!-- Category Tabs -->
                        <div class="categories-scroll-container">
                            <ul class="nav nav-pills sobha-pills" id="categoryTabs" role="tablist">
                                <!-- Categories will be loaded dynamically -->
                            </ul>
                        </div>

                        <div class="tab-content sobha-tab-content" id="categoryTabsContent">
                            <!-- Menu content will be loaded dynamically -->
                        </div>
                    </div>
                </div>

                <!-- Right Column - Shopping Cart (4 columns) -->
                <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12">
                    <div class="content-column right-column">
                        <!-- Cart Header -->
                        <div class="cart-header">
                            <div class="cart-icon">
                                <img src="../image/Cart.svg" alt="Cart" width="24" height="24">
                                <span class="cart-title">Cart</span>
                            </div>
                        </div>

                        <!-- Cart Items -->
                        <div class="cart-items">
                            <!-- Empty cart message -->
                            <div class="empty-cart-message">
                                <p>Click on menu items to add them to cart</p>
                            </div>
                        </div>

                        <!-- Cart Footer -->
                        <div class="cart-footer">
                            <!-- Scroll Indicator -->
                            <div class="scroll-indicator">
                                <img src="../image/Down Arrow.svg" alt="Scroll Down" width="20" height="20">
                            </div>
                            <button class="place-order-btn" id="placeOrderBtn">Place Order</button>
                            <div class="total-items">Total 0 items</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- Customer Information Modal -->
    <div class="modal fade" id="customerModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-user"></i> Customer Information
                    </h5>
                </div>
                <form id="customerForm">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="customerName" class="form-label">Name *</label>
                            <input type="text" class="form-control" id="customerName" required>
                        </div>
                        <div class="mb-3">
                            <label for="customerMobile" class="form-label">Mobile Number *</label>
                            <input type="tel" class="form-control" id="customerMobile" required>
                        </div>
                        <div class="mb-3">
                            <label for="tableSelect" class="form-label">Table Number</label>
                            <select class="form-select" id="tableSelect">
                                <option value="">Select Table (Optional)</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="orderNotes" class="form-label">Order Notes</label>
                            <textarea class="form-control" id="orderNotes" rows="3" placeholder="Any special instructions..."></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-check"></i> Place Order
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Swiper JS -->
    <script src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script>
    
    <!-- Custom JS -->
    <script src="../js/ordering-script.js"></script>
    <script>
        // Global variables
        let menuData = [];
        let cart = [];
        let currentTable = '';

        // Get table from URL parameter
        const urlParams = new URLSearchParams(window.location.search);
        currentTable = urlParams.get('table') || '';

        // Load menu data
        async function loadMenuData() {
            try {
                const response = await fetch('../../backend/api/menu.php');
                const result = await response.json();
                
                console.log('API Response:', result); // Debug log
                
                if (result.success) {
                    // Group menu items by category
                    const categories = result.categories;
                    const menuItems = result.menu_items;
                    
                    console.log('Categories:', categories); // Debug log
                    console.log('Menu Items:', menuItems); // Debug log
                    
                    menuData = categories.map(category => ({
                        id: category.id,
                        name: category.name,
                        icon: category.icon,
                        items: menuItems.filter(item => item.category_id == category.id)
                    }));
                    
                    console.log('Menu Data:', menuData); // Debug log
                    renderMenu();
                } else {
                    console.error('Failed to load menu:', result.message);
                }
            } catch (error) {
                console.error('Error loading menu:', error);
            }
        }

        // Load tables
        async function loadTables() {
            try {
                const response = await fetch('../../backend/api/tables.php');
                const result = await response.json();
                
                if (result.success) {
                    const tableSelect = document.getElementById('tableSelect');
                    result.data.forEach(table => {
                        const option = document.createElement('option');
                        option.value = table.id;
                        option.textContent = `Table ${table.table_number}`;
                        if (currentTable === table.table_number) {
                            option.selected = true;
                        }
                        tableSelect.appendChild(option);
                    });
                }
            } catch (error) {
                console.error('Error loading tables:', error);
            }
        }

        // Render menu
        function renderMenu() {
            console.log('renderMenu called with menuData:', menuData); // Debug log
            
            const categoryTabs = document.getElementById('categoryTabs');
            const categoryContent = document.getElementById('categoryTabsContent');
            
            // Clear existing content
            categoryTabs.innerHTML = '';
            categoryContent.innerHTML = '';
            
            // Add "All" tab
            const allTab = document.createElement('li');
            allTab.className = 'nav-item';
            allTab.innerHTML = `
                <button class="nav-link active" id="all-tab" data-bs-toggle="tab" data-bs-target="#tab-all" type="button" role="tab" aria-selected="true">
                    <span class="category-text">All</span>
                </button>
            `;
            categoryTabs.appendChild(allTab);
            
            // Add category tabs
            menuData.forEach((category, index) => {
                const tab = document.createElement('li');
                tab.className = 'nav-item';
                
                // Handle icon - use SVG images from image folder
                let iconHtml = '';
                if (category.icon) {
                    // Always treat as SVG image file
                    iconHtml = `<img src="../image/${category.icon}" alt="${category.name}" class="category-icon">`;
                }
                
                tab.innerHTML = `
                    <button class="nav-link" id="${category.name.toLowerCase().replace(/\s+/g, '-')}-tab" 
                            data-bs-toggle="tab" data-bs-target="#tab-${category.name.toLowerCase().replace(/\s+/g, '-')}" type="button" role="tab" aria-selected="false">
                        ${iconHtml}
                        <span class="category-text">${category.name}</span>
                    </button>
                `;
                categoryTabs.appendChild(tab);
                
                // Add category content
                const content = document.createElement('div');
                content.className = 'tab-pane fade';
                content.id = `tab-${category.name.toLowerCase().replace(/\s+/g, '-')}`;
                content.innerHTML = `
                    <div class="menu-section">
                        <h3 class="menu-section-title">${category.name.toUpperCase()}</h3>
                        <div class="menu-items-grid">
                            ${category.items.map(item => {
                                console.log('Rendering item:', item); // Debug log
                                return `
                                <div class="menu-item-card" data-item-id="${item.id}" data-item-name="${item.name}" data-item-price="${item.price}">
                                    <div class="item-image">
                                        <img src="../image/${item.image || 'Tea.svg'}" alt="${item.name}">
                                    </div>
                                    <div class="item-info-row">
                                        <div class="item-name-price">
                                            <div class="item-name">${item.name}</div>
                                            <div class="price-tile">₹${item.price}</div>
                                        </div>
                                        <div class="quantity-controls">
                                            <button class="qty-btn minus"></button>
                                            <span class="qty-display">0</span>
                                            <button class="qty-btn plus"></button>
                                        </div>
                                    </div>
                                </div>
                                `;
                            }).join('')}
                        </div>
                    </div>
                `;
                categoryContent.appendChild(content);
            });
            
            // Add "All" content
            const allContent = document.createElement('div');
            allContent.className = 'tab-pane fade show active';
            allContent.id = 'tab-all';
            allContent.innerHTML = menuData.map(category => `
                <div class="menu-section">
                    <h3 class="menu-section-title">${category.name.toUpperCase()}</h3>
                    <div class="menu-items-grid">
                        ${category.items.map(item => {
                            console.log('Rendering All item:', item); // Debug log
                            return `
                            <div class="menu-item-card" data-item-id="${item.id}" data-item-name="${item.name}" data-item-price="${item.price}">
                                <div class="item-image">
                                    <img src="../image/${item.image || 'Tea.svg'}" alt="${item.name}">
                                </div>
                                <div class="item-info-row">
                                    <div class="item-name-price">
                                        <div class="item-name">${item.name}</div>
                                        <div class="price-tile">₹${item.price}</div>
                                    </div>
                                    <div class="quantity-controls">
                                        <button class="qty-btn minus"></button>
                                        <span class="qty-display">0</span>
                                        <button class="qty-btn plus"></button>
                                    </div>
                                </div>
                            </div>
                            `;
                        }).join('')}
                    </div>
                </div>
            `).join('');
            categoryContent.appendChild(allContent);
        }

        // Get cart data from DOM
        function getCartData() {
            const cartItems = document.querySelectorAll('.cart-item');
            const cartData = [];
            
            cartItems.forEach(item => {
                const itemName = item.querySelector('.item-name').textContent.trim();
                const quantity = parseInt(item.querySelector('.qty-display').textContent);
                const notes = item.querySelector('.notes-input').value || '';
                
                // Find the menu item data by searching through all menu items
                let menuItemData = null;
                const allMenuItems = document.querySelectorAll('.menu-item-card[data-item-id]');
                
                for (let menuItem of allMenuItems) {
                    const menuItemName = menuItem.querySelector('.item-name').textContent.trim();
                    if (menuItemName === itemName) {
                        menuItemData = menuItem;
                        break;
                    }
                }
                
                if (menuItemData) {
                    cartData.push({
                        menu_item_id: parseInt(menuItemData.getAttribute('data-item-id')),
                        item_name: itemName,
                        price: parseFloat(menuItemData.getAttribute('data-item-price')),
                        quantity: quantity,
                        notes: notes
                    });
                } else {
                    console.warn('Could not find menu item data for:', itemName);
                }
            });
            
            return cartData;
        }

        // Place order
        async function placeOrder() {
            const cartData = getCartData();
            
            console.log('Cart data:', cartData);
            console.log('Cart items count:', document.querySelectorAll('.cart-item').length);
            
            if (cartData.length === 0) {
                alert('Please add items to your cart before placing an order.');
                return;
            }
            
            const modal = new bootstrap.Modal(document.getElementById('customerModal'));
            modal.show();
        }

        // Handle customer form submission
        document.getElementById('customerForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const customerName = document.getElementById('customerName').value;
            const customerMobile = document.getElementById('customerMobile').value;
            const tableId = document.getElementById('tableSelect').value;
            const orderNotes = document.getElementById('orderNotes').value;
            
            // Get cart data
            const cartData = getCartData();
            
            console.log('Form submission - Cart data:', cartData);
            
            if (cartData.length === 0) {
                alert('No items in cart. Please add items before placing order.');
                return;
            }
            
            // Calculate totals
            let subtotal = 0;
            cartData.forEach(item => {
                subtotal += item.price * item.quantity;
            });
            
            const gst_rate = 0.05; // 5% GST
            const gst_amount = subtotal * gst_rate;
            const total_amount = subtotal + gst_amount;
            
            const orderData = {
                customer_name: customerName,
                customer_mobile: customerMobile,
                table_number: tableId ? document.getElementById('tableSelect').selectedOptions[0].text.replace('Table ', '') : 'T01',
                subtotal: subtotal,
                gst_rate: gst_rate,
                gst_amount: gst_amount,
                total_amount: total_amount,
                notes: orderNotes,
                items: cartData.map(item => ({
                    menu_item_id: item.id,
                    item_name: item.name,
                    quantity: item.quantity,
                    price: item.price,
                    notes: item.notes || ''
                }))
            };
            
            try {
                const response = await fetch('../../backend/api/orders.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(orderData)
                });
                
                const result = await response.json();
                
                if (result.success) {
                    // Store order number for success page
                    sessionStorage.setItem('orderNumber', result.order_number);
                    sessionStorage.setItem('orderId', result.order_id);
                    
                    // Redirect to success page
                    window.location.href = '../order-success.html';
                } else {
                    alert('Failed to place order: ' + result.message);
                }
            } catch (error) {
                console.error('Error placing order:', error);
                alert('An error occurred while placing the order.');
            }
        });

        // Initialize when page loads
        document.addEventListener('DOMContentLoaded', function() {
            loadMenuData();
            loadTables();
            
            // Override the original place order button
            document.getElementById('placeOrderBtn').addEventListener('click', placeOrder);
        });
    </script>
</body>
</html>
