<?php
echo "<!DOCTYPE html>";
echo "<html><head><title>Database Connection Test</title>";
echo "<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css' rel='stylesheet'>";
echo "</head><body class='bg-light'>";

echo "<div class='container mt-5'>";
echo "<div class='row justify-content-center'>";
echo "<div class='col-md-8'>";
echo "<div class='card'>";
echo "<div class='card-header'>";
echo "<h3><i class='fas fa-database'></i> Database Connection Test</h3>";
echo "</div>";
echo "<div class='card-body'>";

try {
    require_once 'backend/config/database.php';
    echo "<div class='alert alert-info'>Database class loaded successfully.</div>";
    
    $database = new Database();
    echo "<div class='alert alert-info'>Database object created successfully.</div>";
    
    $db = $database->getConnection();
    echo "<div class='alert alert-success'>Database connection established successfully!</div>";
    
    // Test a simple query
    $query = "SELECT COUNT(*) as count FROM users";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $result = $stmt->fetch();
    
    echo "<div class='alert alert-success'>";
    echo "<i class='fas fa-check-circle'></i> Query executed successfully!";
    echo "<br>Users count: " . $result['count'];
    echo "</div>";
    
    // Test categories table
    $query = "SELECT COUNT(*) as count FROM categories";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $result = $stmt->fetch();
    
    echo "<div class='alert alert-success'>";
    echo "<i class='fas fa-check-circle'></i> Categories table accessible!";
    echo "<br>Categories count: " . $result['count'];
    echo "</div>";
    
    // Test orders table
    $query = "SELECT COUNT(*) as count FROM orders";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $result = $stmt->fetch();
    
    echo "<div class='alert alert-success'>";
    echo "<i class='fas fa-check-circle'></i> Orders table accessible!";
    echo "<br>Orders count: " . $result['count'];
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div class='alert alert-danger'>";
    echo "<h5><i class='fas fa-exclamation-triangle'></i> Error</h5>";
    echo "<p><strong>Message:</strong> " . htmlspecialchars($e->getMessage()) . "</p>";
    echo "<p><strong>File:</strong> " . htmlspecialchars($e->getFile()) . "</p>";
    echo "<p><strong>Line:</strong> " . $e->getLine() . "</p>";
    echo "</div>";
}

echo "<div class='text-center mt-4'>";
echo "<a href='test_admin_pages.php' class='btn btn-primary'>";
echo "<i class='fas fa-arrow-left'></i> Back to Admin Pages Test";
echo "</a>";
echo "</div>";

echo "</div></div></div></div></div>";
echo "</body></html>";
?>
