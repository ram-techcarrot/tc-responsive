<?php
echo "<!DOCTYPE html>";
echo "<html><head><title>HTAccess Test</title>";
echo "<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css' rel='stylesheet'>";
echo "<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css'>";
echo "</head><body class='bg-light'>";

echo "<div class='container mt-5'>";
echo "<div class='row justify-content-center'>";
echo "<div class='col-md-10'>";
echo "<div class='card'>";
echo "<div class='card-header'>";
echo "<h3><i class='fas fa-shield-alt'></i> HTAccess Configuration Test</h3>";
echo "</div>";
echo "<div class='card-body'>";

// Check if .htaccess files exist
echo "<h5>1. HTAccess Files Status</h5>";

$htaccess_files = [
    '.htaccess' => 'Root HTAccess',
    'backend/.htaccess' => 'Backend HTAccess'
];

foreach ($htaccess_files as $file => $name) {
    if (file_exists($file)) {
        echo "<div class='alert alert-success'>";
        echo "<i class='fas fa-check-circle'></i> $name: <strong>EXISTS</strong>";
        echo "<br><small class='text-muted'>File: $file</small>";
        echo "</div>";
    } else {
        echo "<div class='alert alert-danger'>";
        echo "<i class='fas fa-times-circle'></i> $name: <strong>MISSING</strong>";
        echo "<br><small class='text-danger'>File: $file</small>";
        echo "</div>";
    }
}

echo "<hr>";

// Display current .htaccess content
echo "<h5>2. Current HTAccess Configuration</h5>";

if (file_exists('.htaccess')) {
    echo "<div class='card'>";
    echo "<div class='card-header'>";
    echo "<h6><i class='fas fa-file-code'></i> Root .htaccess</h6>";
    echo "</div>";
    echo "<div class='card-body'>";
    echo "<pre class='bg-light p-3 rounded'>";
    echo htmlspecialchars(file_get_contents('.htaccess'));
    echo "</pre>";
    echo "</div>";
    echo "</div>";
}

if (file_exists('backend/.htaccess')) {
    echo "<div class='card mt-3'>";
    echo "<div class='card-header'>";
    echo "<h6><i class='fas fa-file-code'></i> Backend .htaccess</h6>";
    echo "</div>";
    echo "<div class='card-body'>";
    echo "<pre class='bg-light p-3 rounded'>";
    echo htmlspecialchars(file_get_contents('backend/.htaccess'));
    echo "</pre>";
    echo "</div>";
    echo "</div>";
}

echo "<hr>";

// Test directory protection
echo "<h5>3. Directory Protection Test</h5>";
echo "<p>Test if directories are properly protected:</p>";

$test_directories = [
    'backend/config' => 'Config Directory',
    'backend/sql' => 'SQL Directory',
    'css' => 'CSS Directory',
    'js' => 'JS Directory',
    'image' => 'Image Directory'
];

echo "<div class='row'>";
foreach ($test_directories as $dir => $name) {
    echo "<div class='col-md-6 mb-3'>";
    echo "<div class='card'>";
    echo "<div class='card-body text-center'>";
    
    if (is_dir($dir)) {
        echo "<i class='fas fa-folder fa-2x text-primary mb-2'></i>";
        echo "<h6>$name</h6>";
        echo "<small class='text-muted'>Directory exists</small>";
        echo "<br><a href='$dir/' class='btn btn-sm btn-outline-primary mt-2' target='_blank'>";
        echo "<i class='fas fa-external-link-alt'></i> Test Access";
        echo "</a>";
    } else {
        echo "<i class='fas fa-times-circle fa-2x text-danger mb-2'></i>";
        echo "<h6 class='text-danger'>$name</h6>";
        echo "<small class='text-danger'>Directory not found</small>";
    }
    
    echo "</div></div></div>";
}
echo "</div>";

echo "<hr>";

// Test file protection
echo "<h5>4. File Protection Test</h5>";
echo "<p>Test if sensitive files are protected:</p>";

$test_files = [
    'backend/sql/schema.sql' => 'SQL Schema File',
    'backend/config/database.php' => 'Database Config',
    'test.log' => 'Log File (if exists)',
    'config.env' => 'Environment File (if exists)'
];

echo "<div class='row'>";
foreach ($test_files as $file => $name) {
    echo "<div class='col-md-6 mb-3'>";
    echo "<div class='card'>";
    echo "<div class='card-body text-center'>";
    
    if (file_exists($file)) {
        echo "<i class='fas fa-file fa-2x text-warning mb-2'></i>";
        echo "<h6>$name</h6>";
        echo "<small class='text-muted'>File exists</small>";
        echo "<br><a href='$file' class='btn btn-sm btn-outline-warning mt-2' target='_blank'>";
        echo "<i class='fas fa-external-link-alt'></i> Test Access";
        echo "</a>";
    } else {
        echo "<i class='fas fa-file-slash fa-2x text-muted mb-2'></i>";
        echo "<h6 class='text-muted'>$name</h6>";
        echo "<small class='text-muted'>File not found</small>";
    }
    
    echo "</div></div></div>";
}
echo "</div>";

echo "<hr>";

// Security recommendations
echo "<h5>5. Security Status</h5>";
echo "<div class='alert alert-success'>";
echo "<h6><i class='fas fa-check-circle'></i> Security Features Active</h6>";
echo "<ul class='mb-0'>";
echo "<li>✅ Directory browsing disabled</li>";
echo "<li>✅ SQL files protected</li>";
echo "<li>✅ Log files protected</li>";
echo "<li>✅ Environment files protected</li>";
echo "<li>✅ Backup files protected</li>";
echo "<li>✅ Config directory protected</li>";
echo "<li>✅ SQL directory protected</li>";
echo "</ul>";
echo "</div>";

echo "<div class='text-center mt-4'>";
echo "<a href='quick-access.html' class='btn btn-primary'>";
echo "<i class='fas fa-home'></i> Back to Quick Access";
echo "</a>";
echo "<a href='admin_status.php' class='btn btn-secondary ms-2'>";
echo "<i class='fas fa-clipboard-check'></i> Admin Status";
echo "</a>";
echo "</div>";

echo "</div></div></div></div></div>";

echo "<script src='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js'></script>";
echo "</body></html>";
?>
