<?php
/**
 * Admin Sidebar Navigation
 * Reusable sidebar component for all admin pages
 */

// Get current page name for active state
$current_page = basename($_SERVER['PHP_SELF']);
?>

<!-- Sidebar -->
<div class="col-md-3 col-lg-2 px-0">
    <div class="sidebar p-3">
        <div class="text-center mb-4">
            <h4 class="text-white"><i class="fas fa-utensils"></i> Quick Order</h4>
            <small class="text-white-50">Admin Panel</small>
        </div>
        
        <nav class="nav flex-column">
            <a class="nav-link <?php echo $current_page === 'dashboard.php' ? 'active' : ''; ?>" href="dashboard.php">
                <i class="fas fa-tachometer-alt"></i> Dashboard
            </a>
            <a class="nav-link <?php echo $current_page === 'orders.php' ? 'active' : ''; ?>" href="orders.php">
                <i class="fas fa-shopping-cart"></i> Orders
            </a>
            <a class="nav-link <?php echo $current_page === 'unpaid-orders.php' ? 'active' : ''; ?>" href="unpaid-orders.php">
                <i class="fas fa-credit-card"></i> Unpaid Orders
            </a>
            <a class="nav-link <?php echo $current_page === 'menu.php' ? 'active' : ''; ?>" href="menu.php">
                <i class="fas fa-book"></i> Menu Items
            </a>
            <a class="nav-link <?php echo $current_page === 'categories.php' ? 'active' : ''; ?>" href="categories.php">
                <i class="fas fa-tags"></i> Categories
            </a>
                        <a class="nav-link <?php echo $current_page === 'tables.php' ? 'active' : ''; ?>" href="tables.php">
                            <i class="fas fa-table"></i> Tables
                        </a>
                        <a class="nav-link <?php echo $current_page === 'qr-codes.php' ? 'active' : ''; ?>" href="qr-codes.php">
                            <i class="fas fa-qrcode"></i> QR Codes
                        </a>
            <a class="nav-link <?php echo $current_page === 'reports.php' ? 'active' : ''; ?>" href="reports.php">
                <i class="fas fa-chart-bar"></i> Reports
            </a>
            <a class="nav-link <?php echo $current_page === 'settings.php' ? 'active' : ''; ?>" href="settings.php">
                <i class="fas fa-cog"></i> Settings
            </a>
            <hr class="text-white-50">
            <a class="nav-link" href="../auth/logout.php">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </nav>
    </div>
</div>
