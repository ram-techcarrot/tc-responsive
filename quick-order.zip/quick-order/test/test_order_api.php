<?php
require_once 'backend/config/database.php';

$database = new Database();
$db = $database->getConnection();

echo "<!DOCTYPE html><html><head><title>Test Order API</title>";
echo "<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css' rel='stylesheet'>";
echo "</head><body><div class='container mt-5'>";
echo "<h1>Test Order API</h1>";

try {
    // Check if order_items table has the required columns
    $query = "DESCRIBE order_items";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<h3>Order Items Table Structure:</h3>";
    echo "<table class='table table-striped'>";
    echo "<thead><tr><th>Column</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th></tr></thead><tbody>";
    foreach ($columns as $column) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($column['Field']) . "</td>";
        echo "<td>" . htmlspecialchars($column['Type']) . "</td>";
        echo "<td>" . htmlspecialchars($column['Null']) . "</td>";
        echo "<td>" . htmlspecialchars($column['Key']) . "</td>";
        echo "<td>" . htmlspecialchars($column['Default'] ?? 'NULL') . "</td>";
        echo "</tr>";
    }
    echo "</tbody></table>";
    
    // Test API with sample data
    echo "<h3>Testing Order API:</h3>";
    
    $testOrder = [
        'customer_name' => 'Test Customer',
        'customer_mobile' => '0501234567',
        'table_number' => 'T01',
        'subtotal' => 50.00,
        'gst_rate' => 0.05,
        'gst_amount' => 2.50,
        'total_amount' => 52.50,
        'items' => [
            [
                'menu_item_id' => 1,
                'item_name' => 'Test Item',
                'quantity' => 2,
                'price' => 25.00,
                'notes' => 'Test notes'
            ]
        ]
    ];
    
    $jsonData = json_encode($testOrder);
    
    echo "<div class='alert alert-info'>";
    echo "<strong>Test Order Data:</strong><br>";
    echo "<pre>" . htmlspecialchars($jsonData) . "</pre>";
    echo "</div>";
    
    // Test the API endpoint
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'http://localhost/quick-order/backend/api/orders.php');
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    echo "<div class='alert alert-" . ($httpCode == 200 ? 'success' : 'danger') . "'>";
    echo "<strong>API Response (HTTP $httpCode):</strong><br>";
    echo "<pre>" . htmlspecialchars($response) . "</pre>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div class='alert alert-danger'>Error: " . htmlspecialchars($e->getMessage()) . "</div>";
}

echo "<div class='mt-4'>";
echo "<a href='ordering.php' class='btn btn-primary'>Test Ordering Page</a> ";
echo "<a href='fix_order_items_table.php' class='btn btn-secondary'>Fix Database</a>";
echo "</div>";
echo "</div></body></html>";
?>
