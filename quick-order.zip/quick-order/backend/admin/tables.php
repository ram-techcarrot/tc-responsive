<?php
require_once '../auth/check_auth.php';
require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'add_table') {
        $table_number = trim($_POST['table_number']);
        $is_active = isset($_POST['is_active']) ? 1 : 0;
        
        // Generate QR code data
        $qr_data = json_encode([
            'table_number' => $table_number,
            'url' => 'http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF'], 2) . '/frontend/ordering.php?table=' . urlencode($table_number)
        ]);
        
        $query = "INSERT INTO tables (table_number, qr_code, is_active) VALUES (:table_number, :qr_code, :is_active)";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':table_number', $table_number);
        $stmt->bindParam(':qr_code', $qr_data);
        $stmt->bindParam(':is_active', $is_active);
        
        if ($stmt->execute()) {
            $success = 'Table added successfully!';
        } else {
            $error = 'Failed to add table.';
        }
    } elseif ($action === 'edit_table') {
        $id = $_POST['id'];
        $table_number = trim($_POST['table_number']);
        $is_active = isset($_POST['is_active']) ? 1 : 0;
        
        // Update QR code data
        $qr_data = json_encode([
            'table_number' => $table_number,
            'url' => 'http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF'], 2) . '/frontend/ordering.php?table=' . urlencode($table_number)
        ]);
        
        $query = "UPDATE tables SET table_number = :table_number, qr_code = :qr_code, is_active = :is_active WHERE id = :id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->bindParam(':table_number', $table_number);
        $stmt->bindParam(':qr_code', $qr_data);
        $stmt->bindParam(':is_active', $is_active);
        
        if ($stmt->execute()) {
            $success = 'Table updated successfully!';
        } else {
            $error = 'Failed to update table.';
        }
    } elseif ($action === 'delete_table') {
        $id = $_POST['id'];
        
        $query = "DELETE FROM tables WHERE id = :id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':id', $id);
        
        if ($stmt->execute()) {
            $success = 'Table deleted successfully!';
        } else {
            $error = 'Failed to delete table.';
        }
    }
}

// Get all tables
$query = "SELECT t.*, COUNT(o.id) as order_count FROM tables t 
          LEFT JOIN orders o ON t.id = o.table_id AND o.status IN ('placed', 'pending', 'cooking')
          GROUP BY t.id 
          ORDER BY t.table_number";
$stmt = $db->prepare($query);
$stmt->execute();
$tables = $stmt->fetchAll();

// Get table for editing
$edit_table = null;
if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $query = "SELECT * FROM tables WHERE id = :id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    $edit_table = $stmt->fetch();
}
?>

<?php include 'includes/header.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/qrcode@1.5.3/build/qrcode.min.js"></script>
    <style>
        .table-card {
            background: white;
            border-radius: 10px;
            padding: 1.5rem;
            margin-bottom: 1rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            border-left: 4px solid #007bff;
        }
        .table-card.inactive {
            border-left-color: #dc3545;
            opacity: 0.7;
        }
        .table-card.has-orders {
            border-left-color: #ffc107;
        }
        .qr-code {
            width: 120px;
            height: 120px;
            border: 2px solid #e9ecef;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: white;
        }
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.3);
        }
        .status-badge {
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
            text-transform: uppercase;
        }
        .status-active { background: #d4edda; color: #155724; }
        .status-inactive { background: #f8d7da; color: #721c24; }
        .status-occupied { background: #fff3cd; color: #856404; }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <?php include 'includes/sidebar.php'; ?>
            
            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2><i class="fas fa-table"></i> Table Management</h2>
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addTableModal">
                        <i class="fas fa-plus"></i> Add Table
                    </button>
                </div>
                
                <?php if (isset($success)): ?>
                    <div class="alert alert-success alert-dismissible fade show">
                        <i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <?php if (isset($error)): ?>
                    <div class="alert alert-danger alert-dismissible fade show">
                        <i class="fas fa-exclamation-triangle"></i> <?php echo htmlspecialchars($error); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <!-- Tables Grid -->
                <div class="row">
                    <?php foreach ($tables as $table): ?>
                        <div class="col-md-6 col-lg-4 mb-3">
                            <div class="table-card <?php echo !$table['is_active'] ? 'inactive' : ($table['order_count'] > 0 ? 'has-orders' : ''); ?>">
                                <div class="row align-items-center">
                                    <div class="col-4">
                                        <div class="qr-code" id="qr-<?php echo $table['id']; ?>">
                                            <i class="fas fa-qrcode fa-2x text-muted"></i>
                                        </div>
                                    </div>
                                    <div class="col-8">
                                        <h5 class="mb-1">Table <?php echo htmlspecialchars($table['table_number']); ?></h5>
                                        <div class="mb-2">
                                            <?php if (!$table['is_active']): ?>
                                                <span class="status-badge status-inactive">Inactive</span>
                                            <?php elseif ($table['order_count'] > 0): ?>
                                                <span class="status-badge status-occupied">Occupied</span>
                                            <?php else: ?>
                                                <span class="status-badge status-active">Available</span>
                                            <?php endif; ?>
                                        </div>
                                        <p class="mb-1 text-muted">
                                            <i class="fas fa-shopping-cart"></i> 
                                            <?php echo $table['order_count']; ?> active orders
                                        </p>
                                        <div class="btn-group btn-group-sm">
                                            <button class="btn btn-outline-primary" 
                                                    onclick="editTable(<?php echo htmlspecialchars(json_encode($table)); ?>)">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <button class="btn btn-outline-info" 
                                                    onclick="showQRCode(<?php echo $table['id']; ?>, '<?php echo htmlspecialchars($table['table_number']); ?>')">
                                                <i class="fas fa-qrcode"></i>
                                            </button>
                                            <button class="btn btn-outline-danger" 
                                                    onclick="deleteTable(<?php echo $table['id']; ?>, '<?php echo htmlspecialchars($table['table_number']); ?>')">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                
                <?php if (empty($tables)): ?>
                    <div class="text-center py-5">
                        <i class="fas fa-table fa-3x text-muted mb-3"></i>
                        <h5 class="text-muted">No tables found</h5>
                        <p class="text-muted">Add your first table to get started.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Add/Edit Table Modal -->
    <div class="modal fade" id="addTableModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-plus"></i> Add Table
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" id="tableForm">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="add_table" id="formAction">
                        <input type="hidden" name="id" id="tableId">
                        
                        <div class="mb-3">
                            <label for="table_number" class="form-label">Table Number</label>
                            <input type="text" class="form-control" name="table_number" id="table_number" 
                                   placeholder="e.g., T001" required>
                        </div>
                        
                        <div class="mb-3">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="is_active" 
                                       id="is_active" checked>
                                <label class="form-check-label" for="is_active">
                                    Active (available for orders)
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Save Table
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- QR Code Modal -->
    <div class="modal fade" id="qrModal" tabindex="-1">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-qrcode"></i> QR Code
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body text-center">
                    <div id="qrCodeDisplay" class="mb-3"></div>
                    <h6 id="qrTableNumber"></h6>
                    <p class="text-muted">Scan this QR code to place orders for this table</p>
                    <button class="btn btn-outline-primary btn-sm" onclick="downloadQRCode()">
                        <i class="fas fa-download"></i> Download
                    </button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Delete Confirmation Modal -->
    <div class="modal fade" id="deleteModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-exclamation-triangle text-warning"></i> Confirm Delete
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to delete this table?</p>
                    <p><strong id="deleteTableNumber"></strong></p>
                    <p class="text-danger">This action cannot be undone.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <form method="POST" style="display: inline;">
                        <input type="hidden" name="action" value="delete_table">
                        <input type="hidden" name="id" id="deleteTableId">
                        <button type="submit" class="btn btn-danger">
                            <i class="fas fa-trash"></i> Delete
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Generate QR codes for all tables
        document.addEventListener('DOMContentLoaded', function() {
            <?php foreach ($tables as $table): ?>
                generateQRCode(<?php echo $table['id']; ?>, <?php echo json_encode($table['qr_code']); ?>);
            <?php endforeach; ?>
        });
        
        function generateQRCode(tableId, qrData) {
            const canvas = document.createElement('canvas');
            QRCode.toCanvas(canvas, qrData, {
                width: 100,
                margin: 1,
                color: {
                    dark: '#000000',
                    light: '#FFFFFF'
                }
            }, function (error) {
                if (error) console.error(error);
                else {
                    const qrContainer = document.getElementById('qr-' + tableId);
                    qrContainer.innerHTML = '';
                    qrContainer.appendChild(canvas);
                }
            });
        }
        
        function editTable(table) {
            document.getElementById('formAction').value = 'edit_table';
            document.getElementById('tableId').value = table.id;
            document.getElementById('table_number').value = table.table_number;
            document.getElementById('is_active').checked = table.is_active == 1;
            
            document.querySelector('.modal-title').innerHTML = '<i class="fas fa-edit"></i> Edit Table';
            document.querySelector('.modal-footer button[type="submit"]').innerHTML = '<i class="fas fa-save"></i> Update Table';
            
            new bootstrap.Modal(document.getElementById('addTableModal')).show();
        }
        
        function showQRCode(tableId, tableNumber) {
            const qrData = <?php echo json_encode($tables); ?>.find(t => t.id == tableId).qr_code;
            
            const canvas = document.createElement('canvas');
            QRCode.toCanvas(canvas, qrData, {
                width: 200,
                margin: 2,
                color: {
                    dark: '#000000',
                    light: '#FFFFFF'
                }
            }, function (error) {
                if (error) console.error(error);
                else {
                    document.getElementById('qrCodeDisplay').innerHTML = '';
                    document.getElementById('qrCodeDisplay').appendChild(canvas);
                    document.getElementById('qrTableNumber').textContent = 'Table ' + tableNumber;
                    new bootstrap.Modal(document.getElementById('qrModal')).show();
                }
            });
        }
        
        function deleteTable(id, tableNumber) {
            document.getElementById('deleteTableId').value = id;
            document.getElementById('deleteTableNumber').textContent = 'Table ' + tableNumber;
            new bootstrap.Modal(document.getElementById('deleteModal')).show();
        }
        
        function downloadQRCode() {
            const canvas = document.querySelector('#qrCodeDisplay canvas');
            if (canvas) {
                const link = document.createElement('a');
                link.download = 'table-qr-code.png';
                link.href = canvas.toDataURL();
                link.click();
            }
        }
        
        // Reset form when modal is hidden
        document.getElementById('addTableModal').addEventListener('hidden.bs.modal', function() {
            document.getElementById('tableForm').reset();
            document.getElementById('formAction').value = 'add_table';
            document.getElementById('tableId').value = '';
            document.querySelector('.modal-title').innerHTML = '<i class="fas fa-plus"></i> Add Table';
            document.querySelector('.modal-footer button[type="submit"]').innerHTML = '<i class="fas fa-save"></i> Save Table';
        });
    </script>
    <?php include 'includes/footer.php'; ?>
