<?php
require_once 'backend/config/database.php';

$database = new Database();
$db = $database->getConnection();

echo "<!DOCTYPE html><html><head><title>Order Debug Test</title>";
echo "<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css' rel='stylesheet'>";
echo "</head><body><div class='container mt-5'>";
echo "<h1>Order Debug Test</h1>";

try {
    // Test order data
    $testOrder = [
        'customer_name' => 'Test Customer',
        'customer_mobile' => '0501234567',
        'table_number' => 'T01',
        'subtotal' => 50.00,
        'gst_rate' => 0.05,
        'gst_amount' => 2.50,
        'total_amount' => 52.50,
        'notes' => 'Test order',
        'items' => [
            [
                'menu_item_id' => 1,
                'item_name' => 'Test Item',
                'quantity' => 2,
                'price' => 25.00,
                'notes' => 'Test notes'
            ]
        ]
    ];
    
    echo "<h3>Test Order Data:</h3>";
    echo "<pre>" . htmlspecialchars(json_encode($testOrder, JSON_PRETTY_PRINT)) . "</pre>";
    
    // Test API endpoint
    $api_url = "http://localhost/quick-order/backend/api/orders.php";
    $jsonData = json_encode($testOrder);
    
    echo "<h3>Testing API Endpoint:</h3>";
    echo "<p><strong>URL:</strong> $api_url</p>";
    echo "<p><strong>Method:</strong> POST</p>";
    echo "<p><strong>Data:</strong></p>";
    echo "<pre>" . htmlspecialchars($jsonData) . "</pre>";
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $api_url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_VERBOSE, true);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    
    echo "<h3>API Response:</h3>";
    echo "<p><strong>HTTP Code:</strong> $httpCode</p>";
    
    if ($error) {
        echo "<div class='alert alert-danger'>";
        echo "<strong>cURL Error:</strong> " . htmlspecialchars($error);
        echo "</div>";
    }
    
    if ($response) {
        echo "<div class='alert alert-" . ($httpCode == 200 ? 'success' : 'danger') . "'>";
        echo "<strong>Response:</strong><br>";
        echo "<pre>" . htmlspecialchars($response) . "</pre>";
        echo "</div>";
        
        // Try to decode JSON response
        $decoded = json_decode($response, true);
        if ($decoded) {
            echo "<h4>Decoded Response:</h4>";
            echo "<pre>" . htmlspecialchars(json_encode($decoded, JSON_PRETTY_PRINT)) . "</pre>";
        }
    } else {
        echo "<div class='alert alert-warning'>No response received</div>";
    }
    
    // Check database tables
    echo "<h3>Database Check:</h3>";
    
    // Check if tables exist
    $tables = ['orders', 'order_items', 'menu_items', 'categories', 'tables'];
    foreach ($tables as $table) {
        try {
            $query = "SELECT COUNT(*) as count FROM `$table`";
            $stmt = $db->prepare($query);
            $stmt->execute();
            $result = $stmt->fetch();
            echo "<p><strong>$table:</strong> " . $result['count'] . " records</p>";
        } catch (Exception $e) {
            echo "<p><strong>$table:</strong> <span class='text-danger'>Error: " . htmlspecialchars($e->getMessage()) . "</span></p>";
        }
    }
    
    // Check recent orders
    try {
        $query = "SELECT * FROM orders ORDER BY placed_at DESC LIMIT 3";
        $stmt = $db->prepare($query);
        $stmt->execute();
        $recentOrders = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if ($recentOrders) {
            echo "<h4>Recent Orders:</h4>";
            echo "<table class='table table-striped'>";
            echo "<thead><tr><th>Order #</th><th>Customer</th><th>Total</th><th>Status</th><th>Placed At</th></tr></thead><tbody>";
            foreach ($recentOrders as $order) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($order['order_number']) . "</td>";
                echo "<td>" . htmlspecialchars($order['customer_name']) . "</td>";
                echo "<td>Rs. " . number_format($order['total_amount'], 2) . "</td>";
                echo "<td><span class='badge bg-primary'>" . htmlspecialchars($order['status']) . "</span></td>";
                echo "<td>" . htmlspecialchars($order['placed_at']) . "</td>";
                echo "</tr>";
            }
            echo "</tbody></table>";
        } else {
            echo "<p class='text-muted'>No orders found in database.</p>";
        }
    } catch (Exception $e) {
        echo "<p class='text-danger'>Error checking orders: " . htmlspecialchars($e->getMessage()) . "</p>";
    }
    
} catch (Exception $e) {
    echo "<div class='alert alert-danger'>Error: " . htmlspecialchars($e->getMessage()) . "</div>";
}

echo "<div class='mt-4'>";
echo "<a href='frontend/ordering.php' class='btn btn-primary'>Test Frontend Ordering</a> ";
echo "<a href='ordering.php' class='btn btn-secondary'>Test Main Ordering</a>";
echo "</div>";
echo "</div></body></html>";
?>
