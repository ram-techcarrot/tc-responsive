<?php
require_once 'backend/config/database.php';

$database = new Database();
$db = $database->getConnection();

echo "<!DOCTYPE html>";
echo "<html><head><title>Add Dummy Orders</title>";
echo "<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css' rel='stylesheet'>";
echo "<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css'>";
echo "</head><body class='bg-light'>";

echo "<div class='container mt-5'>";
echo "<div class='row justify-content-center'>";
echo "<div class='col-md-10'>";
echo "<div class='card'>";
echo "<div class='card-header'>";
echo "<h3><i class='fas fa-shopping-cart'></i> Adding Dummy Orders</h3>";
echo "</div>";
echo "<div class='card-body'>";

try {
    // Clear existing orders first
    $db->exec("DELETE FROM order_items");
    $db->exec("DELETE FROM orders");
    echo "<div class='alert alert-info'>Cleared existing orders and order items.</div>";
    
    // Get some menu items for the orders
    $query = "SELECT id, name, price FROM menu_items LIMIT 10";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $menu_items = $stmt->fetchAll();
    
    if (empty($menu_items)) {
        echo "<div class='alert alert-warning'>";
        echo "<i class='fas fa-exclamation-triangle'></i> No menu items found. Please add some menu items first.";
        echo "</div>";
        echo "<div class='text-center mt-4'>";
        echo "<a href='backend/admin/menu.php' class='btn btn-primary' target='_blank'>";
        echo "<i class='fas fa-book'></i> Add Menu Items";
        echo "</a>";
        echo "</div>";
        echo "</div></div></div></div></div>";
        echo "</body></html>";
        exit();
    }
    
    // Define order statuses and their details
    $order_statuses = [
        'placed' => [
            'count' => 3,
            'description' => 'Recently placed orders waiting to be processed',
            'color' => 'primary'
        ],
        'pending' => [
            'count' => 2,
            'description' => 'Orders confirmed and waiting to be prepared',
            'color' => 'warning'
        ],
        'cooking' => [
            'count' => 2,
            'description' => 'Orders currently being prepared in kitchen',
            'color' => 'info'
        ],
        'served' => [
            'count' => 3,
            'description' => 'Orders served to customers',
            'color' => 'success'
        ],
        'completed' => [
            'count' => 2,
            'description' => 'Orders completed and ready for payment',
            'color' => 'secondary'
        ],
        'paid' => [
            'count' => 1,
            'description' => 'Orders fully paid and closed',
            'color' => 'dark'
        ]
    ];
    
    $added_orders = 0;
    $order_number = 1001;
    
    foreach ($order_statuses as $status => $details) {
        echo "<h5>Adding $details[count] '$status' orders...</h5>";
        
        for ($i = 1; $i <= $details['count']; $i++) {
            // Generate random customer data
            $customers = [
                ['name' => 'John Smith', 'mobile' => '+971501234567'],
                ['name' => 'Sarah Johnson', 'mobile' => '+971502345678'],
                ['name' => 'Ahmed Al-Rashid', 'mobile' => '+971503456789'],
                ['name' => 'Maria Garcia', 'mobile' => '+971504567890'],
                ['name' => 'David Brown', 'mobile' => '+971505678901'],
                ['name' => 'Fatima Al-Zahra', 'mobile' => '+971506789012'],
                ['name' => 'Michael Wilson', 'mobile' => '+971507890123'],
                ['name' => 'Aisha Khan', 'mobile' => '+971508901234'],
                ['name' => 'Robert Taylor', 'mobile' => '+971509012345'],
                ['name' => 'Layla Hassan', 'mobile' => '+971500123456']
            ];
            
            $customer = $customers[array_rand($customers)];
            
            // Generate random table number
            $table_numbers = ['T01', 'T02', 'T03', 'T04', 'T05', 'T06', 'T07', 'T08', 'T09', 'T10'];
            $table_number = $table_numbers[array_rand($table_numbers)];
            
            // Calculate random time based on status
            $base_time = time() - (rand(1, 24) * 3600); // Random time in last 24 hours
            
            // Adjust timestamps based on status
            $placed_at = date('Y-m-d H:i:s', $base_time);
            $pending_at = null;
            $cooking_at = null;
            $served_at = null;
            $completed_at = null;
            $paid_at = null;
            
            if (in_array($status, ['pending', 'cooking', 'served', 'completed', 'paid'])) {
                $pending_at = date('Y-m-d H:i:s', $base_time + rand(60, 300));
            }
            if (in_array($status, ['cooking', 'served', 'completed', 'paid'])) {
                $cooking_at = date('Y-m-d H:i:s', $base_time + rand(300, 600));
            }
            if (in_array($status, ['served', 'completed', 'paid'])) {
                $served_at = date('Y-m-d H:i:s', $base_time + rand(600, 1200));
            }
            if (in_array($status, ['completed', 'paid'])) {
                $completed_at = date('Y-m-d H:i:s', $base_time + rand(1200, 1800));
            }
            if ($status === 'paid') {
                $paid_at = date('Y-m-d H:i:s', $base_time + rand(1800, 2400));
            }
            
            // Insert order
            $query = "INSERT INTO orders (order_number, customer_name, customer_mobile, table_number, 
                      status, total_amount, placed_at, pending_at, cooking_at, served_at, completed_at, paid_at) 
                      VALUES (:order_number, :customer_name, :customer_mobile, :table_number, 
                      :status, :total_amount, :placed_at, :pending_at, :cooking_at, :served_at, :completed_at, :paid_at)";
            
            $stmt = $db->prepare($query);
            $stmt->bindParam(':order_number', $order_number);
            $stmt->bindParam(':customer_name', $customer['name']);
            $stmt->bindParam(':customer_mobile', $customer['mobile']);
            $stmt->bindParam(':table_number', $table_number);
            $stmt->bindParam(':status', $status);
            
            // Calculate total amount
            $total_amount = 0;
            $item_count = rand(1, 4); // Random number of items per order
            $selected_items = array_rand($menu_items, min($item_count, count($menu_items)));
            if (!is_array($selected_items)) {
                $selected_items = [$selected_items];
            }
            
            foreach ($selected_items as $item_index) {
                $quantity = rand(1, 3);
                $total_amount += $menu_items[$item_index]['price'] * $quantity;
            }
            
            $stmt->bindParam(':total_amount', $total_amount);
            $stmt->bindParam(':placed_at', $placed_at);
            $stmt->bindParam(':pending_at', $pending_at);
            $stmt->bindParam(':cooking_at', $cooking_at);
            $stmt->bindParam(':served_at', $served_at);
            $stmt->bindParam(':completed_at', $completed_at);
            $stmt->bindParam(':paid_at', $paid_at);
            
            if ($stmt->execute()) {
                $order_id = $db->lastInsertId();
                
                // Add order items
                foreach ($selected_items as $item_index) {
                    $quantity = rand(1, 3);
                    $item_price = $menu_items[$item_index]['price'];
                    
                    $query = "INSERT INTO order_items (order_id, menu_item_id, quantity, price) 
                              VALUES (:order_id, :menu_item_id, :quantity, :price)";
                    $stmt = $db->prepare($query);
                    $stmt->bindParam(':order_id', $order_id);
                    $stmt->bindParam(':menu_item_id', $menu_items[$item_index]['id']);
                    $stmt->bindParam(':quantity', $quantity);
                    $stmt->bindParam(':price', $item_price);
                    $stmt->execute();
                }
                
                echo "<div class='alert alert-success'>";
                echo "<i class='fas fa-check'></i> Order #$order_number ($status) - $customer[name] - Table $table_number - Rs. " . number_format($total_amount, 2);
                echo "</div>";
                
                $added_orders++;
                $order_number++;
            } else {
                echo "<div class='alert alert-danger'>";
                echo "<i class='fas fa-times'></i> Failed to add order #$order_number";
                echo "</div>";
            }
        }
        echo "<br>";
    }
    
    echo "<hr>";
    echo "<div class='alert alert-success'>";
    echo "<h5><i class='fas fa-check-circle'></i> Success!</h5>";
    echo "<p>Added $added_orders dummy orders across all statuses.</p>";
    echo "</div>";
    
    // Show summary by status
    echo "<h5>Order Summary by Status</h5>";
    echo "<div class='row'>";
    foreach ($order_statuses as $status => $details) {
        $query = "SELECT COUNT(*) as count, SUM(total_amount) as total FROM orders WHERE status = :status";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':status', $status);
        $stmt->execute();
        $result = $stmt->fetch();
        
        echo "<div class='col-md-6 col-lg-4 mb-3'>";
        echo "<div class='card border-$details[color]'>";
        echo "<div class='card-body text-center'>";
        echo "<i class='fas fa-shopping-cart fa-2x text-$details[color] mb-2'></i>";
        echo "<h6 class='text-$details[color]'>" . ucfirst($status) . "</h6>";
        echo "<p class='mb-1'><strong>$result[count]</strong> orders</p>";
        echo "<p class='mb-0 text-muted'>Rs. " . number_format($result['total'] ?? 0, 2) . "</p>";
        echo "</div></div></div>";
    }
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div class='alert alert-danger'>";
    echo "<h5><i class='fas fa-exclamation-triangle'></i> Error</h5>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
}

echo "<div class='text-center mt-4'>";
echo "<a href='backend/admin/orders.php' class='btn btn-primary' target='_blank'>";
echo "<i class='fas fa-shopping-cart'></i> View Orders";
echo "</a>";
echo "<a href='backend/admin/dashboard.php' class='btn btn-success ms-2' target='_blank'>";
echo "<i class='fas fa-tachometer-alt'></i> Dashboard";
echo "</a>";
echo "<a href='quick-access.html' class='btn btn-secondary ms-2'>";
echo "<i class='fas fa-home'></i> Quick Access";
echo "</a>";
echo "</div>";

echo "</div></div></div></div></div>";

echo "<script src='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js'></script>";
echo "</body></html>";
?>
