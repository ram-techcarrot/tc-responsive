<?php
/**
 * Admin Header
 * Common header for all admin pages
 */

// Get current page name for page title
$current_page = basename($_SERVER['PHP_SELF']);
$page_titles = [
    'dashboard.php' => 'Dashboard',
    'orders.php' => 'Order Management',
    'unpaid-orders.php' => 'Unpaid Orders',
    'menu.php' => 'Menu Management',
    'categories.php' => 'Category Management',
    'tables.php' => 'Table Management',
    'qr-codes.php' => 'QR Code Generator',
    'reports.php' => 'Reports',
    'settings.php' => 'Settings'
];

$page_title = $page_titles[$current_page] ?? 'Admin Panel';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - Quick Order</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .sidebar {
            min-height: 100vh;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            border-radius: 8px;
            margin: 2px 0;
        }
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            color: white;
            background: rgba(255,255,255,0.1);
        }
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.3);
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
