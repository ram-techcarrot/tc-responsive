# Quick Order System - Production Ready

A complete restaurant ordering system with admin panel, customer ordering interface, and real-time order management.

## 🚀 Features

### Customer Interface
- **Menu Browsing**: Browse categories and menu items with prices
- **Shopping Cart**: Add items, adjust quantities, view totals
- **Order Placement**: Place orders with customer details and table number
- **Order Tracking**: View order status and details
- **Responsive Design**: Works on desktop, tablet, and mobile

### Admin Panel
- **Dashboard**: Overview of orders, sales, and statistics
- **Order Management**: View, update, and track all orders
- **Menu Management**: Add, edit, and manage menu items and categories
- **Table Management**: Manage restaurant tables and QR codes
- **Reports**: Daily sales reports and analytics
- **Settings**: Configure system settings

### Technical Features
- **Real-time Updates**: Order status updates in real-time
- **Security**: Secure authentication and session management
- **Database**: MySQL database with proper schema
- **API**: RESTful API for frontend-backend communication
- **Responsive**: Bootstrap-based responsive design

## 📁 Project Structure

```
quick-order/
├── backend/                 # Backend API and admin panel
│   ├── admin/              # Admin panel pages
│   ├── api/                # REST API endpoints
│   ├── auth/               # Authentication system
│   ├── config/             # Database configuration
│   └── sql/                # Database schema
├── css/                    # Stylesheets
├── image/                  # Images and icons
├── js/                     # JavaScript files
├── error_pages/            # Custom error pages
├── frontend/               # Frontend pages
├── test/                   # Test and development files
├── ordering.php            # Main ordering page
├── order-success.php       # Order success page
└── index.html             # Landing page
```

## 🛠️ Installation

1. **Database Setup**:
   ```sql
   -- Run the schema.sql file in your MySQL database
   mysql -u username -p database_name < backend/sql/schema.sql
   ```

2. **Configuration**:
   - Update `backend/config/database.php` with your database credentials
   - Ensure proper file permissions

3. **Web Server**:
   - Place files in your web server directory
   - Ensure PHP 7.4+ and MySQL 5.7+ are installed
   - Enable mod_rewrite for Apache

## 🔧 Configuration

### Database Configuration
Edit `backend/config/database.php`:
```php
private $host = "localhost";
private $db_name = "quickorder";
private $username = "your_username";
private $password = "your_password";
```

### Admin Access
- Default admin credentials: `admin` / `admin123`
- Change these in production!

## 📱 Usage

### For Customers
1. Visit the ordering page
2. Browse menu categories and items
3. Add items to cart
4. Enter customer details and table number
5. Place order
6. View order confirmation

### For Admins
1. Login at `/backend/auth/login.php`
2. Access dashboard for overview
3. Manage orders, menu, and settings
4. Generate reports

## 🔒 Security Features

- Password hashing with PHP's `password_hash()`
- Session-based authentication
- SQL injection prevention with prepared statements
- XSS protection with proper output escaping
- Directory indexing prevention
- Custom error pages

## 🧪 Testing

All test files are located in the `/test` directory:
- `/test/dummy/` - Dummy data generation scripts
- `/test/debug/` - Debugging and fix scripts
- `/test/` - Various test scripts

**Note**: Test files should not be deployed to production.

## 📄 License

This project is proprietary software. All rights reserved.

## 🆘 Support

For technical support or questions, please contact the development team.

---

**Production Ready** ✅
- Clean codebase structure
- Security best practices implemented
- Test files organized separately
- Documentation complete