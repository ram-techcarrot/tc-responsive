<?php
require_once 'backend/config/database.php';

$database = new Database();
$db = $database->getConnection();

echo "<!DOCTYPE html>";
echo "<html><head><title>Add Sample Menu</title>";
echo "<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css' rel='stylesheet'>";
echo "<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css'>";
echo "</head><body class='bg-light'>";

echo "<div class='container mt-5'>";
echo "<div class='row justify-content-center'>";
echo "<div class='col-md-10'>";
echo "<div class='card'>";
echo "<div class='card-header'>";
echo "<h3><i class='fas fa-book'></i> Adding Sample Menu Items</h3>";
echo "</div>";
echo "<div class='card-body'>";

try {
    // Clear existing menu items first
    $db->exec("DELETE FROM menu_items");
    echo "<div class='alert alert-info'>Cleared existing menu items.</div>";
    
    // Get categories
    $query = "SELECT id, name FROM categories";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $categories = $stmt->fetchAll();
    
    if (empty($categories)) {
        echo "<div class='alert alert-warning'>";
        echo "<i class='fas fa-exclamation-triangle'></i> No categories found. Please add categories first.";
        echo "</div>";
        echo "<div class='text-center mt-4'>";
        echo "<a href='add_sample_categories.php' class='btn btn-primary' target='_blank'>";
        echo "<i class='fas fa-tags'></i> Add Categories";
        echo "</a>";
        echo "</div>";
        echo "</div></div></div></div></div>";
        echo "</body></html>";
        exit();
    }
    
    // Sample menu items
    $menu_items = [
        // Tea Category
        ['name' => 'Black Tea', 'description' => 'Classic black tea with rich flavor', 'price' => 8.00, 'image' => 'black_tea.png', 'category' => 'Tea'],
        ['name' => 'Green Tea', 'description' => 'Refreshing green tea with antioxidants', 'price' => 9.00, 'image' => 'green_tea.png', 'category' => 'Tea'],
        ['name' => 'Chamomile Tea', 'description' => 'Soothing herbal tea for relaxation', 'price' => 10.00, 'image' => 'chamomile_tea.png', 'category' => 'Tea'],
        ['name' => 'Ginger Lemon Tea', 'description' => 'Warming tea with ginger and lemon', 'price' => 12.00, 'image' => 'ginger_lemon.png', 'category' => 'Tea'],
        ['name' => 'Milk Tea', 'description' => 'Creamy tea with milk', 'price' => 11.00, 'image' => 'milk_tea.png', 'category' => 'Tea'],
        
        // Coffee Category
        ['name' => 'Espresso', 'description' => 'Strong Italian coffee', 'price' => 15.00, 'image' => null, 'category' => 'Coffee'],
        ['name' => 'Cappuccino', 'description' => 'Espresso with steamed milk foam', 'price' => 18.00, 'image' => null, 'category' => 'Coffee'],
        ['name' => 'Latte', 'description' => 'Espresso with steamed milk', 'price' => 20.00, 'image' => null, 'category' => 'Coffee'],
        ['name' => 'Americano', 'description' => 'Espresso with hot water', 'price' => 16.00, 'image' => null, 'category' => 'Coffee'],
        
        // Juice Category
        ['name' => 'Orange Juice', 'description' => 'Fresh squeezed orange juice', 'price' => 12.00, 'image' => null, 'category' => 'Juice'],
        ['name' => 'Apple Juice', 'description' => 'Fresh apple juice', 'price' => 11.00, 'image' => null, 'category' => 'Juice'],
        ['name' => 'Mango Juice', 'description' => 'Tropical mango juice', 'price' => 14.00, 'image' => null, 'category' => 'Juice'],
        
        // Water Category
        ['name' => 'Mineral Water', 'description' => 'Pure mineral water', 'price' => 5.00, 'image' => null, 'category' => 'Water'],
        ['name' => 'Sparkling Water', 'description' => 'Carbonated mineral water', 'price' => 6.00, 'image' => null, 'category' => 'Water'],
        
        // Soft Drinks Category
        ['name' => 'Coca Cola', 'description' => 'Classic cola drink', 'price' => 8.00, 'image' => null, 'category' => 'Soft Drinks'],
        ['name' => 'Pepsi', 'description' => 'Refreshing cola drink', 'price' => 8.00, 'image' => null, 'category' => 'Soft Drinks'],
        ['name' => 'Sprite', 'description' => 'Lemon-lime soda', 'price' => 8.00, 'image' => null, 'category' => 'Soft Drinks'],
        
        // Snacks Category
        ['name' => 'Chicken Sandwich', 'description' => 'Grilled chicken sandwich', 'price' => 25.00, 'image' => null, 'category' => 'Snacks'],
        ['name' => 'Vegetable Wrap', 'description' => 'Fresh vegetable wrap', 'price' => 22.00, 'image' => null, 'category' => 'Snacks'],
        ['name' => 'French Fries', 'description' => 'Crispy golden fries', 'price' => 15.00, 'image' => null, 'category' => 'Snacks'],
        ['name' => 'Chicken Wings', 'description' => 'Spicy chicken wings', 'price' => 28.00, 'image' => null, 'category' => 'Snacks']
    ];
    
    $added_count = 0;
    
    foreach ($menu_items as $item) {
        // Find category ID
        $category_id = null;
        foreach ($categories as $cat) {
            if ($cat['name'] === $item['category']) {
                $category_id = $cat['id'];
                break;
            }
        }
        
        if ($category_id) {
            $query = "INSERT INTO menu_items (category_id, name, description, price, image, is_available, sort_order) 
                      VALUES (:category_id, :name, :description, :price, :image, 1, :sort_order)";
            $stmt = $db->prepare($query);
            $stmt->bindParam(':category_id', $category_id);
            $stmt->bindParam(':name', $item['name']);
            $stmt->bindParam(':description', $item['description']);
            $stmt->bindParam(':price', $item['price']);
            $stmt->bindParam(':image', $item['image']);
            $stmt->bindParam(':sort_order', $added_count);
            
            if ($stmt->execute()) {
                echo "<div class='alert alert-success'>";
                echo "<i class='fas fa-check'></i> Added: " . htmlspecialchars($item['name']) . " - Rs. " . number_format($item['price'], 2);
                echo "</div>";
                $added_count++;
            } else {
                echo "<div class='alert alert-danger'>";
                echo "<i class='fas fa-times'></i> Failed to add: " . htmlspecialchars($item['name']);
                echo "</div>";
            }
        } else {
            echo "<div class='alert alert-warning'>";
            echo "<i class='fas fa-exclamation-triangle'></i> Category not found for: " . htmlspecialchars($item['name']);
            echo "</div>";
        }
    }
    
    echo "<hr>";
    echo "<div class='alert alert-success'>";
    echo "<h5><i class='fas fa-check-circle'></i> Success!</h5>";
    echo "<p>Added $added_count menu items to the database.</p>";
    echo "</div>";
    
    // Show summary by category
    echo "<h5>Menu Summary by Category</h5>";
    echo "<div class='row'>";
    foreach ($categories as $category) {
        $query = "SELECT COUNT(*) as count, AVG(price) as avg_price FROM menu_items WHERE category_id = :category_id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':category_id', $category['id']);
        $stmt->execute();
        $result = $stmt->fetch();
        
        echo "<div class='col-md-6 col-lg-4 mb-3'>";
        echo "<div class='card'>";
        echo "<div class='card-body text-center'>";
        echo "<i class='fas fa-book fa-2x text-primary mb-2'></i>";
        echo "<h6>" . htmlspecialchars($category['name']) . "</h6>";
        echo "<p class='mb-1'><strong>$result[count]</strong> items</p>";
        echo "<p class='mb-0 text-muted'>Avg: Rs. " . number_format($result['avg_price'] ?? 0, 2) . "</p>";
        echo "</div></div></div>";
    }
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div class='alert alert-danger'>";
    echo "<h5><i class='fas fa-exclamation-triangle'></i> Error</h5>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
}

echo "<div class='text-center mt-4'>";
echo "<a href='backend/admin/menu.php' class='btn btn-primary' target='_blank'>";
echo "<i class='fas fa-book'></i> Manage Menu";
echo "</a>";
echo "<a href='add_dummy_orders.php' class='btn btn-success ms-2' target='_blank'>";
echo "<i class='fas fa-shopping-cart'></i> Add Dummy Orders";
echo "</a>";
echo "<a href='quick-access.html' class='btn btn-secondary ms-2'>";
echo "<i class='fas fa-home'></i> Quick Access";
echo "</a>";
echo "</div>";

echo "</div></div></div></div></div>";

echo "<script src='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js'></script>";
echo "</body></html>";
?>
