<?php
require_once 'backend/config/database.php';

$database = new Database();
$db = $database->getConnection();

echo "<!DOCTYPE html>";
echo "<html><head><title>Add Single Order</title>";
echo "<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css' rel='stylesheet'>";
echo "</head><body class='bg-light'>";

echo "<div class='container mt-5'>";
echo "<div class='row justify-content-center'>";
echo "<div class='col-md-8'>";
echo "<div class='card'>";
echo "<div class='card-header'>";
echo "<h3><i class='fas fa-plus'></i> Add Single Test Order</h3>";
echo "</div>";
echo "<div class='card-body'>";

try {
    // First, let's add a simple order
    $query = "INSERT INTO orders (order_number, customer_name, customer_mobile, table_number, 
              status, total_amount, placed_at) 
              VALUES ('1001', 'Test Customer', '+971501234567', 'T01', 'placed', 25.00, NOW())";
    
    $result = $db->exec($query);
    
    if ($result) {
        $order_id = $db->lastInsertId();
        echo "<div class='alert alert-success'>";
        echo "<i class='fas fa-check-circle'></i> Order added successfully! Order ID: $order_id";
        echo "</div>";
        
        // Now let's verify it exists
        $query = "SELECT * FROM orders WHERE id = :id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':id', $order_id);
        $stmt->execute();
        $order = $stmt->fetch();
        
        if ($order) {
            echo "<div class='alert alert-info'>";
            echo "<h6>Order Details:</h6>";
            echo "<p><strong>Order Number:</strong> " . htmlspecialchars($order['order_number']) . "</p>";
            echo "<p><strong>Customer:</strong> " . htmlspecialchars($order['customer_name']) . "</p>";
            echo "<p><strong>Table:</strong> " . htmlspecialchars($order['table_number']) . "</p>";
            echo "<p><strong>Status:</strong> " . htmlspecialchars($order['status']) . "</p>";
            echo "<p><strong>Amount:</strong> Rs. " . number_format($order['total_amount'], 2) . "</p>";
            echo "<p><strong>Placed At:</strong> " . htmlspecialchars($order['placed_at']) . "</p>";
            echo "</div>";
        }
        
        // Check total orders count
        $query = "SELECT COUNT(*) as count FROM orders";
        $stmt = $db->prepare($query);
        $stmt->execute();
        $result = $stmt->fetch();
        
        echo "<div class='alert alert-success'>";
        echo "<i class='fas fa-info-circle'></i> Total orders in database: " . $result['count'];
        echo "</div>";
        
    } else {
        echo "<div class='alert alert-danger'>";
        echo "<i class='fas fa-times-circle'></i> Failed to add order";
        echo "</div>";
    }
    
} catch (Exception $e) {
    echo "<div class='alert alert-danger'>";
    echo "<h5><i class='fas fa-exclamation-triangle'></i> Error</h5>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
}

echo "<div class='text-center mt-4'>";
echo "<a href='backend/admin/orders.php' class='btn btn-primary' target='_blank'>";
echo "<i class='fas fa-shopping-cart'></i> View Orders Page";
echo "</a>";
echo "<a href='add_dummy_orders.php' class='btn btn-success ms-2' target='_blank'>";
echo "<i class='fas fa-plus'></i> Add More Orders";
echo "</a>";
echo "</div>";

echo "</div></div></div></div></div>";
echo "</body></html>";
?>
