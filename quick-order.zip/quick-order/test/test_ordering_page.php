<?php
echo "<!DOCTYPE html>";
echo "<html><head><title>Ordering Page Test</title>";
echo "<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css' rel='stylesheet'>";
echo "<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css'>";
echo "</head><body class='bg-light'>";

echo "<div class='container mt-5'>";
echo "<div class='row justify-content-center'>";
echo "<div class='col-md-12'>";
echo "<div class='card'>";
echo "<div class='card-header'>";
echo "<h3><i class='fas fa-shopping-cart'></i> Ordering Page Test</h3>";
echo "</div>";
echo "<div class='card-body'>";

// Test 1: Check if ordering page exists and loads
echo "<h5>1. Ordering Page File Test</h5>";
if (file_exists('ordering.php')) {
    echo "<div class='alert alert-success'>";
    echo "<i class='fas fa-check-circle'></i> ordering.php file exists";
    echo "</div>";
} else {
    echo "<div class='alert alert-danger'>";
    echo "<i class='fas fa-times-circle'></i> ordering.php file not found";
    echo "</div>";
}

// Test 2: Check API endpoints
echo "<h5>2. API Endpoints Test</h5>";

// Test menu API
echo "<div class='alert alert-info'>";
echo "<h6><i class='fas fa-book'></i> Menu API Test</h6>";
echo "<p>Testing: <code>backend/api/menu.php</code></p>";
echo "</div>";

try {
    $menu_response = file_get_contents('http://localhost/quick-order/backend/api/menu.php');
    $menu_data = json_decode($menu_response, true);
    
    if ($menu_data && $menu_data['success']) {
        echo "<div class='alert alert-success'>";
        echo "<i class='fas fa-check-circle'></i> Menu API working!";
        echo "<br><strong>Categories:</strong> " . count($menu_data['categories']);
        echo "<br><strong>Menu Items:</strong> " . count($menu_data['menu_items']);
        echo "</div>";
        
        // Show sample data
        echo "<div class='row'>";
        echo "<div class='col-md-6'>";
        echo "<h6>Sample Categories:</h6>";
        echo "<div class='table-responsive'>";
        echo "<table class='table table-sm'>";
        echo "<thead><tr><th>Name</th><th>Icon</th><th>Active</th></tr></thead>";
        echo "<tbody>";
        foreach (array_slice($menu_data['categories'], 0, 5) as $category) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($category['name']) . "</td>";
            echo "<td>" . htmlspecialchars($category['icon']) . "</td>";
            echo "<td>" . ($category['is_active'] ? 'Yes' : 'No') . "</td>";
            echo "</tr>";
        }
        echo "</tbody></table>";
        echo "</div>";
        echo "</div>";
        
        echo "<div class='col-md-6'>";
        echo "<h6>Sample Menu Items:</h6>";
        echo "<div class='table-responsive'>";
        echo "<table class='table table-sm'>";
        echo "<thead><tr><th>Name</th><th>Category</th><th>Price</th></tr></thead>";
        echo "<tbody>";
        foreach (array_slice($menu_data['menu_items'], 0, 5) as $item) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($item['name']) . "</td>";
            echo "<td>" . htmlspecialchars($item['category_name']) . "</td>";
            echo "<td>Rs. " . number_format($item['price'], 2) . "</td>";
            echo "</tr>";
        }
        echo "</tbody></table>";
        echo "</div>";
        echo "</div>";
        echo "</div>";
        
    } else {
        echo "<div class='alert alert-danger'>";
        echo "<i class='fas fa-times-circle'></i> Menu API failed!";
        echo "<br>Response: " . htmlspecialchars($menu_response);
        echo "</div>";
    }
} catch (Exception $e) {
    echo "<div class='alert alert-danger'>";
    echo "<i class='fas fa-times-circle'></i> Menu API error: " . $e->getMessage();
    echo "</div>";
}

// Test orders API
echo "<div class='alert alert-info mt-3'>";
echo "<h6><i class='fas fa-shopping-cart'></i> Orders API Test</h6>";
echo "<p>Testing: <code>backend/api/orders.php</code></p>";
echo "</div>";

try {
    // Test GET request (order status check)
    $order_response = file_get_contents('http://localhost/quick-order/backend/api/orders.php?order_number=TEST123');
    
    if ($order_response) {
        $order_data = json_decode($order_response, true);
        
        if ($order_data && !$order_data['success']) {
            echo "<div class='alert alert-warning'>";
            echo "<i class='fas fa-exclamation-triangle'></i> Orders API working (no test order found - expected)";
            echo "<br>Response: " . htmlspecialchars($order_response);
            echo "</div>";
        } else {
            echo "<div class='alert alert-success'>";
            echo "<i class='fas fa-check-circle'></i> Orders API working!";
            echo "</div>";
        }
    } else {
        echo "<div class='alert alert-danger'>";
        echo "<i class='fas fa-times-circle'></i> Orders API failed!";
        echo "</div>";
    }
} catch (Exception $e) {
    echo "<div class='alert alert-danger'>";
    echo "<i class='fas fa-times-circle'></i> Orders API error: " . $e->getMessage();
    echo "</div>";
}

echo "<hr>";

// Test 3: Check required files and dependencies
echo "<h5>3. Dependencies Test</h5>";

$required_files = [
    'css/ordering-styles.css' => 'CSS Styles',
    'image/sobha-logo.svg' => 'Logo Image',
    'backend/config/database.php' => 'Database Config',
    'backend/api/menu.php' => 'Menu API',
    'backend/api/orders.php' => 'Orders API'
];

echo "<div class='row'>";
foreach ($required_files as $file => $description) {
    echo "<div class='col-md-6 mb-2'>";
    if (file_exists($file)) {
        echo "<div class='alert alert-success py-2'>";
        echo "<i class='fas fa-check'></i> $description: <code>$file</code>";
        echo "</div>";
    } else {
        echo "<div class='alert alert-danger py-2'>";
        echo "<i class='fas fa-times'></i> Missing: <code>$file</code>";
        echo "</div>";
    }
    echo "</div>";
}
echo "</div>";

echo "<hr>";

// Test 4: Ordering page features
echo "<h5>4. Ordering Page Features Test</h5>";
echo "<div class='row'>";
echo "<div class='col-md-6'>";
echo "<h6>✅ Expected Features:</h6>";
echo "<ul>";
echo "<li>Dynamic menu loading from API</li>";
echo "<li>Category filtering</li>";
echo "<li>Search functionality</li>";
echo "<li>Add to cart with quantities</li>";
echo "<li>Cart management (add/remove/update)</li>";
echo "<li>Order placement with customer details</li>";
echo "<li>Real-time cart updates</li>";
echo "<li>Currency: Rs. (Rupees)</li>";
echo "<li>Responsive design</li>";
echo "</ul>";
echo "</div>";

echo "<div class='col-md-6'>";
echo "<h6>🔧 Technical Features:</h6>";
echo "<ul>";
echo "<li>JavaScript cart management</li>";
echo "<li>AJAX API calls</li>";
echo "<li>Bootstrap 5 styling</li>";
echo "<li>Font Awesome icons</li>";
echo "<li>Modal for customer details</li>";
echo "<li>Form validation</li>";
echo "<li>Local storage for order tracking</li>";
echo "<li>Auto-redirect to success page</li>";
echo "</ul>";
echo "</div>";
echo "</div>";

echo "<hr>";

// Test 5: Complete flow test
echo "<h5>5. Complete Ordering Flow Test</h5>";
echo "<div class='alert alert-info'>";
echo "<h6><i class='fas fa-list-ol'></i> Test Steps</h6>";
echo "<ol>";
echo "<li><strong>Open Ordering Page:</strong> Click the link below to open ordering.php</li>";
echo "<li><strong>Check Menu Loading:</strong> Verify categories and menu items load from database</li>";
echo "<li><strong>Test Category Filter:</strong> Click different categories to filter items</li>";
echo "<li><strong>Test Search:</strong> Use search bar to find specific items</li>";
echo "<li><strong>Add Items to Cart:</strong> Click 'Add' buttons to add items</li>";
echo "<li><strong>Manage Cart:</strong> Adjust quantities, remove items</li>";
echo "<li><strong>Place Order:</strong> Click 'Place Order' and fill customer details</li>";
echo "<li><strong>Check Success Page:</strong> Verify redirect to order-success.php</li>";
echo "<li><strong>Check Admin Panel:</strong> Verify order appears in admin dashboard</li>";
echo "</ol>";
echo "</div>";

echo "<div class='row'>";
echo "<div class='col-md-4 mb-3'>";
echo "<div class='card'>";
echo "<div class='card-body text-center'>";
echo "<i class='fas fa-shopping-cart fa-2x text-primary mb-2'></i>";
echo "<h6>Test Ordering Page</h6>";
echo "<p class='text-muted'>Open the ordering page</p>";
echo "<a href='ordering.php' class='btn btn-primary' target='_blank'>";
echo "<i class='fas fa-external-link-alt'></i> Open Ordering";
echo "</a>";
echo "</div></div></div>";

echo "<div class='col-md-4 mb-3'>";
echo "<div class='card'>";
echo "<div class='card-body text-center'>";
echo "<i class='fas fa-check-circle fa-2x text-success mb-2'></i>";
echo "<h6>Test Success Page</h6>";
echo "<p class='text-muted'>View order success page</p>";
echo "<a href='order-success.php' class='btn btn-success' target='_blank'>";
echo "<i class='fas fa-external-link-alt'></i> Open Success";
echo "</a>";
echo "</div></div></div>";

echo "<div class='col-md-4 mb-3'>";
echo "<div class='card'>";
echo "<div class='card-body text-center'>";
echo "<i class='fas fa-tachometer-alt fa-2x text-info mb-2'></i>";
echo "<h6>Check Admin Panel</h6>";
echo "<p class='text-muted'>View orders in admin</p>";
echo "<a href='backend/admin/dashboard.php' class='btn btn-info' target='_blank'>";
echo "<i class='fas fa-external-link-alt'></i> Admin Panel";
echo "</a>";
echo "</div></div></div>";
echo "</div>";

echo "<hr>";

// Test 6: Sample order data
echo "<h5>6. Sample Order Test Data</h5>";
echo "<div class='alert alert-warning'>";
echo "<h6><i class='fas fa-info-circle'></i> Test Order Information</h6>";
echo "<p>Use this sample data to test the ordering flow:</p>";
echo "<div class='row'>";
echo "<div class='col-md-6'>";
echo "<h6>Customer Details:</h6>";
echo "<ul>";
echo "<li><strong>Name:</strong> Test Customer</li>";
echo "<li><strong>Mobile:</strong> +971501234567</li>";
echo "<li><strong>Table:</strong> T01</li>";
echo "<li><strong>Notes:</strong> Test order</li>";
echo "</ul>";
echo "</div>";
echo "<div class='col-md-6'>";
echo "<h6>Sample Items:</h6>";
echo "<ul>";
echo "<li>Black Tea (Rs. 8.00)</li>";
echo "<li>Chicken Sandwich (Rs. 25.00)</li>";
echo "<li>French Fries (Rs. 15.00)</li>";
echo "</ul>";
echo "</div>";
echo "</div>";
echo "</div>";

echo "<div class='text-center mt-4'>";
echo "<a href='test_frontend.php' class='btn btn-secondary'>";
echo "<i class='fas fa-arrow-left'></i> Back to Frontend Test";
echo "</a>";
echo "<a href='quick-access.html' class='btn btn-primary ms-2'>";
echo "<i class='fas fa-home'></i> Quick Access";
echo "</a>";
echo "</div>";

echo "</div></div></div></div></div>";

echo "<script src='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js'></script>";
echo "</body></html>";
?>
