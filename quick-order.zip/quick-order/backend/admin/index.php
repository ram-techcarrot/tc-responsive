<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    // Store the current page to redirect after successful login
    $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'];
    header('Location: ../auth/login.php?unauthorized=1');
    exit();
}

// Redirect to dashboard
header('Location: dashboard.php');
exit();
?>