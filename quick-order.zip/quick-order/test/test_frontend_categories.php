<?php
require_once 'backend/config/database.php';

$database = new Database();
$db = $database->getConnection();

echo "<!DOCTYPE html><html><head><title>Test Frontend Categories</title>";
echo "<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css' rel='stylesheet'>";
echo "<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css'>";
echo "</head><body><div class='container mt-5'>";
echo "<h1>Test Frontend Categories</h1>";

try {
    // Get categories
    $query = "SELECT * FROM categories WHERE is_active = 1 ORDER BY sort_order, name";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<h3>Categories from Database:</h3>";
    echo "<div class='row'>";
    foreach ($categories as $category) {
        echo "<div class='col-md-4 mb-3'>";
        echo "<div class='card'>";
        echo "<div class='card-body'>";
        echo "<h5 class='card-title'>";
        
        // Show icon
        if ($category['icon']) {
            if (strpos($category['icon'], 'fas ') === 0 || strpos($category['icon'], 'fa ') === 0) {
                echo "<i class='" . htmlspecialchars($category['icon']) . "'></i> ";
            } else {
                echo "<img src='image/" . htmlspecialchars($category['icon']) . "' alt='" . htmlspecialchars($category['name']) . "' style='width: 20px; height: 20px;'> ";
            }
        }
        
        echo htmlspecialchars($category['name']);
        echo "</h5>";
        echo "<p class='card-text'>";
        echo "<strong>ID:</strong> " . $category['id'] . "<br>";
        echo "<strong>Icon:</strong> " . htmlspecialchars($category['icon']) . "<br>";
        echo "<strong>Sort Order:</strong> " . $category['sort_order'] . "<br>";
        echo "<strong>Active:</strong> " . ($category['is_active'] ? 'Yes' : 'No');
        echo "</p>";
        echo "</div></div></div>";
    }
    echo "</div>";
    
    // Test API response
    echo "<h3>API Response Test:</h3>";
    $api_url = "http://localhost/quick-order/backend/api/menu.php";
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $api_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode == 200) {
        $data = json_decode($response, true);
        echo "<div class='alert alert-success'>API Response (HTTP $httpCode):</div>";
        echo "<pre>" . htmlspecialchars(json_encode($data, JSON_PRETTY_PRINT)) . "</pre>";
    } else {
        echo "<div class='alert alert-danger'>API Error (HTTP $httpCode):</div>";
        echo "<pre>" . htmlspecialchars($response) . "</pre>";
    }
    
} catch (Exception $e) {
    echo "<div class='alert alert-danger'>Error: " . htmlspecialchars($e->getMessage()) . "</div>";
}

echo "<div class='mt-4'>";
echo "<a href='frontend/ordering.php' class='btn btn-primary'>Test Frontend Ordering Page</a> ";
echo "<a href='ordering.php' class='btn btn-secondary'>Test Main Ordering Page</a>";
echo "</div>";
echo "</div></body></html>";
?>
