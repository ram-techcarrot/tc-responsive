# 🔐 Authentication System Guide

## Overview
The Quick Order system now includes comprehensive authentication checks on all admin pages to ensure secure access.

## ✅ Authentication Features Implemented

### 1. **Session-Based Authentication**
- Users must login to access admin pages
- Sessions are maintained across page requests
- Automatic redirect to login page for unauthenticated users

### 2. **Session Timeout Protection**
- Sessions expire after 2 hours of inactivity
- Users are automatically logged out when session expires
- Clear message shown when session expires

### 3. **Role-Based Access Control**
- Only admin users can access admin panel
- Non-admin users are automatically logged out
- Role verification on every page load

### 4. **Smart Redirects**
- Users are redirected back to their original page after login
- Proper redirect paths based on current directory structure
- Handles nested directory structures correctly

### 5. **Secure Logout**
- Complete session cleanup on logout
- Confirmation message shown after logout
- Prevents session hijacking

## 📁 Files Updated

### Core Authentication Files:
- `backend/auth/check_auth.php` - Basic authentication check
- `backend/auth/auth_check.php` - Enhanced authentication with timeout
- `backend/auth/protect.php` - Universal protection middleware
- `backend/auth/login.php` - Updated with redirect handling
- `backend/auth/logout.php` - Enhanced logout with cleanup

### Protected Admin Pages:
- `backend/admin/dashboard.php` ✅ Protected
- `backend/admin/orders.php` ✅ Protected  
- `backend/admin/menu.php` ✅ Protected
- `backend/admin/tables.php` ✅ Protected
- `backend/admin/reports.php` ✅ Protected
- `backend/admin/settings.php` ✅ Protected

## 🚀 How to Use

### For Existing Pages:
All admin pages already include authentication checks:
```php
<?php
require_once '../auth/check_auth.php';
// Rest of your page code
?>
```

### For New Pages:
Use the universal protection middleware:
```php
<?php
require_once 'backend/auth/protect.php';
// Rest of your page code
?>
```

### For Custom Protection:
Use the enhanced authentication check:
```php
<?php
require_once 'backend/auth/auth_check.php';
// Rest of your page code
?>
```

## 🔧 Authentication Flow

### 1. **User Access Attempt**
```
User visits protected page → Check authentication → Redirect to login
```

### 2. **Login Process**
```
User enters credentials → Verify password → Set session → Redirect to original page
```

### 3. **Session Management**
```
Page load → Check session → Update activity time → Check timeout → Allow/Deny access
```

### 4. **Logout Process**
```
User clicks logout → Clear session → Redirect to login with message
```

## 🛡️ Security Features

### Session Security:
- ✅ Session timeout (2 hours)
- ✅ Activity tracking
- ✅ Secure session cleanup
- ✅ Session hijacking prevention

### Access Control:
- ✅ Role-based restrictions
- ✅ Automatic redirects
- ✅ Unauthorized access prevention
- ✅ Clear error messages

### User Experience:
- ✅ Remember original page
- ✅ Clear status messages
- ✅ Smooth redirects
- ✅ No broken links

## 🧪 Testing Authentication

### Test Pages Available:
1. **Authentication Test**: `http://localhost/quick-order/test_auth.php`
   - Shows session information
   - Tests all authentication features
   - Provides quick access to admin pages

2. **Login Test**: `http://localhost/quick-order/debug_login.php`
   - Tests database connection
   - Verifies password hashing
   - Provides working login form

3. **Simple Login**: `http://localhost/quick-order/simple_login.php`
   - Clean login interface
   - Better error handling
   - Pre-filled test credentials

### Test Scenarios:
1. **Direct Access Test**: Try accessing `backend/admin/dashboard.php` without login
2. **Session Timeout Test**: Wait 2+ hours and try accessing admin pages
3. **Logout Test**: Login and then logout, verify redirect
4. **Redirect Test**: Access a specific admin page, login, verify redirect back

## 📋 Session Variables

### Stored in Session:
- `$_SESSION['logged_in']` - Boolean authentication status
- `$_SESSION['user_id']` - User ID from database
- `$_SESSION['username']` - Username
- `$_SESSION['role']` - User role (admin/staff)
- `$_SESSION['last_activity']` - Last activity timestamp
- `$_SESSION['redirect_after_login']` - Original page URL

## 🔄 URL Parameters

### Login Page Messages:
- `?expired=1` - Session expired message
- `?unauthorized=1` - Unauthorized access message  
- `?logout=1` - Successful logout message

## 🚨 Troubleshooting

### Common Issues:
1. **Infinite Redirect Loop**: Check file paths in authentication files
2. **Session Not Working**: Verify PHP sessions are enabled
3. **Login Not Working**: Check database connection and password hashing
4. **Redirect Issues**: Verify URL structure and paths

### Debug Steps:
1. Check browser developer tools for redirects
2. Verify session variables with `test_auth.php`
3. Test database connection with `debug_login.php`
4. Check PHP error logs for issues

## 📝 Notes

- All admin pages are now fully protected
- Frontend pages (customer interface) remain public
- Authentication is session-based, not cookie-based
- Sessions are server-side and secure
- No sensitive data stored in client-side storage

---

**Authentication Status**: ✅ **FULLY IMPLEMENTED AND TESTED**

**Last Updated**: <?php echo date('Y-m-d H:i:s'); ?>

**Version**: v1.0
