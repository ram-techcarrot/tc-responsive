<?php
require_once 'backend/config/database.php';

echo "<!DOCTYPE html>";
echo "<html><head><title>Quick Order Setup Complete</title>";
echo "<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css' rel='stylesheet'>";
echo "<style>body{background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; display: flex; align-items: center; justify-content: center;}</style>";
echo "</head><body>";

echo "<div class='container'>";
echo "<div class='row justify-content-center'>";
echo "<div class='col-md-8'>";
echo "<div class='card shadow-lg'>";
echo "<div class='card-body p-5'>";

echo "<div class='text-center mb-4'>";
echo "<h1 class='text-primary'><i class='fas fa-check-circle'></i> Quick Order System</h1>";
echo "<h2 class='text-success'>Setup Complete!</h2>";
echo "</div>";

try {
    $database = new Database();
    $db = $database->getConnection();
    
    if ($db) {
        echo "<div class='alert alert-success'>";
        echo "<h4><i class='fas fa-database'></i> Database Connection: ✅ Success</h4>";
        echo "<p>All database tables have been created successfully.</p>";
        echo "</div>";
        
        // Check all tables
        $tables = ['users', 'categories', 'menu_items', 'tables', 'orders', 'order_items', 'settings'];
        $allTablesExist = true;
        
        foreach ($tables as $table) {
            $query = "SHOW TABLES LIKE '$table'";
            $stmt = $db->prepare($query);
            $stmt->execute();
            if (!$stmt->fetch()) {
                $allTablesExist = false;
                break;
            }
        }
        
        if ($allTablesExist) {
            echo "<div class='alert alert-success'>";
            echo "<h4><i class='fas fa-table'></i> Database Tables: ✅ All Created</h4>";
            echo "<p>7 tables created successfully: users, categories, menu_items, tables, orders, order_items, settings</p>";
            echo "</div>";
        }
        
        // Check default data
        $query = "SELECT COUNT(*) as count FROM users WHERE username='admin'";
        $stmt = $db->prepare($query);
        $stmt->execute();
        $adminCount = $stmt->fetch()['count'];
        
        if ($adminCount > 0) {
            echo "<div class='alert alert-success'>";
            echo "<h4><i class='fas fa-user-shield'></i> Admin User: ✅ Created</h4>";
            echo "<p>Default admin user created successfully.</p>";
            echo "</div>";
        }
        
        $query = "SELECT COUNT(*) as count FROM categories";
        $stmt = $db->prepare($query);
        $stmt->execute();
        $categoryCount = $stmt->fetch()['count'];
        
        if ($categoryCount > 0) {
            echo "<div class='alert alert-success'>";
            echo "<h4><i class='fas fa-tags'></i> Menu Categories: ✅ Loaded</h4>";
            echo "<p>$categoryCount categories loaded with default menu items.</p>";
            echo "</div>";
        }
        
        echo "<hr>";
        echo "<div class='text-center'>";
        echo "<h3 class='mb-4'>🚀 Your System is Ready!</h3>";
        echo "<div class='row'>";
        echo "<div class='col-md-4 mb-3'>";
        echo "<a href='backend/auth/login.php' class='btn btn-primary btn-lg w-100'>";
        echo "<i class='fas fa-user-shield'></i><br>Admin Panel";
        echo "</a>";
        echo "</div>";
        echo "<div class='col-md-4 mb-3'>";
        echo "<a href='index.html' class='btn btn-success btn-lg w-100'>";
        echo "<i class='fas fa-home'></i><br>Landing Page";
        echo "</a>";
        echo "</div>";
        echo "<div class='col-md-4 mb-3'>";
        echo "<a href='frontend/ordering.php' class='btn btn-info btn-lg w-100'>";
        echo "<i class='fas fa-shopping-cart'></i><br>Order System";
        echo "</a>";
        echo "</div>";
        echo "</div>";
        echo "</div>";
        
        echo "<div class='alert alert-info mt-4'>";
        echo "<h5><i class='fas fa-key'></i> Current Admin Credentials:</h5>";
        echo "<p><strong>Username:</strong> admin<br><strong>Password:</strong> admin123</p>";
        echo "</div>";
        
    } else {
        echo "<div class='alert alert-danger'>";
        echo "<h4>❌ Database Connection Failed</h4>";
        echo "<p>Please check your database configuration.</p>";
        echo "</div>";
    }
    
} catch (Exception $e) {
    echo "<div class='alert alert-danger'>";
    echo "<h4>❌ Setup Error</h4>";
    echo "<p>Error: " . $e->getMessage() . "</p>";
    echo "</div>";
}

echo "</div></div></div></div></div>";
echo "<script src='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js'></script>";
echo "<script src='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/js/all.min.js'></script>";
echo "</body></html>";
?>
