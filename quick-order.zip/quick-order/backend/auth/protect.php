<?php
/**
 * Authentication Protection Middleware
 * Include this file at the top of any page that requires authentication
 */

session_start();

// Check if user is logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    // Store the current page URL for redirect after login
    $current_page = $_SERVER['REQUEST_URI'];
    $_SESSION['redirect_after_login'] = $current_page;
    
    // Determine the correct login path based on current directory
    $login_path = 'login.php';
    if (strpos($_SERVER['REQUEST_URI'], '/admin/') !== false) {
        $login_path = '../auth/login.php';
    } elseif (strpos($_SERVER['REQUEST_URI'], '/backend/') !== false) {
        $login_path = 'auth/login.php';
    }
    
    header('Location: ' . $login_path);
    exit();
}

// Check session timeout (2 hours)
$session_timeout = 7200; // 2 hours in seconds
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $session_timeout)) {
    // Session expired
    session_unset();
    session_destroy();
    
    $login_path = 'login.php?expired=1';
    if (strpos($_SERVER['REQUEST_URI'], '/admin/') !== false) {
        $login_path = '../auth/login.php?expired=1';
    } elseif (strpos($_SERVER['REQUEST_URI'], '/backend/') !== false) {
        $login_path = 'auth/login.php?expired=1';
    }
    
    header('Location: ' . $login_path);
    exit();
}

// Update last activity time
$_SESSION['last_activity'] = time();

// Optional: Check if user has admin role
if (isset($_SESSION['role']) && $_SESSION['role'] !== 'admin') {
    // Log out non-admin users
    session_unset();
    session_destroy();
    
    $login_path = 'login.php?unauthorized=1';
    if (strpos($_SERVER['REQUEST_URI'], '/admin/') !== false) {
        $login_path = '../auth/login.php?unauthorized=1';
    } elseif (strpos($_SERVER['REQUEST_URI'], '/backend/') !== false) {
        $login_path = 'auth/login.php?unauthorized=1';
    }
    
    header('Location: ' . $login_path);
    exit();
}
?>
