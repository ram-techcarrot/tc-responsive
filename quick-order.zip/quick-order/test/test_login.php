<?php
require_once 'backend/config/database.php';

echo "<h2>Admin Login Test</h2>";

try {
    $database = new Database();
    $db = $database->getConnection();
    
    if ($db) {
        // Test admin login
        $username = 'admin';
        $password = 'admin123';
        
        $query = "SELECT id, username, email, password, role FROM users WHERE username = :username";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':username', $username);
        $stmt->execute();
        
        if ($user = $stmt->fetch()) {
            if (password_verify($password, $user['password'])) {
                echo "<p style='color: green;'>✅ Admin login successful!</p>";
                echo "<p><strong>Username:</strong> " . htmlspecialchars($user['username']) . "</p>";
                echo "<p><strong>Email:</strong> " . htmlspecialchars($user['email']) . "</p>";
                echo "<p><strong>Role:</strong> " . htmlspecialchars($user['role']) . "</p>";
                echo "<p style='color: green;'>✅ You can now login to the admin panel with: admin / admin123</p>";
            } else {
                echo "<p style='color: red;'>❌ Password verification failed!</p>";
            }
        } else {
            echo "<p style='color: red;'>❌ Admin user not found!</p>";
        }
        
    } else {
        echo "<p style='color: red;'>❌ Database connection failed!</p>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Error: " . $e->getMessage() . "</p>";
}

echo "<hr>";
echo "<p><a href='backend/auth/login.php'>→ Go to Admin Login</a></p>";
echo "<p><a href='quick-access.html'>→ Quick Access Hub</a></p>";
?>
