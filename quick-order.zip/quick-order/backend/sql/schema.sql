-- Quick Order Database Schema

CREATE DATABASE IF NOT EXISTS `quickorder`;
USE `quickorder`;

-- Users table for admin authentication
CREATE TABLE IF NOT EXISTS `users` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `username` varchar(50) NOT NULL UNIQUE,
    `email` varchar(100) NOT NULL UNIQUE,
    `password` varchar(255) NOT NULL,
    `role` enum('admin','staff') DEFAULT 'staff',
    `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
    `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
);

-- Categories table
CREATE TABLE IF NOT EXISTS `categories` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `name` varchar(100) NOT NULL,
    `icon` varchar(255) DEFAULT NULL,
    `is_active` tinyint(1) DEFAULT 1,
    `sort_order` int(11) DEFAULT 0,
    `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
    `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
);

-- Menu items table
CREATE TABLE IF NOT EXISTS `menu_items` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `category_id` int(11) NOT NULL,
    `name` varchar(100) NOT NULL,
    `description` text DEFAULT NULL,
    `price` decimal(10,2) NOT NULL,
    `image` varchar(255) DEFAULT NULL,
    `is_available` tinyint(1) DEFAULT 1,
    `sort_order` int(11) DEFAULT 0,
    `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
    `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    FOREIGN KEY (`category_id`) REFERENCES `categories`(`id`) ON DELETE CASCADE
);

-- Tables table for restaurant tables
CREATE TABLE IF NOT EXISTS `tables` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `table_number` varchar(20) NOT NULL UNIQUE,
    `qr_code` varchar(255) DEFAULT NULL,
    `is_active` tinyint(1) DEFAULT 1,
    `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
    `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
);

-- Orders table
CREATE TABLE IF NOT EXISTS `orders` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `order_number` varchar(20) NOT NULL UNIQUE,
    `customer_name` varchar(100) NOT NULL,
    `customer_mobile` varchar(20) NOT NULL,
    `table_id` int(11) DEFAULT NULL,
    `status` enum('placed','pending','cooking','served','completed','paid') DEFAULT 'placed',
    `subtotal` decimal(10,2) NOT NULL DEFAULT 0.00,
    `gst_rate` decimal(5,2) DEFAULT 0.00,
    `gst_amount` decimal(10,2) DEFAULT 0.00,
    `total_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
    `notes` text DEFAULT NULL,
    `placed_at` timestamp DEFAULT CURRENT_TIMESTAMP,
    `served_at` timestamp NULL DEFAULT NULL,
    `completed_at` timestamp NULL DEFAULT NULL,
    `paid_at` timestamp NULL DEFAULT NULL,
    `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
    `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    FOREIGN KEY (`table_id`) REFERENCES `tables`(`id`) ON DELETE SET NULL,
    INDEX `idx_status` (`status`),
    INDEX `idx_placed_at` (`placed_at`)
);

-- Order items table
CREATE TABLE IF NOT EXISTS `order_items` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `order_id` int(11) NOT NULL,
    `menu_item_id` int(11) NOT NULL,
    `quantity` int(11) NOT NULL DEFAULT 1,
    `unit_price` decimal(10,2) NOT NULL,
    `total_price` decimal(10,2) NOT NULL,
    `notes` text DEFAULT NULL,
    `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    FOREIGN KEY (`order_id`) REFERENCES `orders`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`menu_item_id`) REFERENCES `menu_items`(`id`) ON DELETE CASCADE
);

-- Settings table for GST and other configurations
CREATE TABLE IF NOT EXISTS `settings` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `setting_key` varchar(100) NOT NULL UNIQUE,
    `setting_value` text NOT NULL,
    `description` text DEFAULT NULL,
    `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
    `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
);

-- Insert default admin user (password: admin123)
INSERT INTO `users` (`username`, `email`, `password`, `role`) VALUES 
('admin', 'admin@quickorder.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');

-- Insert default categories
INSERT INTO `categories` (`name`, `icon`, `sort_order`) VALUES 
('All', NULL, 0),
('Tea', 'Tea.svg', 1),
('Coffee', 'Coffee.svg', 2),
('Juices', 'Juice.svg', 3),
('Water', 'Water.svg', 4),
('Snacks', 'Snacks.svg', 5),
('Soft Drinks', 'Soft Drink.svg', 6);

-- Insert default menu items
INSERT INTO `menu_items` (`category_id`, `name`, `description`, `price`, `image`, `sort_order`) VALUES 
-- Tea items
(2, 'Ginger Lemon', 'Refreshing ginger lemon tea', 15.00, 'chamomile_tea.png', 1),
(2, 'Green Tea', 'Premium green tea', 12.00, 'green_tea.png', 2),
(2, 'Milk Tea', 'Classic milk tea', 18.00, 'milk_tea.png', 3),
(2, 'Chamomile', 'Soothing chamomile tea', 16.00, 'chamomile_tea.png', 4),
(2, 'Black Tea', 'Traditional black tea', 14.00, 'black_tea.png', 5),

-- Coffee items
(3, 'Espresso', 'Strong espresso coffee', 25.00, 'milk_tea.png', 1),
(3, 'Cappuccino', 'Creamy cappuccino', 30.00, 'milk_tea.png', 2),
(3, 'Latte', 'Smooth latte', 28.00, 'milk_tea.png', 3),
(3, 'Americano', 'Classic americano', 22.00, 'milk_tea.png', 4),

-- Juice items
(4, 'Orange Juice', 'Fresh orange juice', 20.00, 'green_tea.png', 1),
(4, 'Apple Juice', 'Fresh apple juice', 18.00, 'green_tea.png', 2),

-- Water items
(5, 'Still Water', 'Pure still water', 10.00, 'green_tea.png', 1),
(5, 'Sparkling Water', 'Refreshing sparkling water', 15.00, 'green_tea.png', 2),

-- Snacks items
(6, 'Cookies', 'Delicious cookies', 25.00, 'Snacks.svg', 1),
(6, 'Chips', 'Crispy chips', 20.00, 'Snacks.svg', 2),
(6, 'Nuts', 'Mixed nuts', 30.00, 'Snacks.svg', 3),

-- Soft drinks items
(7, 'Cola', 'Refreshing cola', 18.00, 'Soft Drink.svg', 1),
(7, 'Lemonade', 'Fresh lemonade', 16.00, 'Soft Drink.svg', 2),
(7, 'Ginger Ale', 'Spicy ginger ale', 20.00, 'Soft Drink.svg', 3);

-- Insert default settings
INSERT INTO `settings` (`setting_key`, `setting_value`, `description`) VALUES 
('gst_rate', '18.00', 'GST rate percentage'),
('gst_enabled', '1', 'Enable/disable GST calculation'),
('restaurant_name', 'Sobha Restaurant', 'Restaurant name'),
('restaurant_address', '123 Main Street, City', 'Restaurant address'),
('restaurant_phone', '+91 9876543210', 'Restaurant phone number');

-- Insert sample tables
INSERT INTO `tables` (`table_number`, `is_active`) VALUES 
('T001', 1),
('T002', 1),
('T003', 1),
('T004', 1),
('T005', 1);
