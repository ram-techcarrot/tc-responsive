<?php
echo "<h2>Login Debug Test</h2>";

// Test database connection
echo "<h3>1. Testing Database Connection</h3>";
try {
    require_once 'backend/config/database.php';
    $database = new Database();
    $db = $database->getConnection();
    
    if ($db) {
        echo "<p style='color: green;'>✅ Database connection successful!</p>";
    } else {
        echo "<p style='color: red;'>❌ Database connection failed!</p>";
        exit;
    }
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Database error: " . $e->getMessage() . "</p>";
    exit;
}

// Test admin user exists
echo "<h3>2. Testing Admin User</h3>";
try {
    $query = "SELECT id, username, email, password, role FROM users WHERE username = 'admin'";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $user = $stmt->fetch();
    
    if ($user) {
        echo "<p style='color: green;'>✅ Admin user found!</p>";
        echo "<p><strong>Username:</strong> " . htmlspecialchars($user['username']) . "</p>";
        echo "<p><strong>Email:</strong> " . htmlspecialchars($user['email']) . "</p>";
        echo "<p><strong>Role:</strong> " . htmlspecialchars($user['role']) . "</p>";
        echo "<p><strong>Password Hash:</strong> " . substr($user['password'], 0, 20) . "...</p>";
    } else {
        echo "<p style='color: red;'>❌ Admin user not found!</p>";
        exit;
    }
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Query error: " . $e->getMessage() . "</p>";
    exit;
}

// Test password verification
echo "<h3>3. Testing Password Verification</h3>";
$test_password = 'admin123';
if (password_verify($test_password, $user['password'])) {
    echo "<p style='color: green;'>✅ Password verification successful!</p>";
    echo "<p>Password 'admin123' matches the stored hash.</p>";
} else {
    echo "<p style='color: red;'>❌ Password verification failed!</p>";
    echo "<p>Password 'admin123' does not match the stored hash.</p>";
    
    // Let's reset the password
    echo "<h4>Resetting Password...</h4>";
    $new_hash = password_hash('admin123', PASSWORD_DEFAULT);
    $query = "UPDATE users SET password = :password WHERE username = 'admin'";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':password', $new_hash);
    
    if ($stmt->execute()) {
        echo "<p style='color: green;'>✅ Password reset successful!</p>";
        
        // Test again
        if (password_verify($test_password, $new_hash)) {
            echo "<p style='color: green;'>✅ New password verification successful!</p>";
        }
    } else {
        echo "<p style='color: red;'>❌ Password reset failed!</p>";
    }
}

echo "<hr>";
echo "<h3>4. Test Login Form</h3>";
echo "<form method='POST' style='border: 1px solid #ccc; padding: 20px; border-radius: 10px;'>";
echo "<div style='margin-bottom: 15px;'>";
echo "<label><strong>Username:</strong></label><br>";
echo "<input type='text' name='username' value='admin' style='padding: 8px; width: 200px;'>";
echo "</div>";
echo "<div style='margin-bottom: 15px;'>";
echo "<label><strong>Password:</strong></label><br>";
echo "<input type='password' name='password' value='admin123' style='padding: 8px; width: 200px;'>";
echo "</div>";
echo "<button type='submit' style='background: #007bff; color: white; padding: 10px 20px; border: none; border-radius: 5px;'>Test Login</button>";
echo "</form>";

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    echo "<h3>5. Login Test Result</h3>";
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    
    echo "<p><strong>Submitted Username:</strong> " . htmlspecialchars($username) . "</p>";
    echo "<p><strong>Submitted Password:</strong> " . htmlspecialchars($password) . "</p>";
    
    if (empty($username) || empty($password)) {
        echo "<p style='color: red;'>❌ Username or password is empty!</p>";
    } else {
        $query = "SELECT id, username, email, password, role FROM users WHERE username = :username";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':username', $username);
        $stmt->execute();
        
        if ($user = $stmt->fetch()) {
            if (password_verify($password, $user['password'])) {
                echo "<p style='color: green;'>✅ LOGIN SUCCESSFUL!</p>";
                echo "<p>You can now access the admin panel.</p>";
                echo "<p><a href='backend/auth/login.php'>→ Go to Admin Login</a></p>";
            } else {
                echo "<p style='color: red;'>❌ Invalid password!</p>";
            }
        } else {
            echo "<p style='color: red;'>❌ User not found!</p>";
        }
    }
}

echo "<hr>";
echo "<p><a href='backend/auth/login.php'>→ Go to Admin Login Page</a></p>";
echo "<p><a href='quick-access.html'>→ Quick Access Hub</a></p>";
?>
