# Test Files Directory

This directory contains all test, debug, utility scripts, and documentation that are not needed for production.

## Structure

### `/dummy/`
Contains scripts for generating dummy data:
- `add_dummy_orders.php` - Adds sample orders to the database
- `add_sample_categories.php` - Adds sample categories
- `add_sample_menu.php` - Adds sample menu items
- `add_single_order.php` - Adds a single test order

### `/debug/`
Contains debugging and fix scripts:
- `check_orders.php` - Debug script to check orders
- `debug_login.php` - Debug script for login issues
- `fix_order_items_table.php` - Fixes order_items table structure
- `fix_orders.php` - Fixes order-related issues

### `/instructions/`
Contains all documentation and guides:
- `AUTHENTICATION_GUIDE.md` - Authentication system documentation
- `CUSTOMER_FLOW_GUIDE.md` - Customer ordering flow documentation
- `README.md` - Main project documentation
- `SECURITY_GUIDE.md` - Security implementation guide
- `SETUP_COMPLETE.md` - Setup completion documentation

### Root test files
Contains various test scripts:
- `test_*.php` - Various test scripts for different components
- `admin_status.php` - Admin status check script
- `auth_status.php` - Authentication status check script
- `simple_login.php` - Simple login test script
- `setup_complete.php` - Setup completion check script

## Usage

These files should only be used during development and testing. They should not be deployed to production.

## Security Note

These files may contain sensitive information or bypass security measures. Keep them secure and do not expose them publicly.
