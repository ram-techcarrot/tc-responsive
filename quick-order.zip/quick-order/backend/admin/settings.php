<?php
require_once '../auth/check_auth.php';
require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $gst_rate = floatval($_POST['gst_rate']);
    $gst_enabled = isset($_POST['gst_enabled']) ? 1 : 0;
    $restaurant_name = trim($_POST['restaurant_name']);
    $restaurant_address = trim($_POST['restaurant_address']);
    $restaurant_phone = trim($_POST['restaurant_phone']);
    
    try {
        $db->beginTransaction();
        
        // Update GST settings
        $query = "UPDATE settings SET setting_value = :value WHERE setting_key = 'gst_rate'";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':value', $gst_rate);
        $stmt->execute();
        
        $query = "UPDATE settings SET setting_value = :value WHERE setting_key = 'gst_enabled'";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':value', $gst_enabled);
        $stmt->execute();
        
        // Update restaurant info
        $query = "UPDATE settings SET setting_value = :value WHERE setting_key = 'restaurant_name'";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':value', $restaurant_name);
        $stmt->execute();
        
        $query = "UPDATE settings SET setting_value = :value WHERE setting_key = 'restaurant_address'";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':value', $restaurant_address);
        $stmt->execute();
        
        $query = "UPDATE settings SET setting_value = :value WHERE setting_key = 'restaurant_phone'";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':value', $restaurant_phone);
        $stmt->execute();
        
        $db->commit();
        $success = 'Settings updated successfully!';
        
    } catch (Exception $e) {
        $db->rollBack();
        $error = 'Failed to update settings: ' . $e->getMessage();
    }
}

// Get current settings
$query = "SELECT setting_key, setting_value FROM settings";
$stmt = $db->prepare($query);
$stmt->execute();
$settings = [];
while ($row = $stmt->fetch()) {
    $settings[$row['setting_key']] = $row['setting_value'];
}
?>

<?php include 'includes/header.php'; ?>
    <style>
        .sidebar {
            min-height: 100vh;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            border-radius: 8px;
            margin: 2px 0;
        }
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            color: white;
            background: rgba(255,255,255,0.1);
        }
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.3);
        }
        .form-control:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
        }
        .settings-card {
            background: white;
            border-radius: 15px;
            padding: 2rem;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            margin-bottom: 2rem;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <?php include 'includes/sidebar.php'; ?>
            
            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2><i class="fas fa-cog"></i> Settings</h2>
                </div>
                
                <?php if (isset($success)): ?>
                    <div class="alert alert-success alert-dismissible fade show">
                        <i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <?php if (isset($error)): ?>
                    <div class="alert alert-danger alert-dismissible fade show">
                        <i class="fas fa-exclamation-triangle"></i> <?php echo htmlspecialchars($error); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <form method="POST">
                    <!-- Tax Settings -->
                    <div class="settings-card">
                        <h4 class="mb-4">
                            <i class="fas fa-percentage text-primary"></i> Tax Settings
                        </h4>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <div class="form-check form-switch">
                                        <input class="form-check-input" type="checkbox" name="gst_enabled" id="gst_enabled" 
                                               <?php echo $settings['gst_enabled'] == '1' ? 'checked' : ''; ?>>
                                        <label class="form-check-label" for="gst_enabled">
                                            <strong>Enable GST Calculation</strong>
                                        </label>
                                    </div>
                                    <small class="text-muted">Enable or disable GST calculation for orders</small>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="gst_rate" class="form-label">GST Rate (%)</label>
                                    <input type="number" class="form-control" name="gst_rate" id="gst_rate" 
                                           value="<?php echo htmlspecialchars($settings['gst_rate']); ?>" 
                                           step="0.01" min="0" max="100">
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Restaurant Information -->
                    <div class="settings-card">
                        <h4 class="mb-4">
                            <i class="fas fa-store text-success"></i> Restaurant Information
                        </h4>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="restaurant_name" class="form-label">Restaurant Name</label>
                                    <input type="text" class="form-control" name="restaurant_name" id="restaurant_name" 
                                           value="<?php echo htmlspecialchars($settings['restaurant_name']); ?>" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="restaurant_phone" class="form-label">Phone Number</label>
                                    <input type="tel" class="form-control" name="restaurant_phone" id="restaurant_phone" 
                                           value="<?php echo htmlspecialchars($settings['restaurant_phone']); ?>">
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="restaurant_address" class="form-label">Address</label>
                            <textarea class="form-control" name="restaurant_address" id="restaurant_address" rows="3"><?php echo htmlspecialchars($settings['restaurant_address']); ?></textarea>
                        </div>
                    </div>
                    
                    <!-- System Information -->
                    <div class="settings-card">
                        <h4 class="mb-4">
                            <i class="fas fa-info-circle text-info"></i> System Information
                        </h4>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">System Version</label>
                                    <input type="text" class="form-control" value="Quick Order v1.0" readonly>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Last Updated</label>
                                    <input type="text" class="form-control" value="<?php echo date('d M Y H:i:s'); ?>" readonly>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Database Status</label>
                                    <div class="input-group">
                                        <input type="text" class="form-control" value="Connected" readonly>
                                        <span class="input-group-text text-success">
                                            <i class="fas fa-check-circle"></i>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Admin User</label>
                                    <input type="text" class="form-control" value="<?php echo htmlspecialchars($_SESSION['username']); ?>" readonly>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Save Button -->
                    <div class="text-center">
                        <button type="submit" class="btn btn-primary btn-lg">
                            <i class="fas fa-save"></i> Save Settings
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Enable/disable GST rate input based on checkbox
        document.getElementById('gst_enabled').addEventListener('change', function() {
            const gstRateInput = document.getElementById('gst_rate');
            gstRateInput.disabled = !this.checked;
        });
        
        // Initialize on page load
        document.addEventListener('DOMContentLoaded', function() {
            const gstEnabled = document.getElementById('gst_enabled');
            const gstRateInput = document.getElementById('gst_rate');
            gstRateInput.disabled = !gstEnabled.checked;
        });
    </script>
    <?php include 'includes/footer.php'; ?>
