<!DOCTYPE html>
<html>
<head>
    <title>Cart Debug Test</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .menu-item-card { border: 1px solid #ccc; padding: 10px; margin: 5px; }
        .cart-item { border: 1px solid #007bff; padding: 10px; margin: 5px; background: #f8f9fa; }
    </style>
</head>
<body>
    <div class="container mt-5">
        <h1>Cart Debug Test</h1>
        
        <div class="row">
            <div class="col-md-6">
                <h3>Menu Items (with data attributes)</h3>
                <div class="menu-item-card" data-item-id="1" data-item-name="Tea" data-item-price="15.00">
                    <div class="item-name">Tea</div>
                    <div class="item-price">₹15.00</div>
                    <div class="quantity-controls">
                        <button class="qty-btn minus">-</button>
                        <span class="qty-display">0</span>
                        <button class="qty-btn plus">+</button>
                    </div>
                </div>
                
                <div class="menu-item-card" data-item-id="2" data-item-name="Coffee" data-item-price="20.00">
                    <div class="item-name">Coffee</div>
                    <div class="item-price">₹20.00</div>
                    <div class="quantity-controls">
                        <button class="qty-btn minus">-</button>
                        <span class="qty-display">0</span>
                        <button class="qty-btn plus">+</button>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6">
                <h3>Cart Items (simulated)</h3>
                <div class="cart-item">
                    <div class="item-name">Tea</div>
                    <div class="qty-display">2</div>
                    <input type="text" class="notes-input" placeholder="Notes.." value="Extra sugar">
                </div>
                
                <div class="cart-item">
                    <div class="item-name">Coffee</div>
                    <div class="qty-display">1</div>
                    <input type="text" class="notes-input" placeholder="Notes.." value="">
                </div>
            </div>
        </div>
        
        <div class="mt-4">
            <button class="btn btn-primary" onclick="testCartData()">Test Cart Data Extraction</button>
            <button class="btn btn-secondary" onclick="testOrderData()">Test Order Data Structure</button>
        </div>
        
        <div id="results" class="mt-4"></div>
    </div>

    <script>
        // Copy the getCartData function from frontend ordering page
        function getCartData() {
            const cartItems = document.querySelectorAll('.cart-item');
            const cartData = [];
            
            cartItems.forEach(item => {
                const itemName = item.querySelector('.item-name').textContent.trim();
                const quantity = parseInt(item.querySelector('.qty-display').textContent);
                const notes = item.querySelector('.notes-input').value || '';
                
                // Find the menu item data by searching through all menu items
                let menuItemData = null;
                const allMenuItems = document.querySelectorAll('.menu-item-card[data-item-id]');
                
                for (let menuItem of allMenuItems) {
                    const menuItemName = menuItem.querySelector('.item-name').textContent.trim();
                    if (menuItemName === itemName) {
                        menuItemData = menuItem;
                        break;
                    }
                }
                
                if (menuItemData) {
                    cartData.push({
                        id: parseInt(menuItemData.getAttribute('data-item-id')),
                        name: itemName,
                        price: parseFloat(menuItemData.getAttribute('data-item-price')),
                        quantity: quantity,
                        notes: notes
                    });
                } else {
                    console.warn('Could not find menu item data for:', itemName);
                }
            });
            
            return cartData;
        }
        
        function testCartData() {
            const cartData = getCartData();
            const resultsDiv = document.getElementById('results');
            
            resultsDiv.innerHTML = `
                <div class="alert alert-info">
                    <h4>Cart Data Extraction Test:</h4>
                    <pre>${JSON.stringify(cartData, null, 2)}</pre>
                </div>
            `;
        }
        
        function testOrderData() {
            const cartData = getCartData();
            
            // Calculate totals
            let subtotal = 0;
            cartData.forEach(item => {
                subtotal += item.price * item.quantity;
            });
            
            const gst_rate = 0.05;
            const gst_amount = subtotal * gst_rate;
            const total_amount = subtotal + gst_amount;
            
            const orderData = {
                customer_name: 'Test Customer',
                customer_mobile: '0501234567',
                table_number: 'T01',
                subtotal: subtotal,
                gst_rate: gst_rate,
                gst_amount: gst_amount,
                total_amount: total_amount,
                notes: 'Test order',
                items: cartData.map(item => ({
                    menu_item_id: item.id,
                    item_name: item.name,
                    quantity: item.quantity,
                    price: item.price,
                    notes: item.notes || ''
                }))
            };
            
            const resultsDiv = document.getElementById('results');
            resultsDiv.innerHTML = `
                <div class="alert alert-success">
                    <h4>Order Data Structure Test:</h4>
                    <pre>${JSON.stringify(orderData, null, 2)}</pre>
                </div>
            `;
        }
    </script>
</body>
</html>
