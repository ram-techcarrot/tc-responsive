<?php
require_once 'backend/config/database.php';

echo "<h2>Quick Order System - Connection Test</h2>";

try {
    $database = new Database();
    $db = $database->getConnection();
    
    if ($db) {
        echo "<p style='color: green;'>✅ Database connection successful!</p>";
        
        // Test query
        $query = "SELECT COUNT(*) as count FROM users";
        $stmt = $db->prepare($query);
        $stmt->execute();
        $result = $stmt->fetch();
        
        echo "<p style='color: green;'>✅ Database query successful! Users count: " . $result['count'] . "</p>";
        
        // Test menu items
        $query = "SELECT COUNT(*) as count FROM menu_items";
        $stmt = $db->prepare($query);
        $stmt->execute();
        $result = $stmt->fetch();
        
        echo "<p style='color: green;'>✅ Menu items count: " . $result['count'] . "</p>";
        
        // Test categories
        $query = "SELECT COUNT(*) as count FROM categories";
        $stmt = $db->prepare($query);
        $stmt->execute();
        $result = $stmt->fetch();
        
        echo "<p style='color: green;'>✅ Categories count: " . $result['count'] . "</p>";
        
        echo "<hr>";
        echo "<h3>System Status: ✅ READY</h3>";
        echo "<p><strong>Admin Panel:</strong> <a href='backend/auth/login.php'>Login Here</a></p>";
        echo "<p><strong>Frontend:</strong> <a href='index.html'>Landing Page</a></p>";
        echo "<p><strong>Ordering System:</strong> <a href='frontend/ordering.php'>Order Online</a></p>";
        
    } else {
        echo "<p style='color: red;'>❌ Database connection failed!</p>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Error: " . $e->getMessage() . "</p>";
}
?>
