<?php
require_once '../auth/protect.php';
require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

// Get order ID from URL
$order_id = isset($_GET['order_id']) ? (int)$_GET['order_id'] : 0;

if (!$order_id) {
    die('Invalid order ID');
}

// Get order details
try {
    $query = "SELECT o.*, t.table_number 
              FROM orders o 
              LEFT JOIN tables t ON o.table_id = t.id 
              WHERE o.id = :order_id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':order_id', $order_id);
    $stmt->execute();
    $order = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$order) {
        die('Order not found');
    }
} catch (Exception $e) {
    die('Error fetching order: ' . $e->getMessage());
}

// Get order items
try {
    $query = "SELECT * FROM order_items WHERE order_id = :order_id ORDER BY id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':order_id', $order_id);
    $stmt->execute();
    $order_items = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    die('Error fetching order items: ' . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receipt - Order #<?php echo $order['order_number']; ?></title>
    
    <style>
        /* Thermal Printer Styles */
        @media print {
            body { margin: 0; padding: 0; }
            .no-print { display: none !important; }
            .receipt { width: 100% !important; max-width: none !important; }
        }
        
        body {
            font-family: 'Courier New', monospace;
            background: #fff;
            margin: 0;
            padding: 20px;
            color: #000;
        }
        
        .receipt {
            max-width: 300px;
            margin: 0 auto;
            background: #fff;
            border: 1px solid #000;
            padding: 10px;
        }
        
        .header {
            text-align: center;
            border-bottom: 2px solid #000;
            padding-bottom: 10px;
            margin-bottom: 15px;
        }
        
        .restaurant-name {
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 5px;
        }
        
        .restaurant-address {
            font-size: 12px;
            margin-bottom: 5px;
        }
        
        .receipt-title {
            font-size: 16px;
            font-weight: bold;
            margin-top: 10px;
        }
        
        .order-info {
            margin-bottom: 15px;
        }
        
        .info-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 3px;
            font-size: 12px;
        }
        
        .items-section {
            border-top: 1px solid #000;
            border-bottom: 1px solid #000;
            padding: 10px 0;
            margin: 15px 0;
        }
        
        .item-header {
            display: flex;
            justify-content: space-between;
            font-weight: bold;
            font-size: 12px;
            margin-bottom: 5px;
            border-bottom: 1px dashed #000;
            padding-bottom: 3px;
        }
        
        .item-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 3px;
            font-size: 11px;
        }
        
        .item-name {
            flex: 1;
        }
        
        .item-qty {
            width: 30px;
            text-align: center;
        }
        
        .item-price {
            width: 60px;
            text-align: right;
        }
        
        .totals-section {
            margin-top: 15px;
        }
        
        .total-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 3px;
            font-size: 12px;
        }
        
        .total-final {
            font-weight: bold;
            font-size: 14px;
            border-top: 2px solid #000;
            padding-top: 5px;
            margin-top: 10px;
        }
        
        .footer {
            text-align: center;
            margin-top: 20px;
            font-size: 10px;
            border-top: 1px dashed #000;
            padding-top: 10px;
        }
        
        .print-button {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #007bff;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
        }
        
        .print-button:hover {
            background: #0056b3;
        }
    </style>
</head>
<body>
    <button class="print-button no-print" onclick="window.print()">
        <i class="fas fa-print"></i> Print Receipt
    </button>
    
    <div class="receipt">
        <div class="header">
            <div class="restaurant-name">SOBHA RESTAURANT</div>
            <div class="restaurant-address">123 Main Street, City, State 12345</div>
            <div class="restaurant-address">Phone: +1 (555) 123-4567</div>
            <div class="receipt-title">RECEIPT</div>
        </div>
        
        <div class="order-info">
            <div class="info-row">
                <span>Order #:</span>
                <span><?php echo $order['order_number']; ?></span>
            </div>
            <div class="info-row">
                <span>Date:</span>
                <span><?php echo date('d/m/Y', strtotime($order['created_at'])); ?></span>
            </div>
            <div class="info-row">
                <span>Time:</span>
                <span><?php echo date('H:i:s', strtotime($order['created_at'])); ?></span>
            </div>
            <div class="info-row">
                <span>Customer:</span>
                <span><?php echo htmlspecialchars($order['customer_name']); ?></span>
            </div>
            <?php if ($order['table_number']): ?>
            <div class="info-row">
                <span>Table:</span>
                <span><?php echo htmlspecialchars($order['table_number']); ?></span>
            </div>
            <?php endif; ?>
            <div class="info-row">
                <span>Mobile:</span>
                <span><?php echo htmlspecialchars($order['customer_mobile']); ?></span>
            </div>
        </div>
        
        <div class="items-section">
            <div class="item-header">
                <span class="item-name">Item</span>
                <span class="item-qty">Qty</span>
                <span class="item-price">Amount</span>
            </div>
            
            <?php foreach ($order_items as $item): ?>
            <div class="item-row">
                <span class="item-name"><?php echo htmlspecialchars($item['item_name']); ?></span>
                <span class="item-qty"><?php echo $item['quantity']; ?></span>
                <span class="item-price">Rs. <?php echo number_format($item['total_price'], 2); ?></span>
            </div>
            <?php endforeach; ?>
        </div>
        
        <div class="totals-section">
            <div class="total-row">
                <span>Subtotal:</span>
                <span>Rs. <?php echo number_format($order['subtotal'], 2); ?></span>
            </div>
            <?php if ($order['gst_rate'] > 0): ?>
            <div class="total-row">
                <span>GST (<?php echo $order['gst_rate']; ?>%):</span>
                <span>Rs. <?php echo number_format($order['gst_amount'], 2); ?></span>
            </div>
            <?php endif; ?>
            <div class="total-row total-final">
                <span>TOTAL:</span>
                <span>Rs. <?php echo number_format($order['total_amount'], 2); ?></span>
            </div>
        </div>
        
        <div class="footer">
            <div>Thank you for dining with us!</div>
            <div>Visit us again soon</div>
            <div style="margin-top: 10px;">
                <div>Generated on: <?php echo date('d/m/Y H:i:s'); ?></div>
                <div>Receipt ID: RCP<?php echo str_pad($order_id, 6, '0', STR_PAD_LEFT); ?></div>
            </div>
        </div>
    </div>
    
    <script>
        // Auto-print when page loads (optional)
        // window.onload = function() {
        //     setTimeout(function() {
        //         window.print();
        //     }, 1000);
        // };
        
        // Handle print event
        window.addEventListener('beforeprint', function() {
            document.title = 'Receipt_Order_<?php echo $order['order_number']; ?>';
        });
    </script>
</body>
</html>
