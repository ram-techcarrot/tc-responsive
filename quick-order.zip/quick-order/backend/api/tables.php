<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

try {
    // Get active tables
    $query = "SELECT id, table_number FROM tables WHERE is_active = 1 ORDER BY table_number";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $tables = $stmt->fetchAll();
    
    echo json_encode([
        'success' => true,
        'data' => $tables
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Failed to fetch tables',
        'error' => $e->getMessage()
    ]);
}
?>
