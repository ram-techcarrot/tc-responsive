<?php
/**
 * Error Pages Directory Index
 * Redirects to home page
 */

header('Location: ../index.html');
exit();
?>
