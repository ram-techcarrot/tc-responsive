<?php
require_once '../auth/check_auth.php';
require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'add_item') {
        $category_id = $_POST['category_id'];
        $name = trim($_POST['name']);
        $description = trim($_POST['description']);
        $price = floatval($_POST['price']);
        $image = $_POST['image'];
        $is_available = isset($_POST['is_available']) ? 1 : 0;
        
        $query = "INSERT INTO menu_items (category_id, name, description, price, image, is_available) 
                  VALUES (:category_id, :name, :description, :price, :image, :is_available)";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':category_id', $category_id);
        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':description', $description);
        $stmt->bindParam(':price', $price);
        $stmt->bindParam(':image', $image);
        $stmt->bindParam(':is_available', $is_available);
        
        if ($stmt->execute()) {
            $success = 'Menu item added successfully!';
        } else {
            $error = 'Failed to add menu item.';
        }
    } elseif ($action === 'edit_item') {
        $id = $_POST['id'];
        $category_id = $_POST['category_id'];
        $name = trim($_POST['name']);
        $description = trim($_POST['description']);
        $price = floatval($_POST['price']);
        $image = $_POST['image'];
        $is_available = isset($_POST['is_available']) ? 1 : 0;
        
        $query = "UPDATE menu_items SET category_id = :category_id, name = :name, 
                  description = :description, price = :price, image = :image, 
                  is_available = :is_available WHERE id = :id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->bindParam(':category_id', $category_id);
        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':description', $description);
        $stmt->bindParam(':price', $price);
        $stmt->bindParam(':image', $image);
        $stmt->bindParam(':is_available', $is_available);
        
        if ($stmt->execute()) {
            $success = 'Menu item updated successfully!';
        } else {
            $error = 'Failed to update menu item.';
        }
    } elseif ($action === 'delete_item') {
        $id = $_POST['id'];
        
        $query = "DELETE FROM menu_items WHERE id = :id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':id', $id);
        
        if ($stmt->execute()) {
            $success = 'Menu item deleted successfully!';
        } else {
            $error = 'Failed to delete menu item.';
        }
    }
}

// Get categories for dropdown
$query = "SELECT * FROM categories WHERE is_active = 1 ORDER BY sort_order, name";
$stmt = $db->prepare($query);
$stmt->execute();
$categories = $stmt->fetchAll();

// Get menu items with categories
$query = "SELECT mi.*, c.name as category_name FROM menu_items mi 
          LEFT JOIN categories c ON mi.category_id = c.id 
          ORDER BY c.sort_order, mi.sort_order, mi.name";
$stmt = $db->prepare($query);
$stmt->execute();
$menu_items = $stmt->fetchAll();

// Get item for editing
$edit_item = null;
if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $query = "SELECT * FROM menu_items WHERE id = :id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    $edit_item = $stmt->fetch();
}
?>

<?php include 'includes/header.php'; ?>
    <style>
        .menu-item-card {
            background: white;
            border-radius: 10px;
            padding: 1rem;
            margin-bottom: 1rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            border-left: 4px solid #007bff;
        }
        .menu-item-card.unavailable {
            border-left-color: #dc3545;
            opacity: 0.7;
        }
        .item-image {
            width: 60px;
            height: 60px;
            border-radius: 8px;
            object-fit: cover;
        }
        .form-control:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
        }
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.3);
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <?php include 'includes/sidebar.php'; ?>
            
            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2><i class="fas fa-book"></i> Menu Management</h2>
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addItemModal">
                        <i class="fas fa-plus"></i> Add Menu Item
                    </button>
                </div>
                
                <?php if (isset($success)): ?>
                    <div class="alert alert-success alert-dismissible fade show">
                        <i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <?php if (isset($error)): ?>
                    <div class="alert alert-danger alert-dismissible fade show">
                        <i class="fas fa-exclamation-triangle"></i> <?php echo htmlspecialchars($error); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <!-- Menu Items List -->
                <div class="row">
                    <?php foreach ($menu_items as $item): ?>
                        <div class="col-md-6 col-lg-4 mb-3">
                            <div class="menu-item-card <?php echo $item['is_available'] ? '' : 'unavailable'; ?>">
                                <div class="row align-items-center">
                                    <div class="col-3">
                                        <img src="../../image/<?php echo htmlspecialchars($item['image'] ?? 'default-item.png'); ?>" 
                                             alt="<?php echo htmlspecialchars($item['name'] ?? 'Item'); ?>" 
                                             class="item-image">
                                    </div>
                                    <div class="col-6">
                                        <h6 class="mb-1"><?php echo htmlspecialchars($item['name'] ?? 'Item'); ?></h6>
                                        <small class="text-muted"><?php echo htmlspecialchars($item['category_name'] ?? 'Category'); ?></small>
                                        <br>
                                        <strong class="text-success">₹<?php echo number_format($item['price'], 2); ?></strong>
                                        <?php if (!$item['is_available']): ?>
                                            <br><span class="badge bg-danger">Unavailable</span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-3 text-end">
                                        <button class="btn btn-sm btn-outline-primary" 
                                                onclick="editItem(<?php echo htmlspecialchars(json_encode($item)); ?>)">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-danger" 
                                                onclick="deleteItem(<?php echo $item['id']; ?>, '<?php echo htmlspecialchars($item['name'] ?? 'Item'); ?>')">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Add/Edit Item Modal -->
    <div class="modal fade" id="addItemModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-plus"></i> Add Menu Item
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" id="itemForm">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="add_item" id="formAction">
                        <input type="hidden" name="id" id="itemId">
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="category_id" class="form-label">Category</label>
                                    <select class="form-select" name="category_id" id="category_id" required>
                                        <option value="">Select Category</option>
                                        <?php foreach ($categories as $category): ?>
                                            <option value="<?php echo $category['id']; ?>">
                                                <?php echo htmlspecialchars($category['name'] ?? 'Category'); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="name" class="form-label">Item Name</label>
                                    <input type="text" class="form-control" name="name" id="name" required>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="description" class="form-label">Description</label>
                            <textarea class="form-control" name="description" id="description" rows="3"></textarea>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="price" class="form-label">Price (₹)</label>
                                    <input type="number" class="form-control" name="price" id="price" 
                                           step="0.01" min="0" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="image" class="form-label">Image File</label>
                                    <input type="text" class="form-control" name="image" id="image" 
                                           placeholder="e.g., tea.png">
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="is_available" 
                                       id="is_available" checked>
                                <label class="form-check-label" for="is_available">
                                    Available for ordering
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Save Item
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Delete Confirmation Modal -->
    <div class="modal fade" id="deleteModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-exclamation-triangle text-warning"></i> Confirm Delete
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to delete this menu item?</p>
                    <p><strong id="deleteItemName"></strong></p>
                    <p class="text-danger">This action cannot be undone.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <form method="POST" style="display: inline;">
                        <input type="hidden" name="action" value="delete_item">
                        <input type="hidden" name="id" id="deleteItemId">
                        <button type="submit" class="btn btn-danger">
                            <i class="fas fa-trash"></i> Delete
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function editItem(item) {
            document.getElementById('formAction').value = 'edit_item';
            document.getElementById('itemId').value = item.id;
            document.getElementById('category_id').value = item.category_id;
            document.getElementById('name').value = item.name;
            document.getElementById('description').value = item.description || '';
            document.getElementById('price').value = item.price;
            document.getElementById('image').value = item.image || '';
            document.getElementById('is_available').checked = item.is_available == 1;
            
            document.querySelector('.modal-title').innerHTML = '<i class="fas fa-edit"></i> Edit Menu Item';
            document.querySelector('.modal-footer button[type="submit"]').innerHTML = '<i class="fas fa-save"></i> Update Item';
            
            new bootstrap.Modal(document.getElementById('addItemModal')).show();
        }
        
        function deleteItem(id, name) {
            document.getElementById('deleteItemId').value = id;
            document.getElementById('deleteItemName').textContent = name;
            new bootstrap.Modal(document.getElementById('deleteModal')).show();
        }
        
        // Reset form when modal is hidden
        document.getElementById('addItemModal').addEventListener('hidden.bs.modal', function() {
            document.getElementById('itemForm').reset();
            document.getElementById('formAction').value = 'add_item';
            document.getElementById('itemId').value = '';
            document.querySelector('.modal-title').innerHTML = '<i class="fas fa-plus"></i> Add Menu Item';
            document.querySelector('.modal-footer button[type="submit"]').innerHTML = '<i class="fas fa-save"></i> Save Item';
        });
    </script>
    <?php include 'includes/footer.php'; ?>
