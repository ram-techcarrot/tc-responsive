<!DOCTYPE html>
<html>
<head>
    <title>Database Data Test</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1>Database Data Test</h1>
        
        <?php
        require_once 'backend/config/database.php';
        
        $database = new Database();
        $db = $database->getConnection();
        
        if (!$db) {
            echo '<div class="alert alert-danger">Database connection failed!</div>';
            exit;
        }
        
        echo '<div class="alert alert-success">Database connection successful!</div>';
        
        try {
            // Check categories
            $query = "SELECT COUNT(*) as count FROM categories WHERE is_active = 1";
            $stmt = $db->prepare($query);
            $stmt->execute();
            $result = $stmt->fetch();
            echo '<p><strong>Active categories:</strong> ' . $result['count'] . '</p>';
            
            // Check menu items
            $query = "SELECT COUNT(*) as count FROM menu_items WHERE is_available = 1";
            $stmt = $db->prepare($query);
            $stmt->execute();
            $result = $stmt->fetch();
            echo '<p><strong>Available menu items:</strong> ' . $result['count'] . '</p>';
            
            // Show sample data
            $query = "SELECT * FROM categories WHERE is_active = 1 ORDER BY sort_order, name LIMIT 5";
            $stmt = $db->prepare($query);
            $stmt->execute();
            $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            echo '<h3>Sample Categories:</h3>';
            if (count($categories) > 0) {
                echo '<ul>';
                foreach ($categories as $cat) {
                    echo '<li>' . htmlspecialchars($cat['name']) . ' (ID: ' . $cat['id'] . ') - Icon: ' . htmlspecialchars($cat['icon']) . '</li>';
                }
                echo '</ul>';
            } else {
                echo '<div class="alert alert-warning">No categories found. <a href="add_sample_categories.php">Add sample categories</a></div>';
            }
            
            $query = "SELECT mi.*, c.name as category_name FROM menu_items mi 
                      LEFT JOIN categories c ON mi.category_id = c.id 
                      WHERE mi.is_available = 1
                      ORDER BY c.sort_order, mi.sort_order, mi.name LIMIT 5";
            $stmt = $db->prepare($query);
            $stmt->execute();
            $menu_items = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            echo '<h3>Sample Menu Items:</h3>';
            if (count($menu_items) > 0) {
                echo '<ul>';
                foreach ($menu_items as $item) {
                    echo '<li>' . htmlspecialchars($item['name']) . ' (Rs. ' . $item['price'] . ') - Category: ' . htmlspecialchars($item['category_name']) . '</li>';
                }
                echo '</ul>';
            } else {
                echo '<div class="alert alert-warning">No menu items found. <a href="add_sample_menu.php">Add sample menu items</a></div>';
            }
            
        } catch (Exception $e) {
            echo '<div class="alert alert-danger">Error: ' . htmlspecialchars($e->getMessage()) . '</div>';
        }
        ?>
        
        <div class="mt-4">
            <a href="ordering.php" class="btn btn-primary">Test Ordering Page</a>
            <a href="add_sample_categories.php" class="btn btn-secondary">Add Sample Categories</a>
            <a href="add_sample_menu.php" class="btn btn-secondary">Add Sample Menu Items</a>
        </div>
    </div>
</body>
</html>
