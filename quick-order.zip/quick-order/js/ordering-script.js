// Initialize drag scrolling for category tabs
function initializeDragScrolling() {
  const scrollContainer = document.querySelector('.categories-scroll-container');
  if (!scrollContainer) return;

  let isDown = false;
  let startX;
  let scrollLeft;

  scrollContainer.addEventListener('mousedown', (e) => {
    isDown = true;
    scrollContainer.style.cursor = 'grabbing';
    startX = e.pageX - scrollContainer.offsetLeft;
    scrollLeft = scrollContainer.scrollLeft;
  });

  scrollContainer.addEventListener('mouseleave', () => {
    isDown = false;
    scrollContainer.style.cursor = 'grab';
  });

  scrollContainer.addEventListener('mouseup', () => {
    isDown = false;
    scrollContainer.style.cursor = 'grab';
  });

  scrollContainer.addEventListener('mousemove', (e) => {
    if (!isDown) return;
    e.preventDefault();
    const x = e.pageX - scrollContainer.offsetLeft;
    const walk = (x - startX) * 2; // Scroll speed multiplier
    scrollContainer.scrollLeft = scrollLeft - walk;
  });

  // Add grab cursor style
  scrollContainer.style.cursor = 'grab';
}

// Initialize quantity controls and cart functionality
function initializeQuantityControls() {
  // Add event listeners to all quantity buttons and menu items
  document.addEventListener('click', function(e) {
    // Check if clicked element is a quantity button
    if (e.target.classList.contains('qty-btn')) {
      const button = e.target;
      const quantityDisplay = button.parentElement.querySelector('.qty-display');
      if (quantityDisplay) {
        let currentQuantity = parseInt(quantityDisplay.textContent) || 0;
        
        if (button.classList.contains('plus')) {
          // Increase quantity
          currentQuantity++;
          quantityDisplay.textContent = currentQuantity;
          
          // If this is in the cart, update cart total and sync with menu
          if (button.closest('.cart-item')) {
            const cartItem = button.closest('.cart-item');
            const unitPriceElement = cartItem.querySelector('.unit-price');
            if (unitPriceElement) {
              updateCartItemTotal(cartItem, unitPriceElement.textContent);
            }
            updateCartTotal();
            updateMenuFromCart(cartItem, currentQuantity);
          } else if (button.closest('.menu-item-card')) {
            // If this is a menu item, add to cart when + is clicked
            const menuCard = button.closest('.menu-item-card');
            if (!menuCard.classList.contains('empty')) {
              addToCart(menuCard, true); // forceAdd = true
            }
          }
        } else if (button.classList.contains('minus')) {
          // Decrease quantity (minimum 0)
          if (currentQuantity > 0) {
            currentQuantity--;
            quantityDisplay.textContent = currentQuantity;
            
            // If this is in the cart, update cart total and sync with menu
            if (button.closest('.cart-item')) {
              const cartItem = button.closest('.cart-item');
              if (currentQuantity === 0) {
                // Remove item from cart if quantity becomes 0
                cartItem.remove();
                updateCartTotal();
                updateLastItemBorder();
              } else {
                const unitPriceElement = cartItem.querySelector('.unit-price');
                if (unitPriceElement) {
                  updateCartItemTotal(cartItem, unitPriceElement.textContent);
                }
                updateCartTotal();
                updateMenuFromCart(cartItem, currentQuantity);
              }
            } else if (button.closest('.menu-item-card')) {
              // If this is a menu item, update cart when - is clicked
              const menuCard = button.closest('.menu-item-card');
              if (!menuCard.classList.contains('empty')) {
                updateCartFromMenu(menuCard, currentQuantity);
              }
            }
          }
        }
      }
    }
    
    // Handle menu item clicks (add to cart) - DISABLED
    // Only + and - buttons should control quantity
    // if (e.target.closest('.menu-item-card') && !e.target.closest('.quantity-controls')) {
    //   const menuCard = e.target.closest('.menu-item-card');
    //   if (!menuCard.classList.contains('empty')) {
    //     addToCart(menuCard);
    //   }
    // }
    
    // Handle remove button clicks in cart
    if (e.target.closest('.remove-btn')) {
      const removeBtn = e.target.closest('.remove-btn');
      const cartItem = removeBtn.closest('.cart-item');
      if (cartItem) {
        // Sync menu items before removing from cart
        updateMenuFromCart(cartItem, 0);
        cartItem.remove();
        updateCartTotal();
        updateLastItemBorder();
      }
    }
  });
}

// Update cart based on menu item quantity
function updateCartFromMenu(menuCard, newQuantity) {
  const itemName = menuCard.querySelector('.item-name');
  if (!itemName) return;
  
  const itemNameText = itemName.textContent;
  const existingCartItem = findCartItem(itemNameText);
  
  if (existingCartItem) {
    if (newQuantity === 0) {
      // Remove item from cart if quantity becomes 0
      existingCartItem.remove();
    } else {
      // Update cart item quantity to match menu quantity
      const cartQtyDisplay = existingCartItem.querySelector('.qty-display');
      if (cartQtyDisplay) {
        cartQtyDisplay.textContent = newQuantity;
      }
    }
    // Update cart total
    updateCartTotal();
    
    // Update last item border
    updateLastItemBorder();
  }
}

// Update menu item quantity based on cart quantity
function updateMenuFromCart(cartItem, newQuantity) {
  const itemName = cartItem.querySelector('.item-name');
  if (!itemName) return;
  
  const itemNameText = itemName.textContent;
  
  // Find all menu items with the same name across all tabs
  const allMenuItems = document.querySelectorAll('.menu-item-card:not(.empty)');
  
  allMenuItems.forEach(menuCard => {
    const menuItemName = menuCard.querySelector('.item-name');
    if (menuItemName && menuItemName.textContent.trim() === itemNameText.trim()) {
      const menuQtyDisplay = menuCard.querySelector('.qty-display');
      if (menuQtyDisplay) {
        menuQtyDisplay.textContent = newQuantity;
      }
    }
  });
}

// Add item to cart
function addToCart(menuCard, forceAdd = false) {
  const itemImage = menuCard.querySelector('.item-image img');
  const itemName = menuCard.querySelector('.item-name');
  const itemPrice = menuCard.querySelector('.price-tile') || menuCard.querySelector('.item-price');
  const quantityDisplay = menuCard.querySelector('.qty-display');
  
  if (itemImage && itemName && quantityDisplay) {
    const itemSrc = itemImage.src;
    const itemAlt = itemImage.alt;
    const itemNameText = itemName.textContent;
    const itemPriceText = itemPrice ? itemPrice.textContent : '₹0.00';
    const currentQuantity = parseInt(quantityDisplay.textContent) || 0;
    
    // Add to cart if quantity is greater than 0 OR if forceAdd is true
    if (currentQuantity > 0 || forceAdd) {
      // Check if item already exists in cart
      const existingCartItem = findCartItem(itemNameText);
      
      if (existingCartItem) {
        console.log('Existing Card Updated');
        // Update existing item quantity by adding the menu quantity
        const existingQtyDisplay = existingCartItem.querySelector('.qty-display');
        const existingQty = parseInt(existingQtyDisplay.textContent) || 0;
        const quantityToAdd = forceAdd ? 1 : currentQuantity;
        existingQtyDisplay.textContent = existingQty + quantityToAdd;
        
        // Update the total price for this item
        updateCartItemTotal(existingCartItem, itemPriceText);
      } else {
        console.log('New Card Added');
        // Add new item to cart with the current quantity from menu
        const cartItemsContainer = document.querySelector('.cart-items');
        const scrollIndicator = cartItemsContainer.querySelector('.scroll-indicator');
        
        const quantityToAdd = forceAdd ? 1 : currentQuantity;
        const newCartItem = createCartItem(itemSrc, itemAlt, itemNameText, itemPriceText, quantityToAdd);
        cartItemsContainer.insertBefore(newCartItem, scrollIndicator);
      }
      
      // Update cart total
      updateCartTotal();
      
      // Update last item border
      updateLastItemBorder();
    }
  }
}

// Find existing cart item by name
function findCartItem(itemName) {
  const cartItems = document.querySelectorAll('.cart-item');
  for (let item of cartItems) {
    const nameElement = item.querySelector('.item-name');
    if (nameElement && nameElement.textContent.trim() === itemName.trim()) {
      return item;
    }
  }
  return null;
}

// Create new cart item element
function createCartItem(imageSrc, imageAlt, itemName, itemPrice, quantity) {
  const cartItem = document.createElement('div');
  cartItem.className = 'cart-item';
  
  // Calculate total price for this item
  const unitPrice = parseFloat(itemPrice.replace('₹', '').replace(',', ''));
  const totalPrice = unitPrice * quantity;
  
  console.log('createCartItem called:', { itemName, itemPrice, quantity, unitPrice, totalPrice });
  
  cartItem.innerHTML = `
    <div class="item-image">
      <img src="${imageSrc}" alt="${imageAlt}">
    </div>
    <div class="item-details">
      <div class="item-name">${itemName}</div>
      <div class="item-price-info">
        <span class="unit-price">${itemPrice}</span>
        <span class="item-total">₹${totalPrice.toFixed(2)}</span>
      </div>
      <div class="controls-row">
        <div class="item-controls">
          <button class="qty-btn minus"></button>
          <span class="qty-display">${quantity}</span>
          <button class="qty-btn plus"></button>
        </div>
        <button class="remove-btn">
          <img src="image/Delete.svg" alt="Delete" width="16" height="16">
        </button>
      </div>
    </div>
  `;
  
  // Add event listener to remove border when this becomes the last item
  const removeBtn = cartItem.querySelector('.remove-btn');
  removeBtn.addEventListener('click', () => {
    setTimeout(() => {
      updateLastItemBorder();
    }, 100);
  });
  
  
  return cartItem;
}

// Function to update the last item border
function updateLastItemBorder() {
  const cartItems = document.querySelectorAll('.cart-item');
  cartItems.forEach((item, index) => {
    if (index === cartItems.length - 1) {
      item.style.borderBottom = 'none';
    } else {
      item.style.borderBottom = '2px dashed #fff';
    }
  });
}

// Update cart item total when quantity changes
function updateCartItemTotal(cartItem, unitPriceText) {
  const quantityDisplay = cartItem.querySelector('.qty-display');
  const itemTotalElement = cartItem.querySelector('.item-total');
  
  console.log('updateCartItemTotal called:', { unitPriceText, quantityDisplay: quantityDisplay?.textContent, itemTotalElement });
  
  if (quantityDisplay && itemTotalElement) {
    const quantity = parseInt(quantityDisplay.textContent) || 0;
    const unitPrice = parseFloat(unitPriceText.replace('₹', '').replace(',', ''));
    const totalPrice = unitPrice * quantity;
    
    console.log('Calculating total:', { quantity, unitPrice, totalPrice });
    
    itemTotalElement.textContent = `₹${totalPrice.toFixed(2)}`;
  }
}

// Update cart total count and grand total
function updateCartTotal() {
  const cartItems = document.querySelectorAll('.cart-item');
  const emptyCartMessage = document.querySelector('.empty-cart-message');
  let totalItems = 0;
  let grandTotal = 0;
  
  console.log('updateCartTotal called, found cart items:', cartItems.length);
  
  cartItems.forEach((item, index) => {
    const quantityDisplay = item.querySelector('.qty-display');
    const itemTotalElement = item.querySelector('.item-total');
    
    console.log(`Cart item ${index}:`, {
      quantity: quantityDisplay?.textContent,
      itemTotal: itemTotalElement?.textContent
    });
    
    if (quantityDisplay) {
      totalItems += parseInt(quantityDisplay.textContent) || 0;
    }
    
    if (itemTotalElement) {
      const itemTotal = parseFloat(itemTotalElement.textContent.replace('₹', '').replace(',', ''));
      grandTotal += itemTotal;
    }
  });
  
  console.log('Final totals:', { totalItems, grandTotal });
  
  const totalItemsElement = document.querySelector('.total-items');
  if (totalItemsElement) {
    totalItemsElement.innerHTML = `
      <div>Total ${totalItems} items</div>
      <div class="grand-total">Grand Total: ₹${grandTotal.toFixed(2)}</div>
    `;
  }
  
  // Update cart header totals
  const cartItemCountElement = document.querySelector('.cart-item-count');
  const cartTotalAmountElement = document.querySelector('.cart-total-amount');
  
  if (cartItemCountElement) {
    cartItemCountElement.textContent = `${totalItems} item${totalItems !== 1 ? 's' : ''}`;
  }
  
  if (cartTotalAmountElement) {
    cartTotalAmountElement.textContent = `₹${grandTotal.toFixed(2)}`;
  }
  
  // Show/hide empty cart message
  if (emptyCartMessage) {
    if (cartItems.length === 0) {
      emptyCartMessage.style.display = 'block';
    } else {
      emptyCartMessage.style.display = 'none';
    }
  }
}

// Initialize everything when DOM is loaded
window.addEventListener('DOMContentLoaded', () => {
  // Initialize drag scrolling for category tabs
  initializeDragScrolling();
  
  // Initialize quantity controls
  initializeQuantityControls();
  
  // Initialize the Tea slider (Swiper) if it exists
  try {
    const teaSwiper = new Swiper('.tea-swiper', {
      slidesPerView: 1,
      spaceBetween: 16,
      loop: true,
      pagination: {
        el: '.tea-swiper .swiper-pagination',
        clickable: true,
      },
      navigation: {
        nextEl: '.tea-swiper .swiper-button-next',
        prevEl: '.tea-swiper .swiper-button-prev',
      },
      breakpoints: {
        576: { slidesPerView: 2 },
        768: { slidesPerView: 3 },
        1200: { slidesPerView: 4 }
      }
    });
  } catch (e) {
    console.warn('Swiper init skipped or failed:', e);
  }
});

// Search input placeholder behavior
document.addEventListener('DOMContentLoaded', function() {
  const searchInput = document.querySelector('.search-input');
  
  if (searchInput) {
    searchInput.addEventListener('focus', () => {
      searchInput.placeholder = '';
    });
    
    searchInput.addEventListener('blur', () => {
      if (searchInput.value.trim() === '') {
        searchInput.placeholder = 'Search';
      }
    });
  }

  // Initialize scroll button functionality
  initializeScrollButton();
});

// Initialize scroll button functionality
function initializeScrollButton() {
  const cartItems = document.querySelector('.cart-items');
  const scrollIndicator = document.querySelector('.scroll-indicator');
  
  if (!cartItems || !scrollIndicator) return;

  // Function to check if scrolling is needed
  function checkScrollNeeded() {
    const isScrollable = cartItems.scrollHeight > cartItems.clientHeight;
    if (isScrollable) {
      scrollIndicator.classList.add('show');
    } else {
      scrollIndicator.classList.remove('show');
    }
  }

  // Function to scroll down
  function scrollDown() {
    cartItems.scrollBy({
      top: 100,
      behavior: 'smooth'
    });
  }

  // Add click event to scroll button
  scrollIndicator.addEventListener('click', scrollDown);

  // Check scroll on load and when cart items change
  checkScrollNeeded();
  
  // Check scroll when cart items are added/removed
  const observer = new MutationObserver(checkScrollNeeded);
  observer.observe(cartItems, { childList: true, subtree: true });
  
  // Check scroll on window resize
  window.addEventListener('resize', checkScrollNeeded);
}

// Place Order button functionality
document.addEventListener('DOMContentLoaded', function() {
  const placeOrderBtn = document.querySelector('.place-order-btn');
  
  if (placeOrderBtn) {
    placeOrderBtn.addEventListener('click', () => {
      // Check if cart has items
      const cartItems = document.querySelectorAll('.cart-item');
      if (cartItems.length === 0) {
        alert('Please add items to your cart before placing an order.');
        return;
      }
      
      // Redirect to success page
      window.location.href = 'order-success.html';
    });
  }
});
