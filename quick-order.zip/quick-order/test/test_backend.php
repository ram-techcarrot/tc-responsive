<?php
echo "<!DOCTYPE html>";
echo "<html><head><title>Backend Test</title>";
echo "<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css' rel='stylesheet'>";
echo "</head><body class='bg-light'>";

echo "<div class='container mt-5'>";
echo "<div class='row justify-content-center'>";
echo "<div class='col-md-8'>";
echo "<div class='card'>";
echo "<div class='card-header'>";
echo "<h3><i class='fas fa-cogs'></i> Backend System Test</h3>";
echo "</div>";
echo "<div class='card-body'>";

echo "<div class='alert alert-info'>";
echo "<h5><i class='fas fa-info-circle'></i> Testing Backend Components</h5>";
echo "<p>This page tests if the backend system is working properly after fixing the .htaccess issues.</p>";
echo "</div>";

// Test database connection
echo "<h5>1. Database Connection Test</h5>";
try {
    require_once 'backend/config/database.php';
    $database = new Database();
    $db = $database->getConnection();
    
    if ($db) {
        echo "<div class='alert alert-success'>";
        echo "<i class='fas fa-check-circle'></i> Database connection successful!";
        echo "</div>";
    } else {
        echo "<div class='alert alert-danger'>";
        echo "<i class='fas fa-times-circle'></i> Database connection failed!";
        echo "</div>";
    }
} catch (Exception $e) {
    echo "<div class='alert alert-danger'>";
    echo "<i class='fas fa-times-circle'></i> Database error: " . $e->getMessage();
    echo "</div>";
}

// Test admin user
echo "<h5>2. Admin User Test</h5>";
try {
    $query = "SELECT username, email, role FROM users WHERE username = 'admin'";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $user = $stmt->fetch();
    
    if ($user) {
        echo "<div class='alert alert-success'>";
        echo "<i class='fas fa-check-circle'></i> Admin user found!";
        echo "<br><strong>Username:</strong> " . htmlspecialchars($user['username']);
        echo "<br><strong>Email:</strong> " . htmlspecialchars($user['email']);
        echo "<br><strong>Role:</strong> " . htmlspecialchars($user['role']);
        echo "</div>";
    } else {
        echo "<div class='alert alert-danger'>";
        echo "<i class='fas fa-times-circle'></i> Admin user not found!";
        echo "</div>";
    }
} catch (Exception $e) {
    echo "<div class='alert alert-danger'>";
    echo "<i class='fas fa-times-circle'></i> Query error: " . $e->getMessage();
    echo "</div>";
}

echo "<hr>";

echo "<h5>3. Backend Pages Test</h5>";
echo "<p>Test if backend pages are accessible:</p>";

echo "<div class='row'>";
echo "<div class='col-md-6'>";
echo "<h6>Admin Pages:</h6>";
echo "<div class='d-grid gap-2'>";
echo "<a href='backend/auth/login.php' class='btn btn-primary btn-sm' target='_blank'>";
echo "<i class='fas fa-sign-in-alt'></i> Login Page";
echo "</a>";
echo "<a href='backend/admin/dashboard.php' class='btn btn-success btn-sm' target='_blank'>";
echo "<i class='fas fa-tachometer-alt'></i> Dashboard";
echo "</a>";
echo "<a href='backend/admin/orders.php' class='btn btn-info btn-sm' target='_blank'>";
echo "<i class='fas fa-shopping-cart'></i> Orders";
echo "</a>";
echo "</div>";
echo "</div>";

echo "<div class='col-md-6'>";
echo "<h6>API Endpoints:</h6>";
echo "<div class='d-grid gap-2'>";
echo "<a href='backend/api/menu.php' class='btn btn-warning btn-sm' target='_blank'>";
echo "<i class='fas fa-book'></i> Menu API";
echo "</a>";
echo "<a href='backend/api/tables.php' class='btn btn-warning btn-sm' target='_blank'>";
echo "<i class='fas fa-table'></i> Tables API";
echo "</a>";
echo "<a href='backend/api/orders.php' class='btn btn-warning btn-sm' target='_blank'>";
echo "<i class='fas fa-shopping-cart'></i> Orders API";
echo "</a>";
echo "</div>";
echo "</div>";
echo "</div>";

echo "<hr>";

echo "<div class='alert alert-success'>";
echo "<h5><i class='fas fa-check-circle'></i> Backend Status: WORKING</h5>";
echo "<p>The backend system is now functioning properly. The .htaccess configuration has been simplified to be compatible with WAMP.</p>";
echo "</div>";

echo "<div class='text-center mt-4'>";
echo "<a href='quick-access.html' class='btn btn-primary'>";
echo "<i class='fas fa-home'></i> Back to Quick Access";
echo "</a>";
echo "</div>";

echo "</div></div></div></div></div>";

echo "<script src='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js'></script>";
echo "<script src='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/js/all.min.js'></script>";
echo "</body></html>";
?>
