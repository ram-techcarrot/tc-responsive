-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Sep 24, 2025 at 03:19 PM
-- Server version: 9.1.0
-- PHP Version: 8.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `quickorder`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `sort_order` int DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `icon`, `is_active`, `sort_order`, `created_at`, `updated_at`) VALUES
(26, 'Tea', 'Tea.svg', 1, 1, '2025-09-24 11:34:27', '2025-09-24 11:34:27'),
(27, 'Coffee', 'Coffee.svg', 1, 2, '2025-09-24 11:34:27', '2025-09-24 11:34:27'),
(28, 'Juice', 'Juice.svg', 1, 3, '2025-09-24 11:34:27', '2025-09-24 11:34:27'),
(29, 'Water', 'Water.svg', 1, 4, '2025-09-24 11:34:27', '2025-09-24 11:34:27'),
(30, 'Soft Drinks', 'Soft Drink.svg', 1, 5, '2025-09-24 11:34:27', '2025-09-24 11:34:27'),
(31, 'Snacks', 'Snacks.svg', 1, 6, '2025-09-24 11:34:27', '2025-09-24 11:34:27');

-- --------------------------------------------------------

--
-- Table structure for table `menu_items`
--

DROP TABLE IF EXISTS `menu_items`;
CREATE TABLE IF NOT EXISTS `menu_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `category_id` int NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text,
  `price` decimal(10,2) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `is_available` tinyint(1) DEFAULT '1',
  `sort_order` int DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=83 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `menu_items`
--

INSERT INTO `menu_items` (`id`, `category_id`, `name`, `description`, `price`, `image`, `is_available`, `sort_order`, `created_at`, `updated_at`) VALUES
(62, 26, 'Black Tea', 'Classic black tea with rich flavor', 8.00, 'black_tea.png', 1, 0, '2025-09-24 11:34:33', '2025-09-24 11:34:33'),
(63, 26, 'Green Tea', 'Refreshing green tea with antioxidants', 9.00, 'green_tea.png', 1, 1, '2025-09-24 11:34:33', '2025-09-24 11:34:33'),
(64, 26, 'Chamomile Tea', 'Soothing herbal tea for relaxation', 10.00, 'chamomile_tea.png', 1, 2, '2025-09-24 11:34:33', '2025-09-24 11:34:33'),
(65, 26, 'Ginger Lemon Tea', 'Warming tea with ginger and lemon', 12.00, 'ginger_lemon.png', 1, 3, '2025-09-24 11:34:33', '2025-09-24 11:34:33'),
(66, 26, 'Milk Tea', 'Creamy tea with milk', 11.00, 'milk_tea.png', 1, 4, '2025-09-24 11:34:33', '2025-09-24 11:34:33'),
(67, 27, 'Espresso', 'Strong Italian coffee', 15.00, NULL, 1, 5, '2025-09-24 11:34:33', '2025-09-24 11:34:33'),
(68, 27, 'Cappuccino', 'Espresso with steamed milk foam', 18.00, NULL, 1, 6, '2025-09-24 11:34:33', '2025-09-24 11:34:33'),
(69, 27, 'Latte', 'Espresso with steamed milk', 20.00, NULL, 1, 7, '2025-09-24 11:34:33', '2025-09-24 11:34:33'),
(70, 27, 'Americano', 'Espresso with hot water', 16.00, NULL, 1, 8, '2025-09-24 11:34:33', '2025-09-24 11:34:33'),
(71, 28, 'Orange Juice', 'Fresh squeezed orange juice', 12.00, NULL, 1, 9, '2025-09-24 11:34:33', '2025-09-24 11:34:33'),
(72, 28, 'Apple Juice', 'Fresh apple juice', 11.00, NULL, 1, 10, '2025-09-24 11:34:33', '2025-09-24 11:34:33'),
(73, 28, 'Mango Juice', 'Tropical mango juice', 14.00, NULL, 1, 11, '2025-09-24 11:34:33', '2025-09-24 11:34:33'),
(74, 29, 'Mineral Water', 'Pure mineral water', 5.00, NULL, 1, 12, '2025-09-24 11:34:33', '2025-09-24 11:34:33'),
(75, 29, 'Sparkling Water', 'Carbonated mineral water', 6.00, NULL, 1, 13, '2025-09-24 11:34:33', '2025-09-24 11:34:33'),
(76, 30, 'Coca Cola', 'Classic cola drink', 8.00, NULL, 1, 14, '2025-09-24 11:34:33', '2025-09-24 11:34:33'),
(77, 30, 'Pepsi', 'Refreshing cola drink', 8.00, NULL, 1, 15, '2025-09-24 11:34:33', '2025-09-24 11:34:33'),
(78, 30, 'Sprite', 'Lemon-lime soda', 8.00, NULL, 1, 16, '2025-09-24 11:34:33', '2025-09-24 11:34:33'),
(79, 31, 'Chicken Sandwich', 'Grilled chicken sandwich', 25.00, NULL, 1, 17, '2025-09-24 11:34:33', '2025-09-24 11:34:33'),
(80, 31, 'Vegetable Wrap', 'Fresh vegetable wrap', 22.00, NULL, 1, 18, '2025-09-24 11:34:33', '2025-09-24 11:34:33'),
(81, 31, 'French Fries', 'Crispy golden fries', 15.00, NULL, 1, 19, '2025-09-24 11:34:33', '2025-09-24 11:34:33'),
(82, 31, 'Chicken Wings', 'Spicy chicken wings', 28.00, NULL, 1, 20, '2025-09-24 11:34:33', '2025-09-24 11:34:33');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_number` varchar(20) NOT NULL,
  `customer_name` varchar(100) NOT NULL,
  `customer_mobile` varchar(20) NOT NULL,
  `table_id` int DEFAULT NULL,
  `status` enum('placed','pending','cooking','served','completed','paid') DEFAULT 'placed',
  `subtotal` decimal(10,2) NOT NULL DEFAULT '0.00',
  `gst_rate` decimal(5,2) DEFAULT '0.00',
  `gst_amount` decimal(10,2) DEFAULT '0.00',
  `total_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `notes` text,
  `placed_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `served_at` timestamp NULL DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `paid_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_number` (`order_number`),
  KEY `table_id` (`table_id`),
  KEY `idx_status` (`status`),
  KEY `idx_placed_at` (`placed_at`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `order_number`, `customer_name`, `customer_mobile`, `table_id`, `status`, `subtotal`, `gst_rate`, `gst_amount`, `total_amount`, `notes`, `placed_at`, `served_at`, `completed_at`, `paid_at`, `created_at`, `updated_at`) VALUES
(1, '1001', 'John Smith', '+971501234567', 6, 'served', 0.00, 0.00, 0.00, 25.00, NULL, '2025-09-24 10:52:17', NULL, NULL, NULL, '2025-09-24 10:52:17', '2025-09-24 14:37:33'),
(2, '1002', 'Sarah Johnson', '+971502345678', 7, 'served', 0.00, 0.00, 0.00, 30.00, NULL, '2025-09-24 10:52:17', NULL, NULL, NULL, '2025-09-24 10:52:17', '2025-09-24 14:37:26'),
(3, '1003', 'Ahmed Al-Rashid', '+971503456789', 8, 'served', 0.00, 0.00, 0.00, 35.00, NULL, '2025-09-24 10:52:17', NULL, NULL, NULL, '2025-09-24 10:52:17', '2025-09-24 14:37:35'),
(4, '1004', 'Maria Garcia', '+971504567890', 9, 'served', 0.00, 0.00, 0.00, 28.00, NULL, '2025-09-24 10:52:17', NULL, NULL, NULL, '2025-09-24 10:52:17', '2025-09-24 10:52:17'),
(5, '1005', 'David Brown', '+971505678901', 10, 'completed', 0.00, 0.00, 0.00, 32.00, NULL, '2025-09-24 10:52:17', NULL, NULL, NULL, '2025-09-24 10:52:17', '2025-09-24 10:52:17'),
(6, '1006', 'Fatima Al-Zahra', '+971506789012', 11, 'paid', 0.00, 0.00, 0.00, 40.00, NULL, '2025-09-24 10:52:17', NULL, NULL, NULL, '2025-09-24 10:52:17', '2025-09-24 10:52:17'),
(7, 'ORD202509247670', 'Ram Mohan Sharma', '8586091912', NULL, 'cooking', 75.00, 0.05, 3.75, 78.75, NULL, '2025-09-24 11:42:00', NULL, NULL, NULL, '2025-09-24 11:42:00', '2025-09-24 14:37:38'),
(8, 'ORD202509243790', 'Jeetu', '8586091912', NULL, 'cooking', 40.00, 0.05, 2.00, 42.00, NULL, '2025-09-24 11:54:30', NULL, NULL, NULL, '2025-09-24 11:54:30', '2025-09-24 14:37:45'),
(9, 'ORD202509242448', 'Customer', '', 6, 'cooking', 40.00, 0.05, 2.00, 42.00, NULL, '2025-09-24 11:55:28', NULL, NULL, NULL, '2025-09-24 11:55:28', '2025-09-24 14:37:40'),
(10, 'ORD202509242343', 'Ram', '7689', NULL, 'placed', 39.00, 0.05, 1.95, 40.95, NULL, '2025-09-24 11:57:05', NULL, NULL, NULL, '2025-09-24 11:57:05', '2025-09-24 11:57:05'),
(11, 'ORD202509246603', 'Customer', '', 6, 'placed', 87.00, 0.05, 4.35, 91.35, NULL, '2025-09-24 12:20:08', NULL, NULL, NULL, '2025-09-24 12:20:08', '2025-09-24 12:20:08'),
(12, 'ORD202509243519', 'Ram', '87645675678', NULL, 'placed', 80.00, 0.05, 4.00, 84.00, NULL, '2025-09-24 12:35:45', NULL, NULL, NULL, '2025-09-24 12:35:45', '2025-09-24 12:35:45'),
(13, 'ORD202509244541', 'Ram', '87645675678', NULL, 'cooking', 80.00, 0.05, 4.00, 84.00, NULL, '2025-09-24 12:36:08', NULL, NULL, NULL, '2025-09-24 12:36:08', '2025-09-24 14:41:21'),
(14, 'ORD202509245287', 'Ram', '87645675678', NULL, 'served', 80.00, 0.05, 4.00, 84.00, NULL, '2025-09-24 12:37:43', NULL, NULL, NULL, '2025-09-24 12:37:43', '2025-09-24 15:06:25'),
(15, '4502', 'JayJay', '34567890', NULL, 'placed', 54.00, 0.05, 2.70, 56.70, NULL, '2025-09-24 15:07:02', NULL, NULL, NULL, '2025-09-24 15:07:02', '2025-09-24 15:07:02');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

DROP TABLE IF EXISTS `order_items`;
CREATE TABLE IF NOT EXISTS `order_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL,
  `menu_item_id` int NOT NULL,
  `item_name` varchar(100) DEFAULT NULL,
  `quantity` int NOT NULL DEFAULT '1',
  `unit_price` decimal(10,2) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `notes` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `menu_item_id` (`menu_item_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `menu_item_id`, `item_name`, `quantity`, `unit_price`, `total_price`, `notes`, `created_at`) VALUES
(1, 14, 65, 'Ginger Lemon Tea', 1, 12.00, 12.00, NULL, '2025-09-24 12:37:43'),
(2, 14, 64, 'Chamomile Tea', 1, 10.00, 10.00, NULL, '2025-09-24 12:37:43'),
(3, 14, 68, 'Cappuccino', 1, 18.00, 18.00, NULL, '2025-09-24 12:37:43'),
(4, 14, 67, 'Espresso', 1, 15.00, 15.00, NULL, '2025-09-24 12:37:43'),
(5, 14, 66, 'Milk Tea', 1, 11.00, 11.00, NULL, '2025-09-24 12:37:43'),
(6, 14, 75, 'Sparkling Water', 1, 6.00, 6.00, NULL, '2025-09-24 12:37:43'),
(7, 14, 76, 'Coca Cola', 1, 8.00, 8.00, NULL, '2025-09-24 12:37:43'),
(8, 15, 64, 'Chamomile Tea', 2, 10.00, 20.00, NULL, '2025-09-24 15:07:02'),
(9, 15, 63, 'Green Tea', 2, 9.00, 18.00, NULL, '2025-09-24 15:07:02'),
(10, 15, 62, 'Black Tea', 2, 8.00, 16.00, NULL, '2025-09-24 15:07:02');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
CREATE TABLE IF NOT EXISTS `settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text NOT NULL,
  `description` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `setting_key`, `setting_value`, `description`, `created_at`, `updated_at`) VALUES
(1, 'gst_rate', '18.00', 'GST rate percentage', '2025-09-24 08:36:39', '2025-09-24 08:36:39'),
(2, 'gst_enabled', '1', 'Enable/disable GST calculation', '2025-09-24 08:36:39', '2025-09-24 08:36:39'),
(3, 'restaurant_name', 'Sobha Restaurant', 'Restaurant name', '2025-09-24 08:36:39', '2025-09-24 08:36:39'),
(4, 'restaurant_address', '123 Main Street, City', 'Restaurant address', '2025-09-24 08:36:39', '2025-09-24 08:36:39'),
(5, 'restaurant_phone', '+91 9876543210', 'Restaurant phone number', '2025-09-24 08:36:39', '2025-09-24 08:36:39');

-- --------------------------------------------------------

--
-- Table structure for table `tables`
--

DROP TABLE IF EXISTS `tables`;
CREATE TABLE IF NOT EXISTS `tables` (
  `id` int NOT NULL AUTO_INCREMENT,
  `table_number` varchar(20) NOT NULL,
  `qr_code` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `table_number` (`table_number`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `tables`
--

INSERT INTO `tables` (`id`, `table_number`, `qr_code`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'T001', NULL, 1, '2025-09-24 08:36:39', '2025-09-24 08:36:39'),
(2, 'T002', NULL, 1, '2025-09-24 08:36:39', '2025-09-24 08:36:39'),
(3, 'T003', NULL, 1, '2025-09-24 08:36:39', '2025-09-24 08:36:39'),
(4, 'T004', NULL, 1, '2025-09-24 08:36:39', '2025-09-24 08:36:39'),
(5, 'T005', NULL, 1, '2025-09-24 08:36:39', '2025-09-24 08:36:39'),
(6, 'T01', NULL, 1, '2025-09-24 10:52:17', '2025-09-24 10:52:17'),
(7, 'T02', NULL, 1, '2025-09-24 10:52:17', '2025-09-24 10:52:17'),
(8, 'T03', NULL, 1, '2025-09-24 10:52:17', '2025-09-24 10:52:17'),
(9, 'T04', NULL, 1, '2025-09-24 10:52:17', '2025-09-24 10:52:17'),
(10, 'T05', NULL, 1, '2025-09-24 10:52:17', '2025-09-24 10:52:17'),
(11, 'T06', NULL, 1, '2025-09-24 10:52:17', '2025-09-24 10:52:17'),
(12, 'T07', NULL, 1, '2025-09-24 10:52:17', '2025-09-24 10:52:17'),
(13, 'T08', NULL, 1, '2025-09-24 10:52:17', '2025-09-24 10:52:17'),
(14, 'T09', NULL, 1, '2025-09-24 10:52:17', '2025-09-24 10:52:17'),
(15, 'T10', NULL, 1, '2025-09-24 10:52:17', '2025-09-24 10:52:17');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','staff') DEFAULT 'staff',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `role`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'admin@quickorder.com', '$2y$10$ZEqCWlUJNbjNkxVANsf4FOi./8EPMM.7Pj/nPr5tVpd89GHuaTGqq', 'admin', '2025-09-24 08:36:39', '2025-09-24 10:21:51');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
